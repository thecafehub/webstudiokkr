
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS trending boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS features text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS faqs jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS products_trending_idx ON public.products(trending) WHERE trending = true;
CREATE INDEX IF NOT EXISTS products_featured_idx ON public.products(featured) WHERE featured = true;

ALTER TABLE public.blogs
  ADD COLUMN IF NOT EXISTS featured boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS blogs_featured_idx ON public.blogs(featured) WHERE featured = true;
CREATE INDEX IF NOT EXISTS blogs_view_count_idx ON public.blogs(view_count DESC);

-- Clear out the stale "© 1970" footer copyright row if it exists; it was
-- captured early and now causes a hydration mismatch with the client clock.
DELETE FROM public.website_settings WHERE key = 'footer';
