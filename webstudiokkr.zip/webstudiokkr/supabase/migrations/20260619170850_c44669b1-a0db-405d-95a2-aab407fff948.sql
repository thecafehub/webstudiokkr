
-- Restrict profile reads (email PII) to the owner and admins only.
DROP POLICY IF EXISTS "Profiles are public-readable" ON public.profiles;
REVOKE SELECT ON public.profiles FROM anon;

CREATE POLICY "Users read own profile" ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Staff read profiles" ON public.profiles
  FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['admin','manager','editor']));

-- Lock down trigger-only SECURITY DEFINER helpers; triggers run as table owner regardless.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;
