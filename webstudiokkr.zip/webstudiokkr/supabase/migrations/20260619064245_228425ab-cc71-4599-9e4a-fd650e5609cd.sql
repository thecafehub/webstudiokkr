-- Public SELECT for rows flagged is_public = true
DROP POLICY IF EXISTS "Public read public settings" ON public.website_settings;
CREATE POLICY "Public read public settings" ON public.website_settings
  FOR SELECT TO anon, authenticated
  USING (is_public = true);

-- Ensure anon can SELECT via Data API
GRANT SELECT ON public.website_settings TO anon;

-- Seed default rows (idempotent)
INSERT INTO public.website_settings (key, value, is_public) VALUES
  ('brand', '{"name":"Web Studio KKR","tagline":"Premium digital craftsmanship from Kurukshetra to the world","description":"Web Studio KKR is a full-stack digital agency, products marketplace, tools platform and blog — building websites, custom APIs, automation bots and SEO systems for modern businesses.","logoUrl":"","faviconUrl":"/favicon.ico"}', true),
  ('contact', '{"email":"nitinkamboj510@gmail.com","phone":"+91 8295420609","whatsapp":"+918295420609","whatsappLink":"https://wa.me/918295420609","telegram":"webstudiokkr","telegramLink":"https://t.me/webstudiokkr","instagram":"webstudiokkr","instagramLink":"https://instagram.com/webstudiokkr","address":"Kurukshetra, Haryana, India"}', true),
  ('hero', '{"eyebrow":"Premium digital craftsmanship","headline":"Websites, SEO, APIs, Automation","highlight":"& Digital Products","subcopy":"Premium digital craftsmanship from Kurukshetra to the world","ctaPrimary":{"label":"Start a project","href":"/contact"},"ctaSecondary":{"label":"Explore services","href":"/services"}}', true),
  ('stats', '[{"label":"Projects shipped","value":"120+"},{"label":"Happy clients","value":"80+"},{"label":"Countries served","value":"14"},{"label":"Years of craft","value":"5+"}]', true),
  ('footer', '{"copyright":"© 2026 Web Studio KKR","tagline":"Premium digital craftsmanship from Kurukshetra to the world"}', true),
  ('integrations', '{"ga4MeasurementId":"G-LMK3HRTESX","ga4PropertyId":"542294012","gscSiteUrl":"https://webstudiokkr.in/","clarityProjectId":""}', false)
ON CONFLICT (key) DO NOTHING;