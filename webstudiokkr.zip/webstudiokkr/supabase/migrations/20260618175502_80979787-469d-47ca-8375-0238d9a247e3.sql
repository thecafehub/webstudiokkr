-- 1. Extend role enum (committed before any literal use thanks to has_any_role text helper)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'manager';

-- 2. Extend lead_status enum
ALTER TYPE public.lead_status ADD VALUE IF NOT EXISTS 'qualified';
ALTER TYPE public.lead_status ADD VALUE IF NOT EXISTS 'closed';

-- 3. Role helper that takes text[] so we don't need the new enum literal in this txn
CREATE OR REPLACE FUNCTION public.has_any_role(_user_id uuid, _roles text[])
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role::text = ANY(_roles)
  )
$$;

-- 4. Leads CRM extensions
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS assigned_to uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS follow_up_at timestamptz,
  ADD COLUMN IF NOT EXISTS product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS internal_notes text;

CREATE INDEX IF NOT EXISTS leads_status_idx ON public.leads(status);
CREATE INDEX IF NOT EXISTS leads_follow_up_idx ON public.leads(follow_up_at);

-- 5. Lead notes table
CREATE TABLE IF NOT EXISTS public.lead_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  body text NOT NULL,
  author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lead_notes TO authenticated;
GRANT ALL ON public.lead_notes TO service_role;
ALTER TABLE public.lead_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage lead notes" ON public.lead_notes
  FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['admin','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['admin','manager']));
CREATE INDEX IF NOT EXISTS lead_notes_lead_idx ON public.lead_notes(lead_id);

-- 6. Media folder column
ALTER TABLE public.media
  ADD COLUMN IF NOT EXISTS folder text NOT NULL DEFAULT 'general';
CREATE INDEX IF NOT EXISTS media_folder_idx ON public.media(folder);

-- 7. Manager full access on leads (admin policy already exists)
CREATE POLICY "Managers manage leads" ON public.leads
  FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['manager']));

-- 8. Editor + Manager content access (admin policies already exist; additive)
-- Blogs
CREATE POLICY "Staff read all blogs" ON public.blogs FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage blogs" ON public.blogs FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Products
CREATE POLICY "Staff read all products" ON public.products FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage products" ON public.products FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Services
CREATE POLICY "Staff read all services" ON public.services FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage services" ON public.services FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Tools
CREATE POLICY "Staff read all tools" ON public.tools FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage tools" ON public.tools FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Pages
CREATE POLICY "Staff read all pages" ON public.pages FOR SELECT TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage pages" ON public.pages FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Categories
CREATE POLICY "Staff manage categories" ON public.categories FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Media
CREATE POLICY "Staff manage media" ON public.media FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- SEO
CREATE POLICY "Staff manage seo" ON public.seo_settings FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));

-- Tags / blog_tags / product_tags
CREATE POLICY "Staff manage tags" ON public.tags FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage blog tags" ON public.blog_tags FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));
CREATE POLICY "Staff manage product tags" ON public.product_tags FOR ALL TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['editor','manager']))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['editor','manager']));