
DROP POLICY IF EXISTS "Media admin insert" ON storage.objects;
DROP POLICY IF EXISTS "Media admin update" ON storage.objects;
DROP POLICY IF EXISTS "Media admin delete" ON storage.objects;

CREATE POLICY "Media staff insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'media' AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_any_role(auth.uid(), ARRAY['editor','manager'])
  ));

CREATE POLICY "Media staff update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'media' AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_any_role(auth.uid(), ARRAY['editor','manager'])
  ))
  WITH CHECK (bucket_id = 'media' AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_any_role(auth.uid(), ARRAY['editor','manager'])
  ));

CREATE POLICY "Media staff delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'media' AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_any_role(auth.uid(), ARRAY['editor','manager'])
  ));
