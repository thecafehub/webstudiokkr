
CREATE OR REPLACE FUNCTION public.claim_admin_if_no_admin_exists()
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_existing INT;
BEGIN
  IF v_caller IS NULL THEN
    RETURN false;
  END IF;

  SELECT COUNT(*) INTO v_existing FROM public.user_roles WHERE role = 'admin';

  IF v_existing > 0 THEN
    RETURN false;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (v_caller, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN true;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_admin_if_no_admin_exists() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.claim_admin_if_no_admin_exists() TO authenticated;
