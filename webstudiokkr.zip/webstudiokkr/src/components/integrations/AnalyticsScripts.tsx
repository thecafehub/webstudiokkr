/**
 * Client-side injector for GA4 + Microsoft Clarity, plus SPA route-change
 * page_view tracking. Reads IDs from the CMS settings store so admins can
 * flip them without a code deploy.
 */
import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";
import { useCms } from "@/lib/admin/store";
import { trackPageView } from "@/lib/analytics/track";

function injectOnce(id: string, build: () => HTMLScriptElement) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const el = build();
  el.id = id;
  document.head.appendChild(el);
}

export function AnalyticsScripts() {
  const integrations = useCms((s) => s.settings.integrations);
  const router = useRouter();

  useEffect(() => {
    const ga = integrations?.ga4MeasurementId?.trim();
    if (ga) {
      injectOnce("ga4-loader", () => {
        const s = document.createElement("script");
        s.async = true;
        s.src = `https://www.googletagmanager.com/gtag/js?id=${ga}`;
        return s;
      });
      injectOnce("ga4-init", () => {
        const s = document.createElement("script");
        s.text = `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);} window.gtag=gtag; gtag('js', new Date()); gtag('config', '${ga}', { send_page_view: true });`;
        return s;
      });
    }

    const clarity = integrations?.clarityProjectId?.trim();
    if (clarity) {
      injectOnce("ms-clarity", () => {
        const s = document.createElement("script");
        s.text = `(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y)})(window,document,"clarity","script","${clarity}");`;
        return s;
      });
    }
  }, [integrations?.ga4MeasurementId, integrations?.clarityProjectId]);

  // SPA route-change page_view tracking.
  useEffect(() => {
    if (!integrations?.ga4MeasurementId?.trim()) return;
    const unsub = router.subscribe("onResolved", ({ toLocation }) => {
      trackPageView(toLocation.pathname + (toLocation.searchStr ?? ""));
    });
    return () => unsub();
  }, [router, integrations?.ga4MeasurementId]);

  return null;
}
