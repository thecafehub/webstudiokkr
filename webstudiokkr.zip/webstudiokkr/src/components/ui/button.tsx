import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-white/10 bg-white/[0.03] backdrop-blur hover:bg-white/[0.08] hover:border-white/20",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-white/5 hover:text-foreground",
        link: "text-brand-cyan underline-offset-4 hover:underline",
        brand:
          "relative overflow-hidden bg-gradient-to-r from-brand-blue via-brand-cyan to-brand-violet text-white shadow-[0_8px_24px_-8px_oklch(0.65_0.21_255/0.6)] hover:shadow-[0_12px_32px_-8px_oklch(0.65_0.21_255/0.8)] hover:-translate-y-0.5",
        glass:
          "glass text-foreground hover:bg-white/10 hover:-translate-y-0.5",
        hero:
          "relative overflow-hidden border border-white/10 bg-gradient-to-r from-brand-blue/90 to-brand-violet/90 text-white shadow-[0_0_0_1px_oklch(1_0_0/0.06)_inset,0_20px_60px_-20px_oklch(0.65_0.21_255/0.7)] hover:shadow-[0_0_0_1px_oklch(1_0_0/0.12)_inset,0_24px_70px_-20px_oklch(0.65_0.21_255/0.9)] hover:-translate-y-0.5",
      },
      size: {
        default: "h-10 px-5 py-2",
        sm: "h-9 rounded-md px-3.5 text-xs",
        lg: "h-11 rounded-lg px-7 text-[15px]",
        xl: "h-[52px] rounded-xl px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);


export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
