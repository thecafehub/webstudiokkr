import { MessageCircle, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  buildInquiryMessage,
  copyToClipboard,
  telegramLink,
  trackInquiry,
  whatsappLink,
  type InquiryContext,
} from "@/lib/inquiry";

/**
 * Reusable WhatsApp + Telegram inquiry CTAs.
 *
 * Usage:
 *   <InquiryButtons context={{ source: "product_card", productId, productTitle, productSlug, category }} />
 *
 * Both clicks log a soft lead in the CRM so demand is trackable.
 */
export function InquiryButtons({
  context,
  size = "default",
  className = "",
  variant = "brand",
}: {
  context: InquiryContext;
  size?: "sm" | "default" | "lg";
  className?: string;
  variant?: "brand" | "hero" | "glass" | "outline";
}) {
  const wa = whatsappLink(context);
  const tg = telegramLink();
  const msg = buildInquiryMessage(context);

  const onTelegram = async () => {
    void trackInquiry("telegram", context);
    const copied = await copyToClipboard(msg);
    if (copied) {
      toast.success("Message copied", {
        description: "We've copied your inquiry — paste it into the Telegram chat.",
      });
    }
  };

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      <Button asChild variant={variant} size={size}>
        <a
          href={wa}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => void trackInquiry("whatsapp", context)}
        >
          <MessageCircle className="h-4 w-4" /> WhatsApp inquiry
        </a>
      </Button>
      <Button asChild variant="glass" size={size}>
        <a
          href={tg}
          target="_blank"
          rel="noopener noreferrer"
          onClick={onTelegram}
        >
          <Send className="h-4 w-4" /> Telegram inquiry
        </a>
      </Button>
    </div>
  );
}
