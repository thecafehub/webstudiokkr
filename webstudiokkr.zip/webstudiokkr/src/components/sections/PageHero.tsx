import type { ReactNode } from "react";

/**
 * Reusable page hero. Used by every non-home route. Includes eyebrow tag,
 * gradient title, lead paragraph, and optional CTA slot.
 */
export function PageHero({
  eyebrow,
  title,
  highlight,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  highlight?: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <section className="relative">
      <div className="container mx-auto px-4 pt-12 pb-16 sm:pt-20 sm:pb-24">
        <div className="mx-auto max-w-3xl text-center animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-brand-cyan">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan animate-pulse-glow" />
            {eyebrow}
          </span>
          <h1 className="mt-6 font-display text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            {title}{" "}
            {highlight && <span className="gradient-brand-text">{highlight}</span>}
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {description}
          </p>
          {children && <div className="mt-8 flex flex-wrap items-center justify-center gap-3">{children}</div>}
        </div>
      </div>
    </section>
  );
}
