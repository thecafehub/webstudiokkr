import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Flame, Sparkles, Star } from "lucide-react";
import { Spotlight } from "@/components/effects/Spotlight";
import { trackEvent } from "@/lib/analytics/track";
import type { Product } from "@/lib/cms/queries";

/** Compact product card used on /products and related-product strips. */
export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  return (
    <Link
      to="/products/$slug"
      params={{ slug: product.slug }}
      onClick={() =>
        trackEvent("product_click", {
          product_id: product.id,
          product_title: product.title,
        })
      }
      className="group relative block overflow-hidden rounded-2xl glass p-6 hover-lift animate-fade-up"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <Spotlight />
      {product.image ? (
        <div className="-mx-6 -mt-6 mb-5 aspect-[16/9] overflow-hidden rounded-t-2xl bg-white/5">
          <img
            src={product.image}
            alt={product.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      ) : null}
      <div className="flex items-start justify-between gap-2">
        <div className="text-[10px] uppercase tracking-wider text-brand-cyan">
          {product.category?.name ?? "Product"}
        </div>
        <div className="flex gap-1">
          {product.featured ? <Star className="h-3.5 w-3.5 text-amber-400" aria-label="Featured" /> : null}
          {product.trending ? <Sparkles className="h-3.5 w-3.5 text-brand-cyan" aria-label="Trending" /> : null}
          {product.popular ? <Flame className="h-3.5 w-3.5 text-pink-400" aria-label="Popular" /> : null}
        </div>
      </div>
      <h3 className="mt-2 font-display text-lg font-semibold tracking-tight">{product.title}</h3>
      <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
        {product.description}
      </p>
      <div className="mt-5 flex items-center justify-between">
        <div className="font-display text-xl font-semibold">
          {product.currency === "INR" ? "₹" : `${product.currency} `}
          {Number(product.price).toLocaleString()}
        </div>
        <span className="inline-flex items-center gap-1 text-xs text-brand-cyan group-hover:translate-x-0.5 transition-transform">
          View <ArrowUpRight className="h-3 w-3" />
        </span>
      </div>
    </Link>
  );
}
