import type { LucideIcon } from "lucide-react";
import { Spotlight } from "@/components/effects/Spotlight";
import { TiltCard } from "@/components/effects/TiltCard";

const accentMap: Record<string, string> = {
  blue: "from-brand-blue/40 to-brand-blue/0 text-brand-blue",
  cyan: "from-brand-cyan/40 to-brand-cyan/0 text-brand-cyan",
  violet: "from-brand-violet/40 to-brand-violet/0 text-brand-violet",
  pink: "from-brand-pink/40 to-brand-pink/0 text-brand-pink",
};

const glowMap: Record<string, string> = {
  blue: "oklch(0.65 0.21 255 / 0.45)",
  cyan: "oklch(0.82 0.16 200 / 0.45)",
  violet: "oklch(0.66 0.24 295 / 0.45)",
  pink: "oklch(0.72 0.22 340 / 0.45)",
};

/**
 * Premium glass card with mouse-tracking spotlight, 3D tilt, multi-layer glow,
 * gradient accent icon and animated icon ring.
 */
export function FeatureCard({
  icon: Icon,
  title,
  description,
  accent = "blue",
  footer,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  accent?: "blue" | "cyan" | "violet" | "pink";
  footer?: React.ReactNode;
}) {
  const cls = accentMap[accent] ?? accentMap.blue;
  const glow = glowMap[accent] ?? glowMap.blue;
  return (
    <TiltCard className="h-full">
      <div className="group relative h-full overflow-hidden rounded-2xl glass p-6 tilt-card">
        {/* Layered ambient glow on hover */}
        <div
          className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background: `radial-gradient(80% 60% at 50% 0%, ${glow}, transparent 65%)`,
          }}
        />
        <Spotlight />

        {/* Icon with glow ring */}
        <div className="relative mb-5 inline-flex">
          <div
            className={`relative inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${cls} ring-1 ring-white/10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3`}
          >
            <Icon className="h-5 w-5 transition-transform duration-500 group-hover:scale-110" />
          </div>
          <div
            className="pointer-events-none absolute inset-0 rounded-xl opacity-0 blur-xl transition-opacity duration-500 group-hover:opacity-80"
            style={{ background: glow }}
          />
        </div>

        <h3 className="font-display text-lg font-semibold tracking-tight">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>
        {footer && <div className="mt-4">{footer}</div>}

        {/* Gradient border on hover */}
        <div className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100">
          <div className="absolute inset-0 rounded-2xl [background:linear-gradient(135deg,oklch(0.78_0.18_250/0.5),transparent_40%,oklch(0.75_0.22_295/0.5))_border-box] [mask:linear-gradient(#000_0_0)_padding-box,linear-gradient(#000_0_0)] [mask-composite:exclude] p-px" />
        </div>
      </div>
    </TiltCard>
  );
}
