import { Link } from "@tanstack/react-router";
import { ArrowRight, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trackEvent } from "@/lib/analytics/track";
import { useSiteSettings } from "@/lib/cms/settings";
import { submitPublicLead } from "@/lib/cms/crm";

/**
 * Reusable bottom-of-page CTA strip. Glassy, glow, two CTAs.
 * The WhatsApp button also records a soft lead so the CRM can track
 * outbound interest from the strip.
 */
export function CtaStrip({
  title = "Have a project in mind?",
  description = "Tell us about your idea — we typically respond within a few hours.",
}: {
  title?: string;
  description?: string;
}) {
  const settings = useSiteSettings();
  return (
    <section className="container mx-auto px-4 py-24">
      <div className="relative overflow-hidden rounded-3xl glass-strong p-10 sm:p-14">
        <div className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[60%] -translate-x-1/2 rounded-full bg-brand-blue/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 right-0 h-72 w-[40%] rounded-full bg-brand-violet/25 blur-3xl" />
        <div className="relative flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <div className="max-w-xl">
            <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
              {title}
            </h2>
            <p className="mt-3 text-muted-foreground">{description}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="hero" size="lg">
              <Link
                to="/contact"
                onClick={() => trackEvent("cta_click", { cta: "start_project", location: title })}
              >
                Start a project <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="glass" size="lg">
              <a
                href={settings.contact.whatsappLink}
                target="_blank"
                rel="noreferrer"
                onClick={() => {
                  trackEvent("cta_click", { cta: "whatsapp", location: title });
                  // Soft-lead capture so we can track WhatsApp interest in CRM.
                  submitPublicLead({
                    name: "WhatsApp click",
                    email: "whatsapp@webstudiokkr.in",
                    message: `WhatsApp click from CTA: ${title}`,
                    source: `whatsapp:${location.pathname}`,
                    metadata: { kind: "soft_lead", pathname: location.pathname },
                  }).catch(() => {});
                }}
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp us
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
