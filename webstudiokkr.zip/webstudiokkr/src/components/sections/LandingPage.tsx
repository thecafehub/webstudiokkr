import type { LucideIcon } from "lucide-react";
import { CheckCircle2 } from "lucide-react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { Spotlight } from "@/components/effects/Spotlight";
import { InquiryButtons } from "@/components/inquiry/InquiryButtons";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export type LandingPageProps = {
  eyebrow: string;
  title: string;
  highlight: string;
  description: string;
  heroIcon?: LucideIcon;
  intro: string;
  features: { title: string; description: string; icon: LucideIcon }[];
  benefits: string[];
  faqs: { q: string; a: string }[];
  inquirySource: string;
  inquiryTitle?: string;
  ctaTitle?: string;
  ctaDescription?: string;
};

/**
 * Shared layout for SEO landing pages — hero, feature grid, benefits list,
 * FAQ accordion and inquiry CTAs. Maintains the studio's glassmorphism /
 * aurora aesthetic.
 */
export function LandingPage({
  eyebrow,
  title,
  highlight,
  description,
  intro,
  features,
  benefits,
  faqs,
  inquirySource,
  inquiryTitle,
  ctaTitle,
  ctaDescription,
}: LandingPageProps) {
  const inquiryContext = {
    source: inquirySource,
    productTitle: inquiryTitle,
  };

  return (
    <SiteLayout>
      <PageHero eyebrow={eyebrow} title={title} highlight={highlight} description={description}>
        <InquiryButtons context={inquiryContext} size="lg" />
      </PageHero>

      <section className="container mx-auto max-w-4xl px-4 pb-12 text-center">
        <p className="mx-auto text-base leading-relaxed text-muted-foreground md:text-lg">{intro}</p>
      </section>

      <section className="container mx-auto px-4 pb-12">
        <h2 className="mb-8 text-center font-display text-2xl font-semibold tracking-tight md:text-3xl">
          What you get
        </h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div
                key={f.title}
                className="group relative overflow-hidden rounded-2xl glass p-6 hover-lift animate-fade-up"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <Spotlight />
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-brand-blue/30 via-brand-cyan/30 to-brand-violet/30">
                  <Icon className="h-5 w-5 text-brand-cyan" />
                </span>
                <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {benefits.length > 0 ? (
        <section className="container mx-auto max-w-3xl px-4 pb-16">
          <div className="rounded-3xl glass p-8 sm:p-10">
            <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
              Why teams choose us
            </h2>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {benefits.map((b) => (
                <li key={b} className="flex items-start gap-2.5 text-sm text-foreground/90">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      ) : null}

      {faqs.length > 0 ? (
        <section className="container mx-auto max-w-3xl px-4 pb-20">
          <h2 className="mb-6 font-display text-2xl font-semibold tracking-tight md:text-3xl">
            Frequently asked questions
          </h2>
          <div className="rounded-2xl glass p-2 sm:p-4">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((f, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="text-left text-sm md:text-base">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {f.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      ) : null}

      <CtaStrip
        title={ctaTitle ?? "Ready to start?"}
        description={ctaDescription ?? "Chat with us on WhatsApp or Telegram for a fast, no-pressure quote."}
      />
    </SiteLayout>
  );
}
