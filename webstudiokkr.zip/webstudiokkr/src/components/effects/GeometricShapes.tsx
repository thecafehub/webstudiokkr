/**
 * Floating, slowly drifting 3D-feeling geometric shapes for hero backgrounds.
 * Pure CSS — no canvas, no library. Cheap on the GPU.
 */
export function GeometricShapes({ className = "" }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}
    >
      {/* Big blurred orbs */}
      <div
        className="animate-float absolute -left-24 top-12 h-72 w-72 rounded-full opacity-60 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 30% 30%, oklch(0.65 0.21 255 / 0.55), transparent 70%)",
          animationDuration: "12s",
        }}
      />
      <div
        className="animate-float absolute right-[-6rem] top-32 h-80 w-80 rounded-full opacity-60 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 60% 40%, oklch(0.66 0.24 295 / 0.5), transparent 70%)",
          animationDuration: "14s",
          animationDelay: "-3s",
        }}
      />
      <div
        className="animate-float absolute bottom-0 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full opacity-50 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, oklch(0.82 0.16 200 / 0.4), transparent 70%)",
          animationDuration: "16s",
          animationDelay: "-6s",
        }}
      />

      {/* Geometric primitives */}
      <div
        className="animate-float absolute left-[8%] top-[28%] hidden h-20 w-20 rotate-12 rounded-2xl border border-white/15 backdrop-blur-md sm:block"
        style={{
          background: "linear-gradient(135deg, oklch(0.65 0.21 255 / 0.25), oklch(0.66 0.24 295 / 0.1))",
          boxShadow: "0 30px 80px -20px oklch(0.65 0.21 255 / 0.4)",
          animationDuration: "10s",
        }}
      />
      <div
        className="animate-float absolute right-[10%] top-[18%] hidden h-14 w-14 -rotate-12 rounded-xl border border-white/15 backdrop-blur-md sm:block"
        style={{
          background: "linear-gradient(135deg, oklch(0.82 0.16 200 / 0.3), oklch(0.65 0.21 255 / 0.1))",
          boxShadow: "0 30px 80px -20px oklch(0.82 0.16 200 / 0.4)",
          animationDuration: "9s",
          animationDelay: "-2s",
        }}
      />
      <div
        className="animate-float absolute right-[18%] bottom-[18%] hidden h-16 w-16 rotate-45 rounded-md border border-white/15 backdrop-blur-md sm:block"
        style={{
          background: "linear-gradient(135deg, oklch(0.66 0.24 295 / 0.28), oklch(0.72 0.22 340 / 0.1))",
          boxShadow: "0 30px 80px -20px oklch(0.66 0.24 295 / 0.4)",
          animationDuration: "11s",
          animationDelay: "-4s",
        }}
      />
      <div
        className="animate-float absolute left-[18%] bottom-[22%] hidden h-10 w-10 rounded-full border border-white/20 sm:block"
        style={{
          background: "radial-gradient(circle, oklch(0.82 0.16 200 / 0.6), transparent 70%)",
          animationDuration: "8s",
          animationDelay: "-1s",
        }}
      />
    </div>
  );
}
