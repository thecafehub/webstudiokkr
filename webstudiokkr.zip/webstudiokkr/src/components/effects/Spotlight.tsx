import { useEffect, useRef } from "react";

/**
 * Mouse-tracking spotlight. Wrap any section in a relative container, drop
 * <Spotlight /> inside. Uses CSS variables to avoid React re-renders.
 */
export function Spotlight({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const parent = el.parentElement;
    if (!parent) return;

    const onMove = (e: MouseEvent) => {
      const r = parent.getBoundingClientRect();
      el.style.setProperty("--mx", `${e.clientX - r.left}px`);
      el.style.setProperty("--my", `${e.clientY - r.top}px`);
      el.style.setProperty("--opacity", "1");
    };
    const onLeave = () => el.style.setProperty("--opacity", "0");

    parent.addEventListener("mousemove", onMove);
    parent.addEventListener("mouseleave", onLeave);
    return () => {
      parent.removeEventListener("mousemove", onMove);
      parent.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className={`pointer-events-none absolute inset-0 transition-opacity duration-300 ${className}`}
      style={{
        opacity: "var(--opacity, 0)",
        background:
          "radial-gradient(420px circle at var(--mx, 50%) var(--my, 50%), oklch(0.78 0.18 250 / 0.18), transparent 60%)",
      }}
    />
  );
}
