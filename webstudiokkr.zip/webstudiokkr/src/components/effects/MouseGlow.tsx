import { useEffect, useRef } from "react";

/**
 * Large interactive mouse-follow radial glow.
 * Tracks the parent container; uses CSS vars so React never re-renders.
 * Drop inside a `relative overflow-hidden` parent.
 */
export function MouseGlow({
  size = 720,
  color = "oklch(0.78 0.18 250 / 0.28)",
  className = "",
}: {
  size?: number;
  color?: string;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const parent = el.parentElement;
    if (!parent) return;

    let raf = 0;
    const onMove = (e: MouseEvent) => {
      const r = parent.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        el.style.setProperty("--gx", `${x}px`);
        el.style.setProperty("--gy", `${y}px`);
        el.style.setProperty("--go", "1");
      });
    };
    const onLeave = () => el.style.setProperty("--go", "0");

    parent.addEventListener("mousemove", onMove);
    parent.addEventListener("mouseleave", onLeave);
    return () => {
      parent.removeEventListener("mousemove", onMove);
      parent.removeEventListener("mouseleave", onLeave);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className={`pointer-events-none absolute inset-0 z-0 transition-opacity duration-500 ${className}`}
      style={{
        opacity: "var(--go, 0)",
        background: `radial-gradient(${size}px circle at var(--gx, 50%) var(--gy, 30%), ${color}, transparent 65%)`,
      }}
    />
  );
}
