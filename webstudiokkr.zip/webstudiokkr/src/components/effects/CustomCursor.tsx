import { useEffect, useRef, useState } from "react";

/**
 * Premium Windows-style arrow cursor — desktop only.
 * Familiar pointer shape with a soft blue-violet neon glow and click ripple.
 */
type Ripple = { id: number; x: number; y: number };

export function CustomCursor() {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const rafRef = useRef<number | null>(null);

  const target = useRef({ x: -200, y: -200 });
  const pos = useRef({ x: -200, y: -200 });

  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [ripples, setRipples] = useState<Ripple[]>([]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const isTouch =
      window.matchMedia("(hover: none), (pointer: coarse)").matches ||
      "ontouchstart" in window;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (isTouch || reduced) return;

    setEnabled(true);
    document.documentElement.classList.add("custom-cursor-active");

    const onMove = (e: PointerEvent) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
    };

    const interactiveSelector =
      'a, button, [role="button"], input, textarea, select, label, summary, [data-cursor="hover"], [contenteditable="true"]';

    const onOver = (e: Event) => {
      const t = e.target as HTMLElement | null;
      if (t && t.closest?.(interactiveSelector)) setHovering(true);
    };
    const onOut = (e: Event) => {
      const t = e.target as HTMLElement | null;
      if (t && t.closest?.(interactiveSelector)) setHovering(false);
    };

    const onDown = (e: PointerEvent) => {
      setPressed(true);
      const id = Date.now() + Math.random();
      const rx = e.clientX;
      const ry = e.clientY;
      setRipples((r) => [...r, { id, x: rx, y: ry }]);
      window.setTimeout(() => {
        setRipples((r) => r.filter((rp) => rp.id !== id));
      }, 550);
    };
    const onUp = () => setPressed(false);
    const onLeave = () => {
      target.current.x = -200;
      target.current.y = -200;
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerdown", onDown, { passive: true });
    window.addEventListener("pointerup", onUp, { passive: true });
    window.addEventListener("pointerleave", onLeave, { passive: true });
    document.addEventListener("pointerover", onOver, true);
    document.addEventListener("pointerout", onOut, true);

    pos.current = { ...target.current };

    const tick = () => {
      pos.current.x += (target.current.x - pos.current.x) * 0.5;
      pos.current.y += (target.current.y - pos.current.y) * 0.5;
      if (wrapRef.current) {
        wrapRef.current.style.transform = `translate3d(${pos.current.x}px, ${pos.current.y}px, 0)`;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointerleave", onLeave);
      document.removeEventListener("pointerover", onOver, true);
      document.removeEventListener("pointerout", onOut, true);
      document.documentElement.classList.remove("custom-cursor-active");
    };
  }, []);

  if (!enabled) return null;

  const scale = pressed ? 0.92 : hovering ? 1.12 : 1;
  const glow = hovering
    ? "drop-shadow(0 0 6px rgba(167,139,250,0.95)) drop-shadow(0 0 14px rgba(96,165,250,0.7)) drop-shadow(0 0 24px rgba(139,92,246,0.45))"
    : "drop-shadow(0 0 4px rgba(167,139,250,0.75)) drop-shadow(0 0 10px rgba(96,165,250,0.45)) drop-shadow(0 0 18px rgba(139,92,246,0.28))";

  return (
    <>
      {/* Arrow pointer */}
      <div
        ref={wrapRef}
        aria-hidden
        className="pointer-events-none fixed left-0 top-0 z-[9999] hidden md:block"
        style={{
          transform: "translate3d(-200px,-200px,0)",
          willChange: "transform",
        }}
      >
        <div
          style={{
            transform: `scale(${scale})`,
            transformOrigin: "2px 2px",
            transition: "transform 160ms cubic-bezier(.2,.8,.2,1), filter 220ms ease",
            filter: glow,
          }}
        >
          <svg
            width="22"
            height="22"
            viewBox="0 0 22 22"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            style={{ display: "block" }}
          >
            <defs>
              <linearGradient id="cur-fill" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.98" />
                <stop offset="60%" stopColor="#e9e6ff" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#c4b5fd" stopOpacity="0.9" />
              </linearGradient>
              <linearGradient id="cur-stroke" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#a78bfa" />
                <stop offset="100%" stopColor="#60a5fa" />
              </linearGradient>
            </defs>
            {/* Classic arrow pointer path */}
            <path
              d="M2 1.5 L2 16.5 L6.2 12.8 L8.8 18.6 L11.2 17.6 L8.6 11.9 L14 11.6 Z"
              fill="url(#cur-fill)"
              stroke="url(#cur-stroke)"
              strokeWidth="1"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>

      {/* Click ripples */}
      {ripples.map((r) => (
        <div
          key={r.id}
          aria-hidden
          className="pointer-events-none fixed left-0 top-0 z-[9998] hidden md:block"
          style={{
            transform: `translate3d(${r.x}px, ${r.y}px, 0) translate(-50%, -50%)`,
            width: 12,
            height: 12,
            borderRadius: "9999px",
            border: "1.5px solid rgba(167,139,250,0.9)",
            boxShadow:
              "0 0 12px rgba(139,92,246,0.6), 0 0 24px rgba(96,165,250,0.35)",
            animation: "cursor-ripple 520ms cubic-bezier(.2,.8,.2,1) forwards",
          }}
        />
      ))}

      <style>{`
        html.custom-cursor-active,
        html.custom-cursor-active body,
        html.custom-cursor-active a,
        html.custom-cursor-active button,
        html.custom-cursor-active [role="button"],
        html.custom-cursor-active input,
        html.custom-cursor-active textarea,
        html.custom-cursor-active select,
        html.custom-cursor-active label {
          cursor: none !important;
        }
        @media (hover: none), (pointer: coarse) {
          html.custom-cursor-active, html.custom-cursor-active * { cursor: auto !important; }
        }
        @keyframes cursor-ripple {
          0%   { width: 10px; height: 10px; opacity: 0.9; }
          100% { width: 70px; height: 70px; opacity: 0; }
        }
      `}</style>
    </>
  );
}

export default CustomCursor;
