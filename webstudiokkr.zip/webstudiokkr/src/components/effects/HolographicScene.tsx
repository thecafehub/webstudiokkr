import { useEffect, useRef } from "react";

/**
 * Premium desktop-only holographic 3D scene.
 * Pure CSS transforms — cubes, rings, energy spheres — with mouse-driven
 * parallax across multiple depth layers. Disabled on small screens to keep
 * mobile performance pristine.
 */
export function HolographicScene({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(max-width: 1023px)").matches) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let raf = 0;
    const onMove = (e: MouseEvent) => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const px = (e.clientX / w - 0.5) * 2; // -1..1
      const py = (e.clientY / h - 0.5) * 2;
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        el.style.setProperty("--px", px.toFixed(3));
        el.style.setProperty("--py", py.toFixed(3));
      });
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}
      style={
        {
          perspective: "1400px",
          perspectiveOrigin: "50% 40%",
          ["--px" as string]: "0",
          ["--py" as string]: "0",
        } as React.CSSProperties
      }
    >
      {/* Glass cube — left */}
      <div
        className="absolute left-[6%] top-[18%] hidden lg:block"
        style={{
          transform:
            "translate3d(calc(var(--px) * -34px), calc(var(--py) * -24px), 0)",
          transition: "transform 0.4s cubic-bezier(0.2,0.8,0.2,1)",
        }}
      >
        <Cube size={120} />
      </div>

      {/* Glass cube — right */}
      <div
        className="absolute right-[8%] top-[12%] hidden lg:block"
        style={{
          transform:
            "translate3d(calc(var(--px) * 28px), calc(var(--py) * -20px), 0) rotate(8deg)",
          transition: "transform 0.4s cubic-bezier(0.2,0.8,0.2,1)",
        }}
      >
        <Cube size={88} hue="cyan" delay={-2} />
      </div>


      {/* Energy spheres */}
      <div
        className="absolute right-[6%] top-[40%] hidden lg:block"
        style={{
          transform:
            "translate3d(calc(var(--px) * 48px), calc(var(--py) * 28px), 0)",
          transition: "transform 0.45s cubic-bezier(0.2,0.8,0.2,1)",
        }}
      >
        <EnergySphere size={140} />
      </div>
      <div
        className="absolute left-[10%] top-[55%] hidden xl:block"
        style={{
          transform:
            "translate3d(calc(var(--px) * -36px), calc(var(--py) * 22px), 0)",
          transition: "transform 0.45s cubic-bezier(0.2,0.8,0.2,1)",
        }}
      >
        <EnergySphere size={90} hue="cyan" delay={-3} />
      </div>
    </div>
  );
}

/* ─── Glass cube ─────────────────────────────────────────── */
function Cube({
  size = 110,
  hue = "blue",
  delay = 0,
}: {
  size?: number;
  hue?: "blue" | "cyan" | "violet";
  delay?: number;
}) {
  const tint = {
    blue: "oklch(0.65 0.21 255 / 0.45)",
    cyan: "oklch(0.82 0.16 200 / 0.45)",
    violet: "oklch(0.66 0.24 295 / 0.45)",
  }[hue];
  const tint2 = {
    blue: "oklch(0.65 0.21 255 / 0.18)",
    cyan: "oklch(0.82 0.16 200 / 0.18)",
    violet: "oklch(0.66 0.24 295 / 0.18)",
  }[hue];
  const s = size;
  const half = s / 2;
  const faces: Array<[string, React.CSSProperties]> = [
    ["F", { transform: `translateZ(${half}px)` }],
    ["B", { transform: `rotateY(180deg) translateZ(${half}px)` }],
    ["R", { transform: `rotateY(90deg) translateZ(${half}px)` }],
    ["L", { transform: `rotateY(-90deg) translateZ(${half}px)` }],
    ["T", { transform: `rotateX(90deg) translateZ(${half}px)` }],
    ["U", { transform: `rotateX(-90deg) translateZ(${half}px)` }],
  ];
  return (
    <div
      style={{
        width: s,
        height: s,
        transformStyle: "preserve-3d",
        animation: `spin3d 22s linear infinite`,
        animationDelay: `${delay}s`,
        filter: `drop-shadow(0 30px 60px ${tint})`,
      }}
    >
      {faces.map(([k, st]) => (
        <div
          key={k}
          className="absolute inset-0 rounded-xl border border-white/15 backdrop-blur-md"
          style={{
            ...st,
            background: `linear-gradient(135deg, ${tint}, ${tint2})`,
            boxShadow: `inset 0 0 30px ${tint2}, inset 0 0 0 1px oklch(1 0 0 / 0.08)`,
          }}
        />
      ))}
    </div>
  );
}


/* ─── Energy sphere ──────────────────────────────────────── */
function EnergySphere({
  size = 140,
  hue = "violet",
  delay = 0,
}: {
  size?: number;
  hue?: "violet" | "cyan" | "blue";
  delay?: number;
}) {
  const a = {
    violet: ["oklch(0.66 0.24 295 / 0.8)", "oklch(0.72 0.22 340 / 0.4)"],
    cyan: ["oklch(0.82 0.16 200 / 0.8)", "oklch(0.65 0.21 255 / 0.4)"],
    blue: ["oklch(0.65 0.21 255 / 0.8)", "oklch(0.66 0.24 295 / 0.4)"],
  }[hue];
  return (
    <div
      style={{
        width: size,
        height: size,
        animation: `floatY 9s ease-in-out infinite`,
        animationDelay: `${delay}s`,
        filter: `drop-shadow(0 25px 50px ${a[0]})`,
      }}
    >
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: `radial-gradient(circle at 30% 30%, oklch(1 0 0 / 0.4), ${a[0]} 35%, ${a[1]} 70%, transparent 100%)`,
        }}
      />
      <div
        className="absolute inset-0 rounded-full mix-blend-screen"
        style={{
          background: `radial-gradient(circle at 70% 70%, ${a[1]}, transparent 60%)`,
          animation: `pulse-glow 4s ease-in-out infinite`,
        }}
      />
    </div>
  );
}
