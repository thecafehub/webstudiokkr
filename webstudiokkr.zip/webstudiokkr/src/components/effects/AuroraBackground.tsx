/**
 * Fixed, layered aurora background — radial gradients + animated drift +
 * subtle grid. Sits behind every page (z-0). Pure CSS, GPU-friendly.
 */
export function AuroraBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Base */}
      <div className="absolute inset-0 bg-background" />

      {/* Aurora blobs */}
      <div className="absolute inset-0 bg-aurora animate-aurora" />

      {/* Floating orbs */}
      <div className="absolute -top-32 -left-32 h-[480px] w-[480px] rounded-full bg-brand-blue/25 blur-[120px] animate-float" />
      <div
        className="absolute top-1/3 -right-32 h-[520px] w-[520px] rounded-full bg-brand-violet/25 blur-[140px] animate-float"
        style={{ animationDelay: "-3s" }}
      />
      <div
        className="absolute bottom-0 left-1/3 h-[420px] w-[420px] rounded-full bg-brand-cyan/20 blur-[120px] animate-float"
        style={{ animationDelay: "-6s" }}
      />

      {/* Grid */}
      <div className="absolute inset-0 bg-grid opacity-60 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />

      {/* Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_50%,oklch(0.08_0.02_270)_100%)]" />
    </div>
  );
}
