import { Activity, Sparkles, TrendingUp, Zap } from "lucide-react";

/**
 * Desktop-only floating dashboard mock widgets around the hero. Each card
 * gets its own depth, hue, and float animation — gives the hero a strong
 * "premium SaaS" feeling without any real data.
 */
export function FloatingWidgets() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 hidden lg:block"
      style={{ perspective: "1600px", perspectiveOrigin: "50% 50%" }}
    >
      {/* Live deploys widget — top left */}
      <Card
        className="left-[3%] top-[18%]"
        rotate="rotateY(14deg) rotateX(6deg)"
        delay={0}
      >
        <Row>
          <IconBadge hue="blue">
            <Activity className="h-3.5 w-3.5" />
          </IconBadge>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Deploys / 24h
          </span>
        </Row>
        <p className="mt-2 font-display text-2xl font-bold gradient-brand-text">
          247
        </p>
        <Sparkline color="oklch(0.65 0.21 255 / 0.9)" />
      </Card>

      {/* Conversion widget — top right */}
      <Card
        className="right-[4%] top-[14%]"
        rotate="rotateY(-14deg) rotateX(6deg)"
        delay={-2}
      >
        <Row>
          <IconBadge hue="cyan">
            <TrendingUp className="h-3.5 w-3.5" />
          </IconBadge>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Conv. rate
          </span>
        </Row>
        <p className="mt-2 font-display text-2xl font-bold gradient-brand-text">
          +38.2%
        </p>
        <Sparkline color="oklch(0.82 0.16 200 / 0.9)" reverse />
      </Card>

      {/* Bot status widget — bottom left */}
      <Card
        className="left-[5%] bottom-[10%]"
        rotate="rotateY(18deg) rotateX(-4deg)"
        delay={-4}
      >
        <Row>
          <IconBadge hue="violet">
            <Zap className="h-3.5 w-3.5" />
          </IconBadge>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Bots online
          </span>
        </Row>
        <div className="mt-2 flex items-baseline gap-1.5">
          <p className="font-display text-2xl font-bold gradient-brand-text">12</p>
          <span className="text-[10px] text-brand-cyan">● live</span>
        </div>
        <div className="mt-2 grid grid-cols-12 gap-0.5">
          {Array.from({ length: 12 }).map((_, i) => (
            <span
              key={i}
              className="h-1.5 rounded-sm"
              style={{
                background:
                  i < 11
                    ? "oklch(0.66 0.24 295 / 0.85)"
                    : "oklch(1 0 0 / 0.12)",
              }}
            />
          ))}
        </div>
      </Card>

      {/* AI widget — bottom right */}
      <Card
        className="right-[6%] bottom-[14%]"
        rotate="rotateY(-18deg) rotateX(-4deg)"
        delay={-1}
      >
        <Row>
          <IconBadge hue="pink">
            <Sparkles className="h-3.5 w-3.5" />
          </IconBadge>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            AI tasks
          </span>
        </Row>
        <p className="mt-2 font-display text-2xl font-bold gradient-brand-text">
          1,284
        </p>
        <div className="mt-2 h-1.5 w-full rounded-full bg-white/10">
          <div
            className="h-full rounded-full"
            style={{
              width: "72%",
              background:
                "linear-gradient(90deg, oklch(0.72 0.22 340 / 0.9), oklch(0.82 0.16 200 / 0.9))",
            }}
          />
        </div>
      </Card>
    </div>
  );
}

function Card({
  children,
  className,
  rotate,
  delay,
}: {
  children: React.ReactNode;
  className: string;
  rotate: string;
  delay: number;
}) {
  return (
    <div
      className={`absolute w-44 ${className}`}
      style={{
        transform: rotate,
        transformStyle: "preserve-3d",
        animation: `floatY 11s ease-in-out infinite`,
        animationDelay: `${delay}s`,
      }}
    >
      <div
        className="rounded-2xl glass-strong p-4 backdrop-blur-xl"
        style={{
          boxShadow:
            "0 30px 80px -20px oklch(0 0 0 / 0.6), 0 0 60px -10px oklch(0.66 0.24 295 / 0.25), 0 0 0 1px oklch(1 0 0 / 0.08)",
        }}
      >
        {children}
      </div>
    </div>
  );
}

function Row({ children }: { children: React.ReactNode }) {
  return <div className="flex items-center gap-2">{children}</div>;
}

function IconBadge({
  children,
  hue,
}: {
  children: React.ReactNode;
  hue: "blue" | "cyan" | "violet" | "pink";
}) {
  const bg = {
    blue: "from-brand-blue/40 to-brand-blue/0 text-brand-blue",
    cyan: "from-brand-cyan/40 to-brand-cyan/0 text-brand-cyan",
    violet: "from-brand-violet/40 to-brand-violet/0 text-brand-violet",
    pink: "from-brand-pink/40 to-brand-pink/0 text-brand-pink",
  }[hue];
  return (
    <span
      className={`inline-flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br ${bg} ring-1 ring-white/10`}
    >
      {children}
    </span>
  );
}

function Sparkline({
  color,
  reverse = false,
}: {
  color: string;
  reverse?: boolean;
}) {
  const pts = reverse
    ? "0,18 12,14 24,16 36,10 48,12 60,6 72,8 84,2"
    : "0,16 12,18 24,10 36,12 48,6 60,8 72,3 84,4";
  return (
    <svg viewBox="0 0 84 22" className="mt-2 h-5 w-full">
      <defs>
        <linearGradient id={`sl-${color}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity="0.5" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline
        points={pts}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polygon points={`${pts} 84,22 0,22`} fill={`url(#sl-${color})`} />
    </svg>
  );
}
