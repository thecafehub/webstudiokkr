import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  FileText,
  Wrench,
  Package,
  Hammer,
  PenSquare,
  Search,
  Image as ImageIcon,
  Users,
  Settings,
  BarChart3,
  LogOut,
  Menu,
  X,
  Sparkles,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminLogout, useAdminAuth, type Permission } from "@/lib/admin/auth";
import { cn } from "@/lib/utils";

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  permission?: Permission;
};

const NAV: NavItem[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { to: "/admin/pages", label: "Pages", icon: FileText, permission: "content" },
  { to: "/admin/services", label: "Services", icon: Wrench, permission: "content" },
  { to: "/admin/products", label: "Products", icon: Package, permission: "content" },
  { to: "/admin/tools", label: "Tools", icon: Hammer, permission: "content" },
  { to: "/admin/blog", label: "Blog", icon: PenSquare, permission: "content" },
  { to: "/admin/seo", label: "SEO Center", icon: Search, permission: "content" },
  { to: "/admin/media", label: "Media Library", icon: ImageIcon, permission: "media" },
  { to: "/admin/leads", label: "CRM / Leads", icon: Users, permission: "crm" },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3, permission: "analytics" },
  { to: "/admin/team", label: "Team & Roles", icon: Shield, permission: "roles" },
  { to: "/admin/settings", label: "Settings", icon: Settings, permission: "settings" },
];

export function AdminShell({
  title,
  children,
  requires,
}: {
  title: string;
  children: ReactNode;
  /** Permission required to view this page. Omit for the dashboard. */
  requires?: Permission;
}) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const auth = useAdminAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    if (auth.ready && !auth.isStaff) {
      navigate({ to: "/admin/login" });
    }
  }, [auth.ready, auth.isStaff, navigate]);

  if (!auth.ready || !auth.isStaff) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-sm text-muted-foreground">
          {auth.ready ? "Redirecting to sign in…" : "Loading admin…"}
        </div>
      </div>
    );
  }

  if (requires && !auth.can(requires)) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-8">
        <div className="max-w-md rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center">
          <Shield className="mx-auto mb-3 h-8 w-8 text-amber-400" />
          <h2 className="font-display text-lg font-semibold">Permission required</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Your role ({auth.roles.join(", ") || "none"}) doesn't allow access to this section.
            Ask an admin to grant you the right role.
          </p>
          <Button asChild variant="outline" className="mt-4">
            <Link to="/admin">Back to dashboard</Link>
          </Button>
        </div>
      </div>
    );
  }

  const visibleNav = NAV.filter((n) => !n.permission || auth.can(n.permission));

  const handleLogout = async () => {
    await adminLogout();
    navigate({ to: "/admin/login" });
  };

  const userLabel = auth.email?.split("@")[0] ?? "admin";
  const primaryRole = auth.isAdmin
    ? "admin"
    : auth.hasRole("manager")
      ? "manager"
      : auth.hasRole("editor")
        ? "editor"
        : "staff";

  return (
    <div className="relative min-h-screen bg-[oklch(0.12_0.04_265)] text-foreground">
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 left-1/4 h-[500px] w-[500px] rounded-full bg-brand-blue/20 blur-[140px]" />
        <div className="absolute bottom-0 right-0 h-[500px] w-[500px] rounded-full bg-brand-violet/20 blur-[140px]" />
      </div>

      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-white/5 bg-background/60 px-4 py-3 backdrop-blur md:hidden">
        <Link to="/admin" className="flex items-center gap-2 font-display font-semibold">
          <Sparkles className="h-4 w-4 text-brand-cyan" />
          Admin
        </Link>
        <button
          onClick={() => setMobileOpen((v) => !v)}
          className="rounded-md border border-white/10 p-2"
        >
          {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>

      <div className="flex">
        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-30 w-64 transform border-r border-white/5 bg-[oklch(0.10_0.04_265)]/90 backdrop-blur-xl transition-transform md:sticky md:top-0 md:h-screen md:translate-x-0",
            mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          )}
        >
          <div className="flex h-full flex-col">
            <div className="hidden items-center gap-2 border-b border-white/5 px-5 py-5 md:flex">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand-blue to-brand-violet">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <div>
                <div className="font-display text-sm font-semibold">Web Studio KKR</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Admin Console
                </div>
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto p-3">
              {visibleNav.map((item) => {
                const active =
                  item.to === "/admin"
                    ? pathname === "/admin"
                    : pathname === item.to || pathname.startsWith(item.to + "/");
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all",
                      active
                        ? "bg-gradient-to-r from-brand-blue/20 to-brand-violet/20 text-foreground shadow-[inset_0_1px_0_oklch(1_0_0/0.08)]"
                        : "text-muted-foreground hover:bg-white/5 hover:text-foreground",
                    )}
                  >
                    <Icon
                      className={cn(
                        "h-4 w-4 transition-colors",
                        active ? "text-brand-cyan" : "text-muted-foreground group-hover:text-foreground",
                      )}
                    />
                    {item.label}
                  </Link>
                );
              })}
            </nav>

            <div className="border-t border-white/5 p-3">
              <button
                onClick={handleLogout}
                className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </button>
            </div>
          </div>
        </aside>

        <div className="min-h-screen flex-1 md:ml-0">
          <header className="sticky top-0 z-20 hidden border-b border-white/5 bg-background/40 backdrop-blur-xl md:block">
            <div className="flex items-center justify-between px-8 py-5">
              <div>
                <h1 className="font-display text-2xl font-semibold tracking-tight">{title}</h1>
                <p className="text-xs text-muted-foreground">
                  Manage every part of your Web Studio KKR platform
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" asChild>
                  <Link to="/">View site</Link>
                </Button>
                <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs">
                  <span className="h-2 w-2 rounded-full bg-emerald-400" />
                  {userLabel}
                  <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                    {primaryRole}
                  </span>
                </div>
              </div>
            </div>
          </header>

          <main className="p-4 md:p-8">
            <div className="md:hidden mb-4">
              <h1 className="font-display text-xl font-semibold">{title}</h1>
            </div>
            {children}
          </main>
        </div>
      </div>
    </div>
  );
}

export function GlassCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-white/[0.07] bg-white/[0.03] p-5 shadow-[0_1px_0_oklch(1_0_0/0.04)_inset,0_20px_60px_-30px_oklch(0_0_0/0.8)] backdrop-blur-xl",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h2 className="font-display text-xl font-semibold tracking-tight">{title}</h2>
        {description ? (
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        ) : null}
      </div>
      {action ? <div className="flex items-center gap-2">{action}</div> : null}
    </div>
  );
}
