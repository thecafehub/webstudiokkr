import type { ReactNode } from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { AuroraBackground } from "@/components/effects/AuroraBackground";

/**
 * Public site shell. Provides aurora background, sticky header, footer.
 * Every public route wraps its body in <SiteLayout>.
 */
export function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <AuroraBackground />
      <Header />
      <main className="relative pt-28">{children}</main>
      <Footer />
    </>
  );
}
