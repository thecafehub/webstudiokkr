import { Link } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Send, MessageCircle, Instagram, Sparkles, ArrowUpRight } from "lucide-react";
import { site, services, productCategories } from "@/config/site";
import { useSiteSettings } from "@/lib/cms/settings";

export function Footer() {
  const settings = useSiteSettings();
  return (
    <footer className="relative mt-32 border-t border-white/5">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-blue/60 to-transparent" />

      <div className="container mx-auto px-4 py-16">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Brand */}
          <div className="lg:col-span-4">
            <Link to="/" className="inline-flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-brand-blue via-brand-cyan to-brand-violet">
                {settings.brand.logoUrl ? (
                  <img src={settings.brand.logoUrl} alt={settings.brand.name} className="h-6 w-6 object-contain" />
                ) : (
                  <Sparkles className="h-5 w-5 text-white" strokeWidth={2.5} />
                )}
              </span>
              <span className="font-display text-lg font-bold tracking-tight">
                {settings.brand.name}
              </span>
            </Link>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
              {settings.brand.description}
            </p>

            <div className="mt-6 space-y-3 text-sm">
              <a href={`mailto:${settings.contact.email}`} className="flex items-center gap-3 text-muted-foreground transition-colors hover:text-foreground">
                <Mail className="h-4 w-4 text-brand-cyan" /> {settings.contact.email}
              </a>
              <a href={`tel:${settings.contact.phone}`} className="flex items-center gap-3 text-muted-foreground transition-colors hover:text-foreground">
                <Phone className="h-4 w-4 text-brand-cyan" /> {settings.contact.phone}
              </a>
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="h-4 w-4 text-brand-cyan" /> {settings.contact.address}
              </div>
            </div>

            <div className="mt-6 flex items-center gap-2">
              <SocialIcon href={settings.contact.whatsappLink} label="WhatsApp">
                <MessageCircle className="h-4 w-4" />
              </SocialIcon>
              <SocialIcon href={settings.contact.telegramLink} label="Telegram">
                <Send className="h-4 w-4" />
              </SocialIcon>
              <SocialIcon href={settings.contact.instagramLink} label="Instagram">
                <Instagram className="h-4 w-4" />
              </SocialIcon>
            </div>
          </div>

          {/* Columns */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-8">
            <FooterColumn title="Studio">
              {site.nav.slice(1).map((n) => (
                <FooterLink key={n.href} to={n.href}>{n.label}</FooterLink>
              ))}
            </FooterColumn>

            <FooterColumn title="Services">
              {services.slice(0, 6).map((s) => (
                <FooterLink key={s.id} to="/services">{s.title}</FooterLink>
              ))}
            </FooterColumn>

            <FooterColumn title="Marketplace">
              {productCategories.slice(0, 6).map((p) => (
                <FooterLink key={p.id} to="/products">{p.title}</FooterLink>
              ))}
            </FooterColumn>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-white/5 pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center">
          <p>
            © {new Date().getFullYear()} {settings.brand.name} · {site.brand.domain}
          </p>
          <p className="flex items-center gap-1.5">
            {settings.footer.tagline}
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-4 text-xs font-semibold uppercase tracking-[0.18em] text-foreground/80">
        {title}
      </h4>
      <ul className="space-y-2.5 text-sm">{children}</ul>
    </div>
  );
}

function FooterLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <li>
      <Link
        to={to}
        className="group inline-flex items-center gap-1 text-muted-foreground transition-colors hover:text-foreground"
      >
        {children}
        <ArrowUpRight className="h-3 w-3 opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" />
      </Link>
    </li>
  );
}

function SocialIcon({ href, label, children }: { href: string; label: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer noopener"
      aria-label={label}
      className="inline-flex h-9 w-9 items-center justify-center rounded-lg glass text-muted-foreground transition-all hover:-translate-y-0.5 hover:text-foreground hover:shadow-[0_0_18px_oklch(0.78_0.18_250/0.35)]"
    >
      {children}
    </a>
  );
}
