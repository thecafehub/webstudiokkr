import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Sparkles } from "lucide-react";
import { site } from "@/config/site";
import { Button } from "@/components/ui/button";
import { useSiteSettings } from "@/lib/cms/settings";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const settings = useSiteSettings();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "py-2" : "py-4"
      }`}
    >
      <div className="container mx-auto px-4">
        <div
          className={`flex items-center justify-between rounded-2xl border px-4 py-2.5 transition-all duration-500 ${
            scrolled
              ? "glass-strong border-white/10 shadow-card"
              : "glass border-white/8"
          }`}
        >
          <Link to="/" className="group flex items-center gap-2.5">
            <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-blue via-brand-cyan to-brand-violet shadow-[0_0_24px_oklch(0.65_0.21_255/0.5)]">
              {settings.brand.logoUrl ? (
                <img src={settings.brand.logoUrl} alt={settings.brand.name} className="h-5 w-5 object-contain" />
              ) : (
                <Sparkles className="h-[18px] w-[18px] text-white" strokeWidth={2.5} />
              )}
            </span>
            <div className="flex flex-col leading-tight">
              <span className="font-display text-[15px] font-bold tracking-tight text-foreground">
                {settings.brand.name}
              </span>
              <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Digital Studio
              </span>
            </div>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {site.nav.map((item) => {
              const active =
                item.href === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={`relative rounded-lg px-3.5 py-2 text-sm font-medium transition-colors ${
                    active
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {item.label}
                  {active && (
                    <span className="absolute inset-x-3 -bottom-px h-px bg-gradient-to-r from-transparent via-brand-cyan to-transparent" />
                  )}
                </Link>
              );
            })}
          </nav>

          <div className="hidden items-center gap-2 lg:flex">
            <Button asChild variant="brand" size="sm">
              <Link to="/contact">Start a project</Link>
            </Button>
          </div>

          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg glass lg:hidden"
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <div className="mt-2 rounded-2xl glass-strong p-3 lg:hidden animate-fade-up">
            <nav className="flex flex-col">
              {site.nav.map((item) => {
                const active =
                  item.href === "/"
                    ? pathname === "/"
                    : pathname.startsWith(item.href);
                return (
                  <Link
                    key={item.href}
                    to={item.href}
                    className={`rounded-lg px-4 py-3 text-sm font-medium transition-colors ${
                      active
                        ? "bg-white/5 text-foreground"
                        : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                    }`}
                  >
                    {item.label}
                  </Link>
                );
              })}
              <Button asChild variant="brand" size="sm" className="mt-2">
                <Link to="/contact">Start a project</Link>
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
