import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Save } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  DEFAULT_SETTINGS,
  loadSiteSettings,
  saveSettingsKey,
  type SiteSettings,
} from "@/lib/cms/settings";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({ meta: [{ title: "Settings — Admin" }, { name: "robots", content: "noindex" }] }),
  component: SettingsManager,
});

function SettingsManager() {
  const qc = useQueryClient();
  const { data: live = DEFAULT_SETTINGS } = useQuery({
    queryKey: ["site-settings"],
    queryFn: loadSiteSettings,
  });

  const [draft, setDraft] = useState<SiteSettings>(live);
  const [savedKey, setSavedKey] = useState<string | null>(null);

  useEffect(() => setDraft(live), [live]);

  const saveMut = useMutation({
    mutationFn: async (key: keyof SiteSettings) => {
      await saveSettingsKey(key, draft[key]);
      return key;
    },
    onSuccess: (key) => {
      setSavedKey(key);
      setTimeout(() => setSavedKey(null), 1500);
      qc.invalidateQueries({ queryKey: ["site-settings"] });
    },
  });

  return (
    <AdminShell title="Website Settings" requires="settings">
      <PageHeader
        title="Website settings"
        description="Everything that appears across the public site — brand identity, contact details, hero copy, homepage stats, CTA buttons, footer. Saved per section."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Brand */}
        <SectionCard
          title="Brand"
          onSave={() => saveMut.mutate("brand")}
          saved={savedKey === "brand"}
        >
          <Field label="Brand name">
            <Input
              value={draft.brand.name}
              onChange={(e) =>
                setDraft({ ...draft, brand: { ...draft.brand, name: e.target.value } })
              }
            />
          </Field>
          <Field label="Tagline">
            <Input
              value={draft.brand.tagline}
              onChange={(e) =>
                setDraft({ ...draft, brand: { ...draft.brand, tagline: e.target.value } })
              }
            />
          </Field>
          <Field label="Description (used in OG / about)">
            <Textarea
              rows={3}
              value={draft.brand.description}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  brand: { ...draft.brand, description: e.target.value },
                })
              }
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Logo URL">
              <Input
                value={draft.brand.logoUrl}
                onChange={(e) =>
                  setDraft({ ...draft, brand: { ...draft.brand, logoUrl: e.target.value } })
                }
                placeholder="/logo.svg or https://…"
              />
            </Field>
            <Field label="Favicon URL">
              <Input
                value={draft.brand.faviconUrl}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    brand: { ...draft.brand, faviconUrl: e.target.value },
                  })
                }
              />
            </Field>
          </div>
        </SectionCard>

        {/* Contact */}
        <SectionCard
          title="Contact"
          onSave={() => saveMut.mutate("contact")}
          saved={savedKey === "contact"}
        >
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="Email">
              <Input
                value={draft.contact.email}
                onChange={(e) =>
                  setDraft({ ...draft, contact: { ...draft.contact, email: e.target.value } })
                }
              />
            </Field>
            <Field label="Phone">
              <Input
                value={draft.contact.phone}
                onChange={(e) =>
                  setDraft({ ...draft, contact: { ...draft.contact, phone: e.target.value } })
                }
              />
            </Field>
            <Field label="WhatsApp number (digits)">
              <Input
                value={draft.contact.whatsapp}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, whatsapp: e.target.value },
                  })
                }
              />
            </Field>
            <Field label="WhatsApp link">
              <Input
                value={draft.contact.whatsappLink}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, whatsappLink: e.target.value },
                  })
                }
                placeholder="https://wa.me/…"
              />
            </Field>
            <Field label="Telegram handle">
              <Input
                value={draft.contact.telegram}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, telegram: e.target.value },
                  })
                }
              />
            </Field>
            <Field label="Telegram link">
              <Input
                value={draft.contact.telegramLink}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, telegramLink: e.target.value },
                  })
                }
              />
            </Field>
            <Field label="Instagram handle">
              <Input
                value={draft.contact.instagram}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, instagram: e.target.value },
                  })
                }
              />
            </Field>
            <Field label="Instagram link">
              <Input
                value={draft.contact.instagramLink}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, instagramLink: e.target.value },
                  })
                }
              />
            </Field>
            <Field label="Studio address">
              <Input
                value={draft.contact.address}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    contact: { ...draft.contact, address: e.target.value },
                  })
                }
              />
            </Field>
          </div>
        </SectionCard>

        {/* Hero */}
        <SectionCard
          title="Homepage hero"
          onSave={() => saveMut.mutate("hero")}
          saved={savedKey === "hero"}
        >
          <Field label="Eyebrow">
            <Input
              value={draft.hero.eyebrow}
              onChange={(e) => setDraft({ ...draft, hero: { ...draft.hero, eyebrow: e.target.value } })}
            />
          </Field>
          <Field label="Headline">
            <Input
              value={draft.hero.headline}
              onChange={(e) =>
                setDraft({ ...draft, hero: { ...draft.hero, headline: e.target.value } })
              }
            />
          </Field>
          <Field label="Highlight (gradient text)">
            <Input
              value={draft.hero.highlight}
              onChange={(e) =>
                setDraft({ ...draft, hero: { ...draft.hero, highlight: e.target.value } })
              }
            />
          </Field>
          <Field label="Subcopy">
            <Textarea
              rows={3}
              value={draft.hero.subcopy}
              onChange={(e) =>
                setDraft({ ...draft, hero: { ...draft.hero, subcopy: e.target.value } })
              }
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Primary CTA label">
              <Input
                value={draft.hero.ctaPrimary.label}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    hero: {
                      ...draft.hero,
                      ctaPrimary: { ...draft.hero.ctaPrimary, label: e.target.value },
                    },
                  })
                }
              />
            </Field>
            <Field label="Primary CTA link">
              <Input
                value={draft.hero.ctaPrimary.href}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    hero: {
                      ...draft.hero,
                      ctaPrimary: { ...draft.hero.ctaPrimary, href: e.target.value },
                    },
                  })
                }
              />
            </Field>
            <Field label="Secondary CTA label">
              <Input
                value={draft.hero.ctaSecondary.label}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    hero: {
                      ...draft.hero,
                      ctaSecondary: { ...draft.hero.ctaSecondary, label: e.target.value },
                    },
                  })
                }
              />
            </Field>
            <Field label="Secondary CTA link">
              <Input
                value={draft.hero.ctaSecondary.href}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    hero: {
                      ...draft.hero,
                      ctaSecondary: { ...draft.hero.ctaSecondary, href: e.target.value },
                    },
                  })
                }
              />
            </Field>
          </div>
        </SectionCard>

        {/* Stats */}
        <SectionCard
          title="Homepage stats"
          onSave={() => saveMut.mutate("stats")}
          saved={savedKey === "stats"}
        >
          {draft.stats.map((s, i) => (
            <div key={i} className="grid grid-cols-2 gap-3">
              <Field label={`Label ${i + 1}`}>
                <Input
                  value={s.label}
                  onChange={(e) => {
                    const next = [...draft.stats];
                    next[i] = { ...next[i], label: e.target.value };
                    setDraft({ ...draft, stats: next });
                  }}
                />
              </Field>
              <Field label={`Value ${i + 1}`}>
                <Input
                  value={s.value}
                  onChange={(e) => {
                    const next = [...draft.stats];
                    next[i] = { ...next[i], value: e.target.value };
                    setDraft({ ...draft, stats: next });
                  }}
                />
              </Field>
            </div>
          ))}
        </SectionCard>

        {/* Footer */}
        <SectionCard
          title="Footer"
          onSave={() => saveMut.mutate("footer")}
          saved={savedKey === "footer"}
        >
          <Field label="Copyright line">
            <Input
              value={draft.footer.copyright}
              onChange={(e) =>
                setDraft({ ...draft, footer: { ...draft.footer, copyright: e.target.value } })
              }
            />
          </Field>
          <Field label="Tagline">
            <Input
              value={draft.footer.tagline}
              onChange={(e) =>
                setDraft({ ...draft, footer: { ...draft.footer, tagline: e.target.value } })
              }
            />
          </Field>
        </SectionCard>

        {/* Integrations */}
        <SectionCard
          title="Analytics & integrations"
          onSave={() => saveMut.mutate("integrations")}
          saved={savedKey === "integrations"}
        >
          <p className="-mt-2 mb-2 text-xs text-muted-foreground">
            IDs are safe to ship to the browser. Server-only tokens (PSI_API_KEY,
            GA4_ACCESS_TOKEN) are managed in Lovable Cloud secrets.
          </p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="GA4 Measurement ID">
              <Input
                value={draft.integrations.ga4MeasurementId}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    integrations: {
                      ...draft.integrations,
                      ga4MeasurementId: e.target.value,
                    },
                  })
                }
              />
            </Field>
            <Field label="GA4 Property ID">
              <Input
                value={draft.integrations.ga4PropertyId}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    integrations: {
                      ...draft.integrations,
                      ga4PropertyId: e.target.value,
                    },
                  })
                }
              />
            </Field>
            <Field label="Search Console site URL">
              <Input
                value={draft.integrations.gscSiteUrl}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    integrations: {
                      ...draft.integrations,
                      gscSiteUrl: e.target.value,
                    },
                  })
                }
              />
            </Field>
            <Field label="Microsoft Clarity Project ID">
              <Input
                value={draft.integrations.clarityProjectId}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    integrations: {
                      ...draft.integrations,
                      clarityProjectId: e.target.value,
                    },
                  })
                }
              />
            </Field>
          </div>
        </SectionCard>
      </div>
    </AdminShell>
  );
}

function SectionCard({
  title,
  children,
  onSave,
  saved,
}: {
  title: string;
  children: React.ReactNode;
  onSave: () => void;
  saved: boolean;
}) {
  return (
    <GlassCard>
      <div className="mb-4 flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{title}</div>
        <div className="flex items-center gap-2">
          {saved ? <span className="text-xs text-emerald-400">Saved ✓</span> : null}
          <Button size="sm" variant="brand" onClick={onSave}>
            <Save className="h-3.5 w-3.5" /> Save
          </Button>
        </div>
      </div>
      <div className="space-y-4">{children}</div>
    </GlassCard>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
