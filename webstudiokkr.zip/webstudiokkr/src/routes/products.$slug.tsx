import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowUpRight, CheckCircle2, Flame, Loader2, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { ProductCard } from "@/components/sections/ProductCard";
import { InquiryButtons } from "@/components/inquiry/InquiryButtons";
import {
  getProductBySlug,
  listRelatedProducts,
  parseFaqs,
} from "@/lib/cms/queries";
import { site } from "@/config/site";

export const Route = createFileRoute("/products/$slug")({
  head: ({ loaderData }) => {
    const product = loaderData as Awaited<ReturnType<typeof getProductBySlug>> | undefined;
    if (!product) {
      return { meta: [{ title: `Product — ${site.brand.name}` }] };
    }
    const title = product.seo_title || `${product.title} — ${site.brand.name}`;
    const description =
      product.seo_description ||
      product.description ||
      `${product.title} — by ${site.brand.name}.`;

    const productSchema = {
      "@context": "https://schema.org",
      "@type": "Product",
      name: product.title,
      description,
      image: product.image ? [product.image, ...(product.gallery ?? [])] : undefined,
      brand: { "@type": "Brand", name: site.brand.name },
      sku: product.slug,
      category: product.category?.name,
      offers: {
        "@type": "Offer",
        priceCurrency: product.currency || "INR",
        price: Number(product.price),
        availability: "https://schema.org/InStock",
        url: `${site.brand.url}/products/${product.slug}`,
      },
    };

    const faqs = parseFaqs(product.faqs);
    const faqSchema = faqs.length
      ? {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: faqs.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }
      : null;

    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "product" },
        { property: "og:url", content: `${site.brand.url}/products/${product.slug}` },
        ...(product.image
          ? [
              { property: "og:image", content: product.image },
              { name: "twitter:image", content: product.image },
            ]
          : []),
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: `${site.brand.url}/products/${product.slug}` }],
      scripts: [
        { type: "application/ld+json", children: JSON.stringify(productSchema) },
        ...(faqSchema
          ? [{ type: "application/ld+json", children: JSON.stringify(faqSchema) }]
          : []),
      ],
    };
  },
  loader: async ({ params }) => {
    const product = await getProductBySlug(params.slug);
    if (!product) throw notFound();
    return product;
  },
  errorComponent: ({ error }) => (
    <SiteLayout>
      <div className="container mx-auto max-w-2xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-semibold">Couldn't load this product</h1>
        <p className="mt-2 text-sm text-muted-foreground">{(error as Error).message}</p>
      </div>
    </SiteLayout>
  ),
  notFoundComponent: () => (
    <SiteLayout>
      <div className="container mx-auto max-w-2xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-semibold">Product not found</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This product doesn't exist or is no longer available.
        </p>
        <Link
          to="/products"
          className="mt-6 inline-flex items-center gap-1 text-sm text-brand-cyan"
        >
          <ArrowLeft className="h-4 w-4" /> Back to marketplace
        </Link>
      </div>
    </SiteLayout>
  ),
  component: ProductDetailPage,
});

function ProductDetailPage() {
  const initial = Route.useLoaderData();
  const { data: product, isLoading } = useQuery({
    queryKey: ["public", "product", initial.slug],
    queryFn: () => getProductBySlug(initial.slug),
    initialData: initial,
  });

  const relatedQ = useQuery({
    queryKey: ["public", "product", initial.slug, "related"],
    queryFn: () => listRelatedProducts(initial.category_id, initial.id, 4),
  });

  if (isLoading || !product) {
    return (
      <SiteLayout>
        <div className="flex justify-center py-20 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      </SiteLayout>
    );
  }

  const price = `${product.currency === "INR" ? "₹" : product.currency + " "}${Number(
    product.price,
  ).toLocaleString()}`;
  const gallery: string[] = (product.gallery ?? []) as string[];
  const features: string[] = (product.features ?? []) as string[];
  const faqs = parseFaqs(product.faqs);

  return (
    <SiteLayout>
      <section className="container mx-auto max-w-6xl px-4 pb-12 pt-10 md:pt-16">
        <Link
          to="/products"
          className="mb-6 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> All products
        </Link>

        <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
          <ProductGallery
            primary={product.image ?? null}
            gallery={gallery}
            title={product.title}
          />

          <div>
            <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
              {product.category?.name ? (
                <span className="rounded-full bg-white/5 px-2.5 py-1 text-brand-cyan">
                  {product.category.name}
                </span>
              ) : null}
              {product.featured ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-1 text-amber-300">
                  <Star className="h-3 w-3" /> Featured
                </span>
              ) : null}
              {product.trending ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-brand-cyan/10 px-2 py-1 text-brand-cyan">
                  <Sparkles className="h-3 w-3" /> Trending
                </span>
              ) : null}
              {product.popular ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-pink-500/10 px-2 py-1 text-pink-300">
                  <Flame className="h-3 w-3" /> Popular
                </span>
              ) : null}
            </div>

            <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
              {product.title}
            </h1>
            <p className="mt-3 text-sm text-muted-foreground md:text-base">
              {product.description}
            </p>

            <div className="mt-6 flex items-baseline gap-3">
              <div className="font-display text-3xl font-semibold">{price}</div>
              {product.compare_at_price ? (
                <div className="text-sm text-muted-foreground line-through">
                  {product.currency === "INR" ? "₹" : product.currency + " "}
                  {Number(product.compare_at_price).toLocaleString()}
                </div>
              ) : null}
            </div>

            {/* Inquiry CTAs — no payment gateway, WhatsApp + Telegram only */}
            <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                Inquire about this product
              </div>
              <p className="mt-1 text-sm text-foreground/80">
                Chat directly with our team. We'll share scope, timeline and a custom quote.
              </p>
              <div className="mt-4">
                <InquiryButtons
                  context={{
                    source: "product_detail",
                    productId: product.id,
                    productTitle: product.title,
                    productSlug: product.slug,
                    category: product.category?.name,
                  }}
                />
              </div>
              {product.demo_url ? (
                <div className="mt-4">
                  <Button asChild variant="outline" size="sm">
                    <a href={product.demo_url} target="_blank" rel="noopener noreferrer">
                      Live demo <ArrowUpRight className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              ) : null}
            </div>

            {/* Features */}
            {features.length > 0 ? (
              <div className="mt-8">
                <h2 className="font-display text-lg font-semibold">Features</h2>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-foreground/90">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {product.long_description ? (
              <div className="mt-8">
                <h2 className="font-display text-lg font-semibold">Description</h2>
                <div className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">
                  {product.long_description}
                </div>
              </div>
            ) : null}
          </div>
        </div>

        {/* FAQ */}
        {faqs.length > 0 ? (
          <div className="mt-16">
            <h2 className="font-display text-2xl font-semibold tracking-tight">FAQ</h2>
            <div className="mt-4 rounded-2xl glass p-2 sm:p-4">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((f, i) => (
                  <AccordionItem key={i} value={`faq-${i}`}>
                    <AccordionTrigger className="text-left text-sm md:text-base">
                      {f.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                      {f.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        ) : null}

        {/* SEO summary panel — surfaces seo_title/description on-page */}
        {product.seo_title || product.seo_description ? (
          <div className="mt-12 rounded-2xl glass p-6">
            <div className="text-xs uppercase tracking-wider text-brand-cyan">About this listing</div>
            {product.seo_title ? (
              <h3 className="mt-2 font-display text-lg font-semibold">{product.seo_title}</h3>
            ) : null}
            {product.seo_description ? (
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {product.seo_description}
              </p>
            ) : null}
          </div>
        ) : null}

        {/* Related products */}
        {relatedQ.data && relatedQ.data.length > 0 ? (
          <div className="mt-16">
            <h2 className="font-display text-2xl font-semibold tracking-tight">Related products</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              More from {product.category?.name ?? "the marketplace"}.
            </p>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {relatedQ.data.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          </div>
        ) : null}
      </section>

      <CtaStrip
        title="Need a customised version?"
        description="We can tailor any of our marketplace products to your brand and requirements."
      />
    </SiteLayout>
  );
}

function ProductGallery({
  primary,
  gallery,
  title,
}: {
  primary: string | null;
  gallery: string[];
  title: string;
}) {
  const images = useMemo(() => {
    const all: string[] = [];
    if (primary) all.push(primary);
    for (const g of gallery) if (g && !all.includes(g)) all.push(g);
    return all;
  }, [primary, gallery]);
  const [active, setActive] = useState(0);

  if (images.length === 0) {
    return (
      <div>
        <div className="aspect-[4/3] rounded-2xl border border-white/5 bg-gradient-to-br from-brand-blue/20 to-brand-violet/20" />
      </div>
    );
  }

  return (
    <div>
      <div className="overflow-hidden rounded-2xl border border-white/5 bg-white/5">
        <img
          src={images[active]}
          alt={`${title} — view ${active + 1}`}
          className="w-full"
        />
      </div>
      {images.length > 1 ? (
        <div className="mt-4 grid grid-cols-4 gap-2">
          {images.map((src, i) => (
            <button
              key={src + i}
              type="button"
              onClick={() => setActive(i)}
              className={`overflow-hidden rounded-lg border transition-all ${
                active === i
                  ? "border-brand-cyan/60 ring-1 ring-brand-cyan/40"
                  : "border-white/5 hover:border-white/20"
              }`}
              aria-label={`Show screenshot ${i + 1}`}
            >
              <img
                src={src}
                alt={`${title} screenshot ${i + 1}`}
                loading="lazy"
                className="aspect-square w-full object-cover"
              />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
