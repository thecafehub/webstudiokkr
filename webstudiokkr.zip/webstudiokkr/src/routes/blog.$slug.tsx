import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Calendar, Loader2 } from "lucide-react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { Spotlight } from "@/components/effects/Spotlight";
import { getBlogBySlug, listRelatedBlogs } from "@/lib/cms/queries";
import { site } from "@/config/site";

export const Route = createFileRoute("/blog/$slug")({
  head: ({ loaderData }) => {
    const post = loaderData as Awaited<ReturnType<typeof getBlogBySlug>> | undefined;
    if (!post) {
      return { meta: [{ title: `Post — ${site.brand.name}` }] };
    }
    const title = post.seo_title || `${post.title} — ${site.brand.name}`;
    const description =
      post.seo_description || post.excerpt || `${post.title} — read on ${site.brand.name}.`;
    const articleSchema = {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: post.title,
      description,
      image: post.featured_image ? [post.featured_image] : undefined,
      datePublished: post.publish_at,
      dateModified: post.updated_at,
      author: { "@type": "Organization", name: site.brand.name },
      publisher: { "@type": "Organization", name: site.brand.name },
      mainEntityOfPage: `${site.brand.url}/blog/${post.slug}`,
    };
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `${site.brand.url}/blog/${post.slug}` },
        ...(post.featured_image
          ? [
              { property: "og:image", content: post.featured_image },
              { name: "twitter:image", content: post.featured_image },
            ]
          : []),
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: `${site.brand.url}/blog/${post.slug}` }],
      scripts: [{ type: "application/ld+json", children: JSON.stringify(articleSchema) }],
    };
  },
  loader: async ({ params }) => {
    const post = await getBlogBySlug(params.slug);
    if (!post) throw notFound();
    return post;
  },
  errorComponent: ({ error }) => (
    <SiteLayout>
      <div className="container mx-auto max-w-2xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-semibold">Couldn't load this post</h1>
        <p className="mt-2 text-sm text-muted-foreground">{(error as Error).message}</p>
      </div>
    </SiteLayout>
  ),
  notFoundComponent: () => (
    <SiteLayout>
      <div className="container mx-auto max-w-2xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-semibold">Post not found</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          The post you're looking for doesn't exist or hasn't been published yet.
        </p>
        <Link to="/blog" className="mt-6 inline-flex items-center gap-1 text-sm text-brand-cyan">
          <ArrowLeft className="h-4 w-4" /> Back to all posts
        </Link>
      </div>
    </SiteLayout>
  ),
  component: BlogDetailPage,
});

function BlogDetailPage() {
  const initial = Route.useLoaderData();
  const { data: post, isLoading } = useQuery({
    queryKey: ["public", "blog", initial.slug],
    queryFn: () => getBlogBySlug(initial.slug),
    initialData: initial,
  });
  const relatedQ = useQuery({
    queryKey: ["public", "blog", initial.slug, "related"],
    queryFn: () => listRelatedBlogs(initial.category_id, initial.id, 3),
  });

  if (isLoading || !post) {
    return (
      <SiteLayout>
        <div className="flex justify-center py-20 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      </SiteLayout>
    );
  }

  return (
    <SiteLayout>
      <article className="container mx-auto max-w-3xl px-4 pb-12 pt-10 md:pt-16">
        <Link
          to="/blog"
          className="mb-6 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-3 w-3" /> All posts
        </Link>

        <div className="mb-3 flex items-center gap-3 text-xs text-muted-foreground">
          {post.category?.name ? (
            <span className="rounded-full bg-white/5 px-2.5 py-1 text-brand-cyan">
              {post.category.name}
            </span>
          ) : null}
          {post.publish_at ? (
            <span className="inline-flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {new Date(post.publish_at).toLocaleDateString(undefined, {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
            </span>
          ) : null}
          {post.reading_minutes ? <span>· {post.reading_minutes} min read</span> : null}
        </div>

        <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          {post.title}
        </h1>
        {post.excerpt ? (
          <p className="mt-3 text-base text-muted-foreground md:text-lg">{post.excerpt}</p>
        ) : null}

        {post.featured_image ? (
          <div className="mt-8 overflow-hidden rounded-2xl border border-white/5">
            <img
              src={post.featured_image}
              alt={post.title}
              className="w-full"
              loading="lazy"
            />
          </div>
        ) : null}

        <div className="prose prose-invert mt-10 max-w-none whitespace-pre-wrap text-sm leading-relaxed text-foreground/90 md:text-base">
          {post.body}
        </div>
      </article>

      {/* Related articles */}
      {relatedQ.data && relatedQ.data.length > 0 ? (
        <section className="container mx-auto max-w-5xl px-4 pb-16">
          <h2 className="mb-6 font-display text-2xl font-semibold tracking-tight">Related articles</h2>
          <div className="grid gap-5 md:grid-cols-3">
            {relatedQ.data.map((p, i) => (
              <Link
                key={p.id}
                to="/blog/$slug"
                params={{ slug: p.slug }}
                className="group relative block overflow-hidden rounded-2xl glass p-6 hover-lift animate-fade-up"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <Spotlight />
                <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-[11px] text-brand-cyan">
                  {p.category?.name ?? "Article"}
                </span>
                <h3 className="mt-3 font-display text-base font-semibold tracking-tight">
                  {p.title}
                </h3>
                <p className="mt-2 line-clamp-3 text-xs leading-relaxed text-muted-foreground">
                  {p.excerpt}
                </p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      <CtaStrip
        title="Need help with a project like this?"
        description="We build websites, APIs, automation and SEO systems for serious businesses."
      />
    </SiteLayout>
  );
}
