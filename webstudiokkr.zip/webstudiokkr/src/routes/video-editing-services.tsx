import { createFileRoute } from "@tanstack/react-router";
import { Clapperboard, Film, Music2, Scissors, Sparkles, Youtube } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/video-editing-services";
const TITLE = "Video Editing Services";
const DESC =
  "Cinematic video editing and motion graphics — reels, shorts, YouTube videos, product films and ads by Web Studio KKR.";

export const Route = createFileRoute("/video-editing-services")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Video Editing",
          provider: { "@type": "Organization", name: site.brand.name, url: site.brand.url },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Video & Motion"
      title="Video editing that"
      highlight="looks premium."
      description="Reels, YouTube long-form, product films, ads and motion graphics — edited to convert, not just to fill a timeline."
      intro="Most videos lose viewers in the first 3 seconds. We edit hooks, pacing and motion that hold attention — whether you're shipping daily reels, monthly YouTube uploads, or a launch film for a new product."
      features={[
        { title: "Reels & shorts", description: "Hook-first cuts, captions, trending audio — built to retain.", icon: Sparkles },
        { title: "YouTube long-form", description: "Pacing, B-roll, thumbnails — built for watch time.", icon: Youtube },
        { title: "Product & ad films", description: "Cinematic edits that sell — for landing pages and paid ads.", icon: Clapperboard },
        { title: "Motion graphics", description: "Lower-thirds, animated titles, kinetic typography.", icon: Film },
        { title: "Color grading", description: "Cinematic looks, consistent across your channel.", icon: Scissors },
        { title: "Sound design", description: "Music, SFX and mixing that doesn't feel like an afterthought.", icon: Music2 },
      ]}
      benefits={[
        "Fast turnaround — 48-hour drafts available",
        "Edit in Premiere Pro / DaVinci / Final Cut",
        "Captions and translations on request",
        "Project files delivered if needed",
        "Retainer plans available for creators",
        "Free thumbnail design with every YouTube edit",
      ]}
      faqs={[
        { q: "How quickly can you turn around a reel?", a: "Standard turnaround is 48–72 hours. Rush 24-hour delivery is available with a small uplift." },
        { q: "Do you also write the script or hook?", a: "Yes — scriptwriting and hook design are available add-ons for creators and brands." },
        { q: "Can you handle a YouTube channel end-to-end?", a: "Yes. Editing, thumbnails, titles/descriptions, scheduling and analytics review — monthly retainer." },
      ]}
      inquirySource="landing_video_editing"
      inquiryTitle="Video Editing Services"
    />
  ),
});
