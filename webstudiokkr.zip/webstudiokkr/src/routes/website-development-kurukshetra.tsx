import { createFileRoute } from "@tanstack/react-router";
import { Code2, Gauge, LayoutTemplate, Search, Shield, Smartphone } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/website-development-kurukshetra";
const TITLE = "Website Development Services in Kurukshetra";
const DESC =
  "Hire a top website development company in Kurukshetra. Custom, responsive, SEO-ready websites built by Web Studio KKR for local businesses, startups and creators.";

export const Route = createFileRoute("/website-development-kurukshetra")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Website Development",
          provider: {
            "@type": "LocalBusiness",
            name: site.brand.name,
            url: site.brand.url,
            telephone: site.contact.phone,
            email: site.contact.email,
            address: {
              "@type": "PostalAddress",
              addressLocality: "Kurukshetra",
              addressRegion: "Haryana",
              addressCountry: "IN",
            },
          },
          areaServed: { "@type": "City", name: "Kurukshetra" },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Kurukshetra · Website Development"
      title="Website development"
      highlight="services in Kurukshetra."
      description="Custom-coded, lightning-fast websites for businesses across Kurukshetra and Haryana. Built on modern stacks, designed to convert."
      intro="Web Studio KKR is a Kurukshetra-based web development studio building production-grade websites for local stores, professionals, startups and growing brands across India. Every site we ship is mobile-first, SEO-ready, and built to scale."
      features={[
        { title: "Custom website design", description: "Hand-crafted designs tailored to your brand — no recycled templates.", icon: LayoutTemplate },
        { title: "Mobile-first build", description: "Pixel-perfect on every device, from low-end Android to desktop.", icon: Smartphone },
        { title: "Modern code stack", description: "React, Next.js & TanStack — clean, maintainable, future-proof.", icon: Code2 },
        { title: "SEO foundation", description: "Schema markup, semantic HTML, fast Core Web Vitals out of the box.", icon: Search },
        { title: "Blazing performance", description: "Sub-second load times. 95+ Lighthouse on every page we ship.", icon: Gauge },
        { title: "Secure hosting", description: "SSL, hardened servers, daily backups and monitoring included.", icon: Shield },
      ]}
      benefits={[
        "Local Kurukshetra studio — meet in person if you prefer",
        "Fixed-quote projects with clear milestones",
        "Content management built in — edit pages yourself",
        "Free 30-day post-launch support",
        "GST-compliant invoicing for Indian businesses",
        "Hindi & English communication",
      ]}
      faqs={[
        { q: "How long does a website take?", a: "A typical 5–7 page business website takes 2–4 weeks from kickoff to launch, depending on content readiness and revisions." },
        { q: "Do you serve businesses outside Kurukshetra?", a: "Yes — we work with clients across India and 14+ countries. Local Kurukshetra clients are welcome to meet in person." },
        { q: "Will I be able to edit the website myself?", a: "Yes. Every site ships with an admin panel so your team can update content, blogs, products and SEO without writing code." },
        { q: "Do you handle hosting and domain?", a: "We help you choose, register and configure both. Hosting is on hardened servers with SSL, backups and monitoring." },
        { q: "What's the cost of a website?", a: "Static brochure sites start around ₹15,000. Full-featured business sites with CMS, blog and bookings typically range ₹35,000–₹1,20,000. Send us your brief on WhatsApp for a quote." },
      ]}
      inquirySource="landing_website_development_kurukshetra"
      inquiryTitle="Website Development (Kurukshetra)"
      ctaTitle="Ready to build your website?"
      ctaDescription="Chat on WhatsApp or Telegram and we'll send a proposal within 24 hours."
    />
  ),
});
