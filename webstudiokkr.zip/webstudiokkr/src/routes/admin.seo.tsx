import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Save,
  Gauge,
  Zap,
  RefreshCw,
  Smartphone,
  Monitor,
  Loader2,
  ShieldCheck,
} from "lucide-react";
import {
  Line,
  LineChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  cms,
  computeSeoScore,
  useCms,
  type PsiHistoryEntry,
  type SeoEntry,
} from "@/lib/admin/store";
import { fetchPsi } from "@/lib/integrations/psi.functions";

export const Route = createFileRoute("/admin/seo")({
  head: () => ({ meta: [{ title: "SEO Center — Admin" }, { name: "robots", content: "noindex" }] }),
  component: SeoCenter,
});

// Pages to include in the PSI scanner. Paths align with the public router.
const SCAN_PAGES: { id: string; label: string; path: string }[] = [
  { id: "home", label: "Home", path: "/" },
  { id: "services", label: "Services", path: "/services" },
  { id: "products", label: "Products", path: "/products" },
  { id: "blog", label: "Blog", path: "/blog" },
  { id: "contact", label: "Contact", path: "/contact" },
];

type Strategy = "mobile" | "desktop";

function SeoCenter() {
  const pages = useCms((s) => s.pages);
  const seo = useCms((s) => s.seo);
  const [activeId, setActiveId] = useState(pages[0]?.id ?? "home");
  const entry = seo.find((e) => e.pageId === activeId);
  const [draft, setDraft] = useState<SeoEntry | null>(entry ?? null);
  const [saved, setSaved] = useState(false);

  function selectPage(id: string) {
    setActiveId(id);
    setDraft(seo.find((e) => e.pageId === id) ?? null);
    setSaved(false);
  }

  function save() {
    if (!draft) return;
    cms.upsertSeo(draft);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  const score = draft ? computeSeoScore(draft) : 0;

  return (
    <AdminShell title="SEO Center">
      <PageHeader
        title="SEO control"
        description="Live PageSpeed Insights, meta tags, OpenGraph and schema for every page."
      />

      <PsiDashboard />

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-[260px,1fr]">
        <GlassCard className="h-fit p-3">
          <div className="px-2 py-2 text-xs uppercase tracking-wider text-muted-foreground">
            Pages
          </div>
          <ul>
            {pages.map((p) => {
              const e = seo.find((x) => x.pageId === p.id);
              const sc = e ? computeSeoScore(e) : 0;
              return (
                <li key={p.id}>
                  <button
                    onClick={() => selectPage(p.id)}
                    className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                      activeId === p.id
                        ? "bg-white/[0.06] text-foreground"
                        : "text-muted-foreground hover:bg-white/[0.03] hover:text-foreground"
                    }`}
                  >
                    <span>{p.title}</span>
                    <span
                      className={`text-[10px] font-medium ${
                        sc >= 80
                          ? "text-emerald-400"
                          : sc >= 50
                            ? "text-amber-400"
                            : "text-destructive"
                      }`}
                    >
                      {sc}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </GlassCard>

        {draft ? (
          <div className="space-y-4">
            <GlassCard>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-display text-lg font-semibold">{draft.pageId}</div>
                  <div className="text-xs text-muted-foreground">SEO Health Score</div>
                </div>
                <div className="flex items-center gap-3">
                  <Gauge className="h-5 w-5 text-brand-cyan" />
                  <div className="font-display text-3xl font-semibold">{score}</div>
                </div>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-blue via-brand-cyan to-emerald-400"
                  style={{ width: `${score}%` }}
                />
              </div>
            </GlassCard>

            <GlassCard>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Field label="Meta Title (30–60 chars)">
                  <Input
                    value={draft.metaTitle}
                    onChange={(e) => setDraft({ ...draft, metaTitle: e.target.value })}
                  />
                  <Counter value={draft.metaTitle} min={30} max={60} />
                </Field>
                <Field label="Canonical URL">
                  <Input
                    value={draft.canonical}
                    onChange={(e) => setDraft({ ...draft, canonical: e.target.value })}
                  />
                </Field>
                <Field label="Meta Description (80–160 chars)">
                  <Textarea
                    rows={3}
                    value={draft.metaDescription}
                    onChange={(e) => setDraft({ ...draft, metaDescription: e.target.value })}
                  />
                  <Counter value={draft.metaDescription} min={80} max={160} />
                </Field>
                <Field label="Keywords (comma separated)">
                  <Textarea
                    rows={3}
                    value={draft.keywords}
                    onChange={(e) => setDraft({ ...draft, keywords: e.target.value })}
                  />
                </Field>
              </div>
            </GlassCard>

            <GlassCard>
              <div className="mb-3 text-xs uppercase tracking-wider text-muted-foreground">
                Open Graph
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Field label="OG Title">
                  <Input
                    value={draft.ogTitle}
                    onChange={(e) => setDraft({ ...draft, ogTitle: e.target.value })}
                  />
                </Field>
                <Field label="OG Image URL">
                  <Input
                    value={draft.ogImage}
                    onChange={(e) => setDraft({ ...draft, ogImage: e.target.value })}
                  />
                </Field>
                <Field label="OG Description">
                  <Textarea
                    rows={2}
                    value={draft.ogDescription}
                    onChange={(e) => setDraft({ ...draft, ogDescription: e.target.value })}
                  />
                </Field>
                <Field label="Twitter Card">
                  <select
                    value={draft.twitterCard}
                    onChange={(e) =>
                      setDraft({
                        ...draft,
                        twitterCard: e.target.value as SeoEntry["twitterCard"],
                      })
                    }
                    className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                  >
                    <option value="summary_large_image">summary_large_image</option>
                    <option value="summary">summary</option>
                  </select>
                </Field>
              </div>
            </GlassCard>

            <GlassCard>
              <Field label="Structured Data (JSON-LD)">
                <Textarea
                  rows={6}
                  className="font-mono text-xs"
                  value={draft.schema}
                  onChange={(e) => setDraft({ ...draft, schema: e.target.value })}
                  placeholder='{"@context":"https://schema.org","@type":"WebPage"}'
                />
              </Field>
            </GlassCard>

            <div className="flex items-center justify-end gap-2">
              {saved ? <span className="text-xs text-emerald-400">Saved ✓</span> : null}
              <Button variant="brand" onClick={save}>
                <Save className="h-4 w-4" /> Save SEO
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </AdminShell>
  );
}

// ---------------------------------------------------------------------------
// Live PageSpeed Insights dashboard
// ---------------------------------------------------------------------------

function PsiDashboard() {
  const history = useCms((s) => s.psiHistory);
  const [strategy, setStrategy] = useState<Strategy>("mobile");
  const [chartPage, setChartPage] = useState<string>("home");
  const qc = useQueryClient();

  // Build per-page query for the active strategy. Caching is handled by
  // react-query: each (page, strategy) pair has its own key with a 10-min
  // stale window so panel toggles don't refire the API.
  const queries = SCAN_PAGES.map((p) => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const q = useQuery({
      queryKey: ["psi", p.path, strategy],
      queryFn: async () => {
        const env = await fetchPsi({ data: { url: p.path, strategy } });
        cms.addPsiSnapshot({
          pageId: p.id,
          strategy,
          fetchedAt: env.fetchedAt,
          source: env.source,
          scores: env.data.scores,
          vitals: env.data.vitals,
        } satisfies PsiHistoryEntry);
        return env;
      },
      staleTime: 10 * 60_000,
      gcTime: 30 * 60_000,
      retry: 1,
    });
    return { page: p, q };
  });

  const isScanning = queries.some((x) => x.q.isFetching);
  const lastScan = useMemo(() => {
    const ts = queries
      .map((x) => x.q.data?.fetchedAt ?? 0)
      .filter(Boolean)
      .sort((a, b) => b - a)[0];
    return ts ?? 0;
  }, [queries]);
  const anyPending = queries.some((x) => x.q.data?.source !== "live");

  const refreshMutation = useMutation({
    mutationFn: async () => {
      await Promise.all(
        SCAN_PAGES.map((p) =>
          qc.invalidateQueries({ queryKey: ["psi", p.path, strategy] }),
        ),
      );
    },
  });

  const chartData = useMemo(() => {
    const filtered = history
      .filter((h) => h.pageId === chartPage && h.strategy === strategy)
      .slice(0, 20)
      .reverse();
    return filtered.map((h) => ({
      t: new Date(h.fetchedAt).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
      Performance: h.scores.performance,
      SEO: h.scores.seo,
      Accessibility: h.scores.accessibility,
      "Best Practices": h.scores.bestPractices,
    }));
  }, [history, chartPage, strategy]);

  return (
    <div className="space-y-4">
      <GlassCard>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 font-display text-lg font-semibold">
              <Zap className="h-5 w-5 text-brand-cyan" /> PageSpeed Insights
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
              API key stored server-side as <code className="rounded bg-white/5 px-1">PSI_API_KEY</code>
              <span>·</span>
              <span>
                {lastScan
                  ? `Last scan ${new Date(lastScan).toLocaleString()}`
                  : "No scans yet"}
              </span>
              {anyPending && lastScan ? (
                <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-amber-300">
                  Some pages awaiting live data
                </span>
              ) : null}

            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex overflow-hidden rounded-md border border-white/10">
              <button
                onClick={() => setStrategy("mobile")}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs ${strategy === "mobile" ? "bg-white/10 text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Smartphone className="h-3.5 w-3.5" /> Mobile
              </button>
              <button
                onClick={() => setStrategy("desktop")}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs ${strategy === "desktop" ? "bg-white/10 text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Monitor className="h-3.5 w-3.5" /> Desktop
              </button>
            </div>
            <Button
              variant="outline"
              onClick={() => refreshMutation.mutate()}
              disabled={isScanning}
            >
              {isScanning ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <RefreshCw className="h-3.5 w-3.5" />
              )}
              Refresh all
            </Button>
          </div>
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
        {queries.map(({ page, q }) => (
          <PsiPageCard
            key={page.id}
            label={page.label}
            path={page.path}
            loading={q.isLoading || q.isFetching}
            error={q.error instanceof Error ? q.error.message : null}
            data={q.data}
          />
        ))}
      </div>

      <GlassCard>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="font-display text-base font-semibold">Historical score tracking</div>
            <div className="text-xs text-muted-foreground">
              Last {chartData.length || 0} scans · {strategy}
            </div>
          </div>
          <select
            value={chartPage}
            onChange={(e) => setChartPage(e.target.value)}
            className="h-9 rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
          >
            {SCAN_PAGES.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
        <div className="h-64 w-full">
          {chartData.length > 1 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 8, right: 16, left: -8, bottom: 0 }}>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3" />
                <XAxis dataKey="t" stroke="rgba(255,255,255,0.4)" fontSize={11} />
                <YAxis domain={[0, 100]} stroke="rgba(255,255,255,0.4)" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "rgba(10,12,20,0.95)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="Performance" stroke="#22d3ee" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="SEO" stroke="#34d399" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Accessibility" stroke="#a78bfa" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="Best Practices" stroke="#f472b6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
              Run two or more scans to plot trends.
            </div>
          )}
        </div>
      </GlassCard>
    </div>
  );
}

function PsiPageCard({
  label,
  path,
  loading,
  error,
  data,
}: {
  label: string;
  path: string;
  loading: boolean;
  error: string | null;
  data: Awaited<ReturnType<typeof fetchPsi>> | undefined;
}) {
  return (
    <GlassCard className="space-y-3">
      <div className="flex items-start justify-between">
        <div>
          <div className="font-display text-sm font-semibold">{label}</div>
          <div className="text-[11px] text-muted-foreground">{path}</div>
        </div>
        {data ? (
          <span
            className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
              data.source === "live"
                ? "bg-emerald-500/15 text-emerald-300"
                : "bg-amber-500/15 text-amber-300"
            }`}
          >
            {data.source === "live" ? "Live" : "Not Connected"}
          </span>

        ) : loading ? (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        ) : null}
      </div>

      {error ? (
        <div className="rounded-md border border-rose-500/30 bg-rose-500/10 p-2 text-xs text-rose-200">
          {error}
        </div>
      ) : null}

      {data ? (
        <>
          <div className="grid grid-cols-4 gap-2">
            <ScorePill label="Perf" value={data.data.scores.performance} />
            <ScorePill label="SEO" value={data.data.scores.seo} />
            <ScorePill label="A11y" value={data.data.scores.accessibility} />
            <ScorePill label="Best" value={data.data.scores.bestPractices} />
          </div>
          <div className="grid grid-cols-5 gap-1.5 pt-1">
            <Vital label="LCP" value={`${(data.data.vitals.lcp / 1000).toFixed(2)}s`} />
            <Vital label="CLS" value={data.data.vitals.cls.toFixed(3)} />
            <Vital label="INP" value={`${data.data.vitals.inp}ms`} />
            <Vital label="FCP" value={`${(data.data.vitals.fcp / 1000).toFixed(2)}s`} />
            <Vital label="TTFB" value={`${data.data.vitals.ttfb}ms`} />
          </div>
          {data.reason ? (
            <div className="text-[10px] text-muted-foreground">Note: {data.reason}</div>
          ) : null}
        </>
      ) : !error ? (
        <div className="space-y-2">
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="h-14 animate-pulse rounded-xl border border-white/5 bg-white/[0.02]"
              />
            ))}
          </div>
          <div className="grid grid-cols-5 gap-1.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="h-10 animate-pulse rounded-lg border border-white/5 bg-white/[0.02]"
              />
            ))}
          </div>
        </div>
      ) : null}
    </GlassCard>
  );
}

function ScorePill({ label, value }: { label: string; value: number }) {
  const color =
    value >= 90 ? "text-emerald-300" : value >= 50 ? "text-amber-300" : "text-rose-300";
  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.02] p-2 text-center">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-0.5 font-display text-xl font-semibold ${color}`}>{value}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function Counter({ value, min, max }: { value: string; min: number; max: number }) {
  const len = value.length;
  const ok = len >= min && len <= max;
  return (
    <div className={`text-[10px] ${ok ? "text-emerald-400" : "text-muted-foreground"}`}>
      {len} chars · ideal {min}–{max}
    </div>
  );
}

function Vital({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/5 bg-white/[0.02] p-1.5 text-center">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 font-mono text-[11px]">{value}</div>
    </div>
  );
}
