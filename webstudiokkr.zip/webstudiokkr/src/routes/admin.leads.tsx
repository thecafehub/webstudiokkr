import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Trash2,
  Mail,
  Phone,
  Calendar,
  AlertCircle,
  MessageSquare,
  ExternalLink,
} from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  listLeads,
  updateLead,
  deleteLead,
  listNotes,
  addNote,
  deleteNote,
  isDueFollowUp,
  LEAD_STATUSES,
  LEAD_STATUS_LABEL,
  type Lead,
  type LeadStatus,
} from "@/lib/cms/crm";

export const Route = createFileRoute("/admin/leads")({
  head: () => ({ meta: [{ title: "CRM — Admin" }, { name: "robots", content: "noindex" }] }),
  component: LeadsManager,
});

const STATUS_COLORS: Record<LeadStatus, string> = {
  new: "bg-blue-500/15 text-blue-300 border-blue-500/30",
  contacted: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  qualified: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  won: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  closed: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  lost: "bg-muted/30 text-muted-foreground border-white/10",
};

function LeadsManager() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | LeadStatus | "due">("all");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data: leads = [], isLoading } = useQuery({
    queryKey: ["crm", "leads"],
    queryFn: listLeads,
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return leads.filter((l) => {
      if (filter === "due") {
        if (!isDueFollowUp(l)) return false;
      } else if (filter !== "all") {
        if (l.status !== filter) return false;
      }
      if (!q) return true;
      return (
        l.name.toLowerCase().includes(q) ||
        l.email.toLowerCase().includes(q) ||
        (l.phone ?? "").toLowerCase().includes(q) ||
        l.message.toLowerCase().includes(q)
      );
    });
  }, [leads, filter, search]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: leads.length, due: 0 };
    for (const s of LEAD_STATUSES) c[s] = 0;
    for (const l of leads) {
      c[l.status] = (c[l.status] ?? 0) + 1;
      if (isDueFollowUp(l)) c.due += 1;
    }
    return c;
  }, [leads]);

  const updateMut = useMutation({
    mutationFn: (args: { id: string; patch: Partial<Lead> }) =>
      updateLead(args.id, args.patch),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["crm", "leads"] }),
  });

  const deleteMut = useMutation({
    mutationFn: deleteLead,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["crm", "leads"] }),
  });

  const selected = filtered.find((l) => l.id === selectedId) ?? null;

  return (
    <AdminShell title="CRM / Leads" requires="crm">
      <PageHeader
        title="Lead pipeline"
        description="Inbound inquiries from the website, WhatsApp clicks and product pages. Update status, schedule follow-ups, and keep internal notes."
        action={
          counts.due > 0 ? (
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs text-amber-300">
              <AlertCircle className="h-3.5 w-3.5" />
              {counts.due} follow-up{counts.due === 1 ? "" : "s"} due
            </span>
          ) : null
        }
      />

      {/* Filters */}
      <div className="mb-5 flex flex-wrap items-center gap-2">
        <FilterPill active={filter === "all"} onClick={() => setFilter("all")}>
          All <span className="opacity-60">· {counts.all}</span>
        </FilterPill>
        <FilterPill active={filter === "due"} onClick={() => setFilter("due")}>
          Due follow-ups <span className="opacity-60">· {counts.due}</span>
        </FilterPill>
        {LEAD_STATUSES.map((s) => (
          <FilterPill key={s} active={filter === s} onClick={() => setFilter(s)}>
            {LEAD_STATUS_LABEL[s]} <span className="opacity-60">· {counts[s]}</span>
          </FilterPill>
        ))}
        <Input
          placeholder="Search name, email, message…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="ml-auto max-w-xs"
        />
      </div>

      {isLoading ? (
        <GlassCard className="py-16 text-center text-muted-foreground">Loading leads…</GlassCard>
      ) : filtered.length === 0 ? (
        <GlassCard className="py-16 text-center text-muted-foreground">
          No leads match this view.
        </GlassCard>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1fr_minmax(380px,420px)]">
          <div className="grid gap-3">
            {filtered.map((l) => {
              const due = isDueFollowUp(l);
              return (
                <button
                  type="button"
                  key={l.id}
                  onClick={() => setSelectedId(l.id)}
                  className={`text-left rounded-2xl border bg-white/[0.03] p-4 transition-all hover:bg-white/[0.06] ${
                    selectedId === l.id
                      ? "border-brand-cyan/40 shadow-[0_0_0_1px_oklch(0.85_0.18_200/0.4)]"
                      : "border-white/[0.07]"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-display text-base font-semibold">{l.name}</span>
                        {due ? (
                          <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] text-amber-300">
                            Due
                          </span>
                        ) : null}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <Mail className="h-3 w-3" /> {l.email}
                        </span>
                        {l.phone ? (
                          <span className="inline-flex items-center gap-1">
                            <Phone className="h-3 w-3" /> {l.phone}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <span
                      className={`rounded-full border px-2 py-0.5 text-[10px] ${STATUS_COLORS[l.status]}`}
                    >
                      {LEAD_STATUS_LABEL[l.status]}
                    </span>
                  </div>
                  <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{l.message}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-3 text-[10px] uppercase tracking-wider text-muted-foreground">
                    <span>via {l.source ?? "unknown"}</span>
                    <span>· {new Date(l.created_at).toLocaleString()}</span>
                    {l.product ? (
                      <span className="text-brand-cyan/80">
                        · product: {l.product.title}
                      </span>
                    ) : null}
                    {l.follow_up_at ? (
                      <span className={due ? "text-amber-300" : ""}>
                        · follow-up {new Date(l.follow_up_at).toLocaleDateString()}
                      </span>
                    ) : null}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="lg:sticky lg:top-24 lg:self-start">
            {selected ? (
              <LeadDetailPanel
                lead={selected}
                onUpdate={(patch) =>
                  updateMut.mutate({ id: selected.id, patch })
                }
                onDelete={() => {
                  if (confirm(`Delete lead from ${selected.name}?`)) {
                    deleteMut.mutate(selected.id);
                    setSelectedId(null);
                  }
                }}
              />
            ) : (
              <GlassCard className="py-12 text-center text-sm text-muted-foreground">
                Select a lead to see contact info, status controls, follow-up date and notes.
              </GlassCard>
            )}
          </div>
        </div>
      )}
    </AdminShell>
  );
}

function FilterPill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
        active
          ? "border-brand-cyan/40 bg-brand-cyan/10 text-foreground"
          : "border-white/10 text-muted-foreground hover:bg-white/5"
      }`}
    >
      {children}
    </button>
  );
}

function LeadDetailPanel({
  lead,
  onUpdate,
  onDelete,
}: {
  lead: Lead;
  onUpdate: (patch: Partial<Lead>) => void;
  onDelete: () => void;
}) {
  const qc = useQueryClient();
  const [noteBody, setNoteBody] = useState("");
  const [followUp, setFollowUp] = useState<string>(
    lead.follow_up_at ? lead.follow_up_at.slice(0, 10) : "",
  );
  const [internal, setInternal] = useState<string>(lead.internal_notes ?? "");

  const { data: notes = [] } = useQuery({
    queryKey: ["crm", "notes", lead.id],
    queryFn: () => listNotes(lead.id),
  });
  const addNoteMut = useMutation({
    mutationFn: () => addNote(lead.id, noteBody.trim()),
    onSuccess: () => {
      setNoteBody("");
      qc.invalidateQueries({ queryKey: ["crm", "notes", lead.id] });
    },
  });
  const delNoteMut = useMutation({
    mutationFn: deleteNote,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["crm", "notes", lead.id] }),
  });

  return (
    <GlassCard className="space-y-5">
      <div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Lead</div>
        <div className="mt-1 font-display text-lg font-semibold">{lead.name}</div>
        <div className="mt-2 flex flex-wrap gap-2 text-xs">
          <a
            href={`mailto:${lead.email}`}
            className="inline-flex items-center gap-1 rounded-md bg-white/5 px-2 py-1 hover:bg-white/10"
          >
            <Mail className="h-3 w-3" /> {lead.email}
          </a>
          {lead.phone ? (
            <a
              href={`tel:${lead.phone}`}
              className="inline-flex items-center gap-1 rounded-md bg-white/5 px-2 py-1 hover:bg-white/10"
            >
              <Phone className="h-3 w-3" /> {lead.phone}
            </a>
          ) : null}
          {lead.phone ? (
            <a
              href={`https://wa.me/${lead.phone.replace(/[^\d]/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 rounded-md bg-emerald-500/15 px-2 py-1 text-emerald-300 hover:bg-emerald-500/25"
            >
              <MessageSquare className="h-3 w-3" /> WhatsApp
            </a>
          ) : null}
        </div>
      </div>

      <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3 text-sm text-muted-foreground">
        {lead.message}
      </div>

      {lead.product ? (
        <div className="text-xs text-muted-foreground">
          Interested in:{" "}
          <a
            href={`/products/${lead.product.slug}`}
            className="inline-flex items-center gap-1 text-brand-cyan hover:underline"
          >
            {lead.product.title} <ExternalLink className="h-3 w-3" />
          </a>
        </div>
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label>Status</Label>
          <select
            value={lead.status}
            onChange={(e) => onUpdate({ status: e.target.value as LeadStatus })}
            className="mt-1 h-9 w-full rounded-md border border-white/10 bg-white/[0.03] px-2 text-xs"
          >
            {LEAD_STATUSES.map((s) => (
              <option key={s} value={s}>
                {LEAD_STATUS_LABEL[s]}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Follow-up date</Label>
          <div className="mt-1 flex items-center gap-2">
            <Input
              type="date"
              value={followUp}
              onChange={(e) => setFollowUp(e.target.value)}
              className="h-9"
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                onUpdate({ follow_up_at: followUp ? new Date(followUp).toISOString() : null })
              }
            >
              <Calendar className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>

      <div>
        <Label>Internal notes (quick)</Label>
        <Textarea
          value={internal}
          onChange={(e) => setInternal(e.target.value)}
          onBlur={() => {
            if (internal !== (lead.internal_notes ?? "")) {
              onUpdate({ internal_notes: internal });
            }
          }}
          rows={3}
          placeholder="One-line private notes that always stay with the lead…"
          className="mt-1"
        />
      </div>

      <div>
        <Label>Activity & notes</Label>
        <div className="mt-2 space-y-2">
          <div className="flex gap-2">
            <Input
              value={noteBody}
              onChange={(e) => setNoteBody(e.target.value)}
              placeholder="Add a note (called, emailed, sent quote…)"
              className="h-9"
            />
            <Button
              size="sm"
              variant="brand"
              disabled={!noteBody.trim() || addNoteMut.isPending}
              onClick={() => addNoteMut.mutate()}
            >
              Add
            </Button>
          </div>

          {notes.length === 0 ? (
            <div className="rounded-md border border-dashed border-white/10 p-3 text-xs text-muted-foreground">
              No notes yet.
            </div>
          ) : (
            <ul className="space-y-2">
              {notes.map((n) => (
                <li
                  key={n.id}
                  className="flex items-start gap-2 rounded-md border border-white/5 bg-white/[0.02] p-3"
                >
                  <div className="flex-1">
                    <div className="text-sm">{n.body}</div>
                    <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                      {new Date(n.created_at).toLocaleString()}
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => delNoteMut.mutate(n.id)}
                    title="Delete note"
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="flex justify-end border-t border-white/5 pt-3">
        <Button variant="ghost" size="sm" onClick={onDelete}>
          <Trash2 className="mr-1.5 h-3.5 w-3.5 text-destructive" />
          Delete lead
        </Button>
      </div>
    </GlassCard>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
      {children}
    </div>
  );
}
