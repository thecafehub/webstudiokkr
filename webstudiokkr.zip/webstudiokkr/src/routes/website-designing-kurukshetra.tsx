import { createFileRoute } from "@tanstack/react-router";
import { Brush, Eye, Layers, Palette, Sparkles, Wand2 } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/website-designing-kurukshetra";
const TITLE = "Website Designing Services in Kurukshetra";
const DESC =
  "Premium website designing services in Kurukshetra. Beautiful, brand-aligned UI/UX, landing pages and product designs by Web Studio KKR.";

export const Route = createFileRoute("/website-designing-kurukshetra")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Website Designing",
          provider: {
            "@type": "LocalBusiness",
            name: site.brand.name,
            url: site.brand.url,
            telephone: site.contact.phone,
            email: site.contact.email,
            address: { "@type": "PostalAddress", addressLocality: "Kurukshetra", addressRegion: "Haryana", addressCountry: "IN" },
          },
          areaServed: { "@type": "City", name: "Kurukshetra" },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Kurukshetra · Website Design"
      title="Website designing"
      highlight="that actually converts."
      description="Modern, premium UI/UX design for websites, landing pages and product surfaces — by a Kurukshetra studio with global standards."
      intro="Great design isn't decoration — it's how visitors decide whether to trust you in the first three seconds. Our designers craft visual systems that look premium and convert better, tailored to your brand voice and audience."
      features={[
        { title: "Visual identity", description: "Color systems, typography and motion language that match your brand.", icon: Palette },
        { title: "UI/UX wireframing", description: "Information architecture that guides users to the right action.", icon: Layers },
        { title: "Premium aesthetics", description: "Glassmorphism, gradients, 3D and aurora effects done tastefully.", icon: Sparkles },
        { title: "Conversion-led layouts", description: "Hero, social proof and CTA placement informed by real data.", icon: Eye },
        { title: "Custom illustrations", description: "Unique visual assets — no stock photo clichés.", icon: Brush },
        { title: "Design + dev handoff", description: "Pixel-perfect implementation, no \"close enough\".", icon: Wand2 },
      ]}
      benefits={[
        "Figma source files included",
        "2 design rounds + unlimited refinements per round",
        "Responsive mobile + tablet + desktop layouts",
        "Brand-aligned typography & color tokens",
        "Component library for future expansion",
        "Real Kurukshetra studio — no offshore guesswork",
      ]}
      faqs={[
        { q: "Do you only design, or also build the site?", a: "Both. We can design only and hand off to your developers, or design + build end-to-end." },
        { q: "How many design revisions are included?", a: "Two full revision rounds with unlimited tweaks per round. Heavy scope changes are scoped separately." },
        { q: "Can you redesign my existing website?", a: "Yes — redesigns are one of our most common projects. We audit your current site, propose direction, then design and ship the new version." },
        { q: "Do you provide brand identity too?", a: "Yes. Logo, color palette, typography and brand guidelines can be bundled with website design." },
      ]}
      inquirySource="landing_website_designing_kurukshetra"
      inquiryTitle="Website Designing (Kurukshetra)"
    />
  ),
});
