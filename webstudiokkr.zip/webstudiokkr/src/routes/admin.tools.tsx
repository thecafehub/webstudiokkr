import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, Save, Power } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cms, uid, useCms, type ToolItem } from "@/lib/admin/store";
import { toolCategories } from "@/config/site";
import { Drawer } from "./admin.services";

export const Route = createFileRoute("/admin/tools")({
  head: () => ({ meta: [{ title: "Tools — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ToolsManager,
});

const empty = (): ToolItem => ({
  id: uid("tool"),
  title: "",
  description: "",
  category: toolCategories[0].id,
  url: "",
  enabled: true,
});

function ToolsManager() {
  const tools = useCms((s) => s.tools);
  const [editing, setEditing] = useState<ToolItem | null>(null);

  function save() {
    if (!editing) return;
    cms.upsertTool(editing);
    setEditing(null);
  }

  return (
    <AdminShell title="Tools">
      <PageHeader
        title="Tools catalog"
        description="Manage every utility shown in the public Tools section."
        action={
          <Button variant="brand" onClick={() => setEditing(empty())}>
            <Plus className="h-4 w-4" /> New tool
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {tools.map((t) => (
          <GlassCard key={t.id}>
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-brand-cyan">
                  {toolCategories.find((c) => c.id === t.category)?.title ?? t.category}
                </div>
                <div className="font-display text-base font-semibold">{t.title}</div>
              </div>
              <span
                className={`text-[10px] ${
                  t.enabled ? "text-emerald-400" : "text-muted-foreground"
                }`}
              >
                {t.enabled ? "Live" : "Off"}
              </span>
            </div>
            <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{t.description}</p>
            <div className="mt-4 flex justify-end gap-1">
              <Button
                size="icon"
                variant="ghost"
                onClick={() => cms.upsertTool({ ...t, enabled: !t.enabled })}
              >
                <Power className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditing(t)}>
                Edit
              </Button>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  if (confirm(`Delete tool "${t.title}"?`)) cms.deleteTool(t.id);
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </GlassCard>
        ))}
      </div>

      {editing ? (
        <Drawer title={editing.title ? "Edit tool" : "New tool"} onClose={() => setEditing(null)}>
          <div className="space-y-4">
            <Field label="Title">
              <Input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </Field>
            <Field label="Description">
              <Textarea
                rows={3}
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Category">
                <select
                  value={editing.category}
                  onChange={(e) => setEditing({ ...editing, category: e.target.value })}
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  {toolCategories.map((c) => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </Field>
              <Field label="URL / Anchor">
                <Input value={editing.url} onChange={(e) => setEditing({ ...editing, url: e.target.value })} />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={editing.enabled}
                onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })}
              />
              Enabled
            </label>
            <Button variant="brand" className="w-full" onClick={save}>
              <Save className="h-4 w-4" /> Save tool
            </Button>
          </div>
        </Drawer>
      ) : null}
    </AdminShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
