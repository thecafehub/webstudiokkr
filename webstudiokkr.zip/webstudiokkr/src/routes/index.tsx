import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  MapPin,
  MessageCircle,
  Quote,
  Sparkles,
  Star,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { FloatingParticles } from "@/components/effects/FloatingParticles";
import { GeometricShapes } from "@/components/effects/GeometricShapes";


import { FeatureCard } from "@/components/sections/FeatureCard";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { Spotlight } from "@/components/effects/Spotlight";
import { TiltCard } from "@/components/effects/TiltCard";
import { HolographicScene } from "@/components/effects/HolographicScene";

import { Reveal } from "@/components/effects/Reveal";
import { ParallaxLayer } from "@/components/effects/ParallaxLayer";
import {
  site,
  services,
  productCategories,
  toolCategories,
  highlights,
} from "@/config/site";
import { useSiteSettings } from "@/lib/cms/settings";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: `${site.brand.name} — Websites, SEO, APIs, Automation & Digital Products`,
      },
      {
        name: "description",
        content:
          "Web Studio KKR is a premium digital agency in Kurukshetra, Haryana — building websites, SEO systems, custom APIs, Telegram & WhatsApp automation, and a marketplace of digital products.",
      },
      {
        name: "keywords",
        content:
          "web studio kkr, digital marketing services kurukshetra, website designing kurukshetra, website development kurukshetra, SEO services kurukshetra, telegram bot development, custom API development, whatsapp api integration, video editing kurukshetra, graphic design kurukshetra, local SEO, google ranking services",
      },
      { property: "og:title", content: `${site.brand.name} — Premium Digital Studio` },
      { property: "og:description", content: site.brand.description },
      { property: "og:url", content: site.brand.url + "/" },
    ],
    links: [{ rel: "canonical", href: site.brand.url + "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <SiteLayout>
      <Hero />
      <TrustStrip />
      <Reveal><Stats /></Reveal>
      <Reveal><ServicesPreview /></Reveal>
      <Reveal><FeaturedProducts /></Reveal>
      <Reveal><FeaturedTools /></Reveal>
      <Reveal><AboutPreview /></Reveal>
      <Reveal><Testimonials /></Reveal>
      <Reveal><Highlights /></Reveal>
      <Reveal><Process /></Reveal>
      <Reveal><SeoContent /></Reveal>
      <CtaStrip />
    </SiteLayout>
  );
}

/* ─── Hero ────────────────────────────────────────────────── */
function Hero() {
  return (
    <section className="relative overflow-hidden">
      <GeometricShapes />
      <HolographicScene />
      <FloatingParticles count={24} />

      <div className="container relative z-10 mx-auto px-4 pt-8 pb-20 sm:pt-16 sm:pb-28">
        <div className="mx-auto max-w-4xl text-center">
          <div className="inline-flex animate-fade-up items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-brand-cyan">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Premium digital craftsmanship</span>
            <span className="opacity-50">·</span>
            <MapPin className="h-3 w-3" />
            <span>{site.brand.location.split(",")[0]}</span>
          </div>

          <h1
            className="mt-6 animate-fade-up font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl md:text-7xl"
            style={{ animationDelay: "60ms" }}
          >
            <span className="block">Websites · SEO · APIs</span>
            <span className="relative inline-block">
              <span className="gradient-brand-text">Automation</span>
              <span className="absolute -bottom-2 left-0 h-1 w-full rounded-full bg-gradient-to-r from-brand-blue via-brand-cyan to-brand-violet opacity-70" />
            </span>{" "}
            <span className="block">&amp; Digital Products</span>
          </h1>

          <p
            className="mx-auto mt-7 max-w-2xl animate-fade-up text-base leading-relaxed text-muted-foreground sm:text-lg"
            style={{ animationDelay: "120ms" }}
          >
            {site.brand.name} is a full-stack digital studio from{" "}
            {site.brand.location.split(",")[0]} — shipping pixel-perfect websites, custom
            APIs, Telegram &amp; WhatsApp bots, ranking-grade SEO, and a fast-growing
            marketplace of source codes, templates and digital products.
          </p>

          <div
            className="mt-9 flex animate-fade-up flex-wrap items-center justify-center gap-3"
            style={{ animationDelay: "180ms" }}
          >
            <Button asChild variant="hero" size="xl">
              <Link to="/contact">
                Start a project <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="glass" size="xl">
              <Link to="/products">
                Browse marketplace <ArrowUpRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div
            className="mt-10 flex animate-fade-up flex-wrap items-center justify-center gap-x-6 gap-y-3 text-xs text-muted-foreground"
            style={{ animationDelay: "240ms" }}
          >
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand-cyan" /> 120+ projects shipped
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand-cyan" /> SEO-first architecture
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand-cyan" /> 14 countries served
            </span>
          </div>
        </div>

      </div>

    </section>
  );
}

/* ─── Trust strip (marquee) ──────────────────────────────── */
function TrustStrip() {
  const items = [
    "React", "Next.js", "TanStack", "Node.js", "Supabase", "PostgreSQL",
    "Tailwind CSS", "Stripe", "Telegram API", "WhatsApp Cloud API",
    "OpenAI", "Vercel", "Cloudflare", "Docker",
  ];
  return (
    <section className="relative py-10">
      <div className="container mx-auto px-4">
        <p className="text-center text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
          Built with modern, production-grade stacks
        </p>
        <div className="relative mt-6 overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_15%,#000_85%,transparent)]">
          <div className="flex w-max animate-marquee gap-10">
            {[...items, ...items].map((label, i) => (
              <span
                key={i}
                className="whitespace-nowrap font-display text-sm font-semibold text-muted-foreground/70"
              >
                {label}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Stats ───────────────────────────────────────────────── */
function Stats() {
  const settings = useSiteSettings();
  return (
    <section className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {settings.stats.map((s) => (
          <TiltCard key={s.label}>
            <div className="rounded-2xl glass p-5 text-center tilt-card">
              <p className="gradient-brand-text font-display text-3xl font-bold tracking-tight sm:text-4xl">
                {s.value}
              </p>
              <p className="mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground">{s.label}</p>
            </div>
          </TiltCard>
        ))}
      </div>
    </section>
  );
}

/* ─── Services preview ───────────────────────────────────── */
function ServicesPreview() {
  const preview = services.slice(0, 6);
  return (
    <section className="container mx-auto px-4 py-20">
      <SectionHeading
        eyebrow="What we build"
        title="Services that ship businesses,"
        highlight="not slide decks."
        description="From the first wireframe to a hardened production server — full-stack delivery, end to end."
      />
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {preview.map((s, i) => (
          <div key={s.id} style={{ animationDelay: `${i * 60}ms` }} className="animate-fade-up">
            <FeatureCard icon={s.icon} title={s.title} description={s.description} accent={s.accent} />
          </div>
        ))}
      </div>
      <div className="mt-10 text-center">
        <Button asChild variant="glass" size="lg">
          <Link to="/services">
            View all {services.length} services <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </div>
    </section>
  );
}

/* ─── Featured Products ──────────────────────────────────── */
function FeaturedProducts() {
  return (
    <section className="relative py-20">
      <div className="pointer-events-none absolute inset-0 -z-10 mesh-bg opacity-40" />
      <ParallaxLayer range={60} className="pointer-events-none absolute inset-0 -z-10 hidden lg:block">
        <div className="absolute left-[8%] top-10 h-64 w-64 rounded-full opacity-50 blur-3xl"
             style={{ background: "radial-gradient(circle, oklch(0.65 0.21 255 / 0.45), transparent 70%)" }} />
        <div className="absolute right-[6%] bottom-10 h-72 w-72 rounded-full opacity-50 blur-3xl"
             style={{ background: "radial-gradient(circle, oklch(0.66 0.24 295 / 0.45), transparent 70%)" }} />
      </ParallaxLayer>
      <div className="container mx-auto px-4">
        <SectionHeading
          eyebrow="Featured Products"
          title="Production-ready source codes,"
          highlight="ready to deploy today."
          description="Trading platforms, SMM panels, Telegram bots and website templates — full source code, battle-tested by our team."
        />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {productCategories.map((p, i) => (
            <Link
              key={p.id}
              to="/products"
              className="animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <TiltCard>
                <div className="group relative h-full overflow-hidden rounded-2xl glass p-7 tilt-card">
                  <Spotlight />
                  <div className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full opacity-50 blur-3xl"
                       style={{ background: accentGlow(p.accent) }} />
                  <div className={`mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${accentBg(p.accent)} ring-1 ring-white/10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3`}>
                    <p.icon className="h-6 w-6" />
                  </div>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-xl font-semibold tracking-tight">{p.title}</h3>
                    <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-foreground" />
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                  <div className="mt-5 flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-xs text-brand-cyan">
                      <Star className="h-3 w-3 fill-brand-cyan text-brand-cyan" /> {p.count}
                    </span>
                    <span className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                      View collection
                    </span>
                  </div>
                </div>
              </TiltCard>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function accentBg(a: "blue" | "cyan" | "violet" | "pink") {
  return {
    blue: "from-brand-blue/30 to-brand-blue/0 text-brand-blue",
    cyan: "from-brand-cyan/30 to-brand-cyan/0 text-brand-cyan",
    violet: "from-brand-violet/30 to-brand-violet/0 text-brand-violet",
    pink: "from-brand-pink/30 to-brand-pink/0 text-brand-pink",
  }[a];
}
function accentGlow(a: "blue" | "cyan" | "violet" | "pink") {
  return {
    blue: "oklch(0.65 0.21 255 / 0.4)",
    cyan: "oklch(0.82 0.16 200 / 0.4)",
    violet: "oklch(0.66 0.24 295 / 0.4)",
    pink: "oklch(0.72 0.22 340 / 0.4)",
  }[a];
}

/* ─── Featured Tools ─────────────────────────────────────── */
function FeaturedTools() {
  return (
    <section className="container mx-auto px-4 py-20">
      <SectionHeading
        eyebrow="Featured Tools"
        title="A growing platform of"
        highlight="free, futuristic tools."
        description="SEO checkers, developer utilities, API inspectors and marketing helpers — all in one place, no signup required."
      />
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {toolCategories.map((t, i) => (
          <Link
            key={t.id}
            to="/tools"
            className="animate-fade-up"
            style={{ animationDelay: `${i * 50}ms` }}
          >
            <TiltCard>
              <div className="group relative h-full overflow-hidden rounded-2xl holo-border tilt-card">
                <div className="relative h-full overflow-hidden rounded-[15px] bg-[oklch(0.16_0.028_270)] p-6 backdrop-blur-md">
                  <Spotlight />
                  <div
                    className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full opacity-40 blur-3xl transition-opacity duration-500 group-hover:opacity-90"
                    style={{ background: "radial-gradient(circle, oklch(0.82 0.16 200 / 0.6), transparent 70%)" }}
                  />
                  <div className="flex items-center gap-3">
                    <div className="relative inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-cyan/30 to-brand-blue/10 text-brand-cyan ring-1 ring-white/10 transition-transform duration-500 group-hover:scale-110 group-hover:-translate-y-0.5">
                      <t.icon className="h-5 w-5" />
                      <span
                        className="pointer-events-none absolute inset-0 rounded-xl opacity-0 blur-md transition-opacity duration-500 group-hover:opacity-80"
                        style={{ background: "oklch(0.82 0.16 200 / 0.6)" }}
                      />
                    </div>
                    <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-[0.18em] text-brand-cyan">
                      Free
                    </span>
                  </div>
                  <h3 className="mt-5 font-display text-lg font-semibold tracking-tight">{t.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{t.description}</p>
                  <div className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-brand-cyan opacity-80 transition-opacity group-hover:opacity-100">
                    Open tools <ArrowUpRight className="h-3.5 w-3.5" />
                  </div>
                </div>
              </div>
            </TiltCard>
          </Link>
        ))}
      </div>
    </section>
  );
}

/* ─── About Preview ──────────────────────────────────────── */
function AboutPreview() {
  return (
    <section className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full glass px-3.5 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-brand-cyan">
              <MapPin className="h-3 w-3" /> Kurukshetra · Haryana · India
            </span>
            <h2 className="mt-5 font-display text-3xl font-bold leading-tight tracking-tight sm:text-4xl md:text-5xl">
              A digital studio built for the{" "}
              <span className="gradient-brand-text">next generation</span> of internet businesses.
            </h2>
            <p className="mt-5 text-muted-foreground">
              We're a Kurukshetra-based team obsessed with shipping. Whether it's a
              hand-crafted website, an SEO program that quietly climbs Google, a custom API
              for your product, or an automation that gives you hours back every week — we
              build the digital backbone modern businesses run on.
            </p>
            <ul className="mt-6 space-y-2 text-sm">
              {[
                "Website design & development for startups and SMBs",
                "Technical SEO and Google ranking systems",
                "Custom APIs, automation and Telegram / WhatsApp bots",
                "A growing marketplace of digital products and tools",
              ].map((line) => (
                <li key={line} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 flex-none text-brand-cyan" />
                  <span className="text-muted-foreground">{line}</span>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="hero">
                <Link to="/about">Our story <ArrowRight className="h-4 w-4" /></Link>
              </Button>
              <Button asChild variant="glass">
                <Link to="/contact">
                  <MessageCircle className="h-4 w-4" /> Talk to us
                </Link>
              </Button>
            </div>
          </div>

          <div className="relative animate-scale-fade-in">
            <div className="relative overflow-hidden rounded-3xl glass-strong p-6 glow-multi">
              <Spotlight />
              <div className="grid grid-cols-2 gap-3">
                {[
                  { k: "Founded", v: site.brand.founded, sub: "Quietly shipping since" },
                  { k: "Based in", v: "Kurukshetra", sub: "Haryana, India" },
                  { k: "Focus", v: "Web · SEO · API", sub: "& automation" },
                  { k: "Clients", v: "80+", sub: "Across 14 countries" },
                ].map((s) => (
                  <div key={s.k} className="rounded-xl border border-white/5 bg-white/[0.02] p-4">
                    <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{s.k}</p>
                    <p className="mt-2 font-display text-2xl font-bold gradient-brand-text">{s.v}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">{s.sub}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 rounded-xl border border-white/5 bg-gradient-to-br from-brand-blue/10 via-transparent to-brand-violet/10 p-4">
                <p className="text-xs text-muted-foreground">
                  "We don't sell hours. We sell shipped, measurable, ranked, automated
                  outcomes — built to a higher bar than templates."
                </p>
                <p className="mt-2 text-[11px] uppercase tracking-[0.18em] text-brand-cyan">
                  — Nitin Kamboj, Founder
                </p>
              </div>
            </div>
            <div className="pointer-events-none absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-tr from-brand-blue/30 via-brand-cyan/20 to-brand-violet/30 blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── Testimonials ──────────────────────────────────────── */
function Testimonials() {
  const items = [
    {
      name: "Rohan Mehta",
      role: "Founder, CommerceLane",
      type: "E-commerce build + SEO",
      stars: 5,
      quote:
        "Web Studio KKR rebuilt our Shopify store and shipped the SEO foundation in 3 weeks. Organic traffic is up 4.2× in 6 months. Genuinely premium work.",
    },
    {
      name: "Sneha Kapoor",
      role: "Marketing Head, Brightline",
      type: "WhatsApp + Telegram automation",
      stars: 5,
      quote:
        "The WhatsApp Business API + Telegram bot combo they built handles 60% of our pre-sales conversations now. The bots feel human. The dashboards are beautiful.",
    },
    {
      name: "Arjun Verma",
      role: "Indie SaaS founder",
      type: "Landing page + custom API",
      stars: 5,
      quote:
        "From wireframe to deployed API + landing page in 11 days. Code quality is excellent, docs were ready on day one. Easiest agency engagement I've had.",
    },
  ];
  return (
    <section className="relative py-24">
      <div className="container mx-auto px-4">
        <SectionHeading
          eyebrow="Clients · Words"
          title="Premium work,"
          highlight="quietly remarkable results."
          description="A few words from the founders and operators we've shipped with."
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {items.map((t, i) => (
            <TiltCard key={t.name}>
              <div
                className="group relative h-full overflow-hidden rounded-2xl glass-strong p-7 tilt-card animate-fade-up"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <Spotlight />
                <Quote className="h-7 w-7 text-brand-cyan opacity-60" />
                <p className="mt-3 text-sm leading-relaxed text-foreground/90">"{t.quote}"</p>

                <div className="mt-5 flex items-center gap-1 text-brand-cyan">
                  {Array.from({ length: t.stars }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-current" />
                  ))}
                </div>

                <div className="mt-5 flex items-center gap-3 border-t border-white/10 pt-5">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-brand-blue/40 to-brand-violet/30 font-display text-base font-bold ring-1 ring-white/10">
                    {t.name.split(" ").map((w) => w[0]).join("")}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate font-display text-sm font-semibold">{t.name}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{t.role}</p>
                  </div>
                </div>
                <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-[10px] uppercase tracking-[0.16em] text-brand-cyan">
                  <Zap className="h-3 w-3" /> {t.type}
                </div>
              </div>
            </TiltCard>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Highlights ────────────────────────────────────────── */
function Highlights() {
  return (
    <section className="container mx-auto px-4 py-20">
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {highlights.map((h, i) => (
          <TiltCard key={h.title}>
            <div
              className="h-full rounded-2xl glass p-6 tilt-card animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-brand-blue/30 to-brand-violet/20 text-brand-cyan ring-1 ring-white/10">
                <h.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-base font-semibold tracking-tight">{h.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{h.description}</p>
            </div>
          </TiltCard>
        ))}
      </div>
    </section>
  );
}

/* ─── Process ───────────────────────────────────────────── */
function Process() {
  const steps = [
    { n: "01", t: "Discovery", d: "Understand your business, your users and your goals. No assumptions." },
    { n: "02", t: "Design", d: "Wireframes, brand-aligned UI, motion and prototypes — reviewed at every step." },
    { n: "03", t: "Build", d: "Production-grade code, tested, documented, on modern infrastructure." },
    { n: "04", t: "Launch & grow", d: "Deploy, monitor, optimise SEO and iterate as your business scales." },
  ];
  return (
    <section className="container mx-auto px-4 py-20">
      <SectionHeading
        eyebrow="How we work"
        title="A clear, calm process —"
        highlight="from idea to launch."
        description="Four phases. No surprises. Every milestone has a tangible deliverable you can review."
      />
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {steps.map((s, i) => (
          <TiltCard key={s.n}>
            <div className="relative h-full rounded-2xl glass p-6 tilt-card animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
              <p className="gradient-brand-text font-display text-5xl font-bold tracking-tight">{s.n}</p>
              <h3 className="mt-3 font-display text-lg font-semibold tracking-tight">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          </TiltCard>
        ))}
      </div>
    </section>
  );
}

/* ─── SEO Content blocks ────────────────────────────────── */
function SeoContent() {
  const blocks = [
    {
      h: "Best Digital Marketing Services in Kurukshetra",
      p: "Looking for a full-service digital marketing partner in Kurukshetra? Web Studio KKR combines SEO, performance marketing, content, automation and conversion design under one roof — built around measurable business outcomes, not vanity metrics.",
    },
    {
      h: "Website Designing Services in Kurukshetra",
      p: "We design distinctive, conversion-focused websites for Kurukshetra startups, local businesses and growing brands — every layout is hand-crafted in modern tooling, never spun out of a generic theme.",
    },
    {
      h: "Website Development Services in Kurukshetra",
      p: "From marketing sites to SaaS platforms and admin dashboards, our Kurukshetra-based development team ships fast, well-architected React, Next.js and TanStack Start applications ready for production traffic.",
    },
    {
      h: "SEO Services in Kurukshetra",
      p: "Technical SEO audits, on-page optimisation, schema markup, internal linking, content roadmaps and authority building — our SEO programs are built to compound over months, not vanish at the next algorithm update.",
    },
    {
      h: "Telegram Bot Development Services",
      p: "We build production-grade Telegram bots — earning bots, channel managers, payment bots, AI assistants, broadcasting systems — deployed to your own infrastructure with proper logging, analytics and admin panels.",
    },
    {
      h: "Custom API Development Services",
      p: "Need a robust API for your product, mobile app or internal team? We design and ship REST & GraphQL APIs with authentication, rate limiting, webhooks, queues and rigorous OpenAPI documentation.",
    },
    {
      h: "Business Automation Services",
      p: "Stop paying humans to do robot work. We automate reporting, lead routing, scraping, alerting, billing and back-office workflows — saving teams hours every single week.",
    },
    {
      h: "WhatsApp API Integration Services",
      p: "Official WhatsApp Business Cloud API setup, template management, broadcast systems, chatbots and CRM sync — built to scale conversations without breaking compliance.",
    },
    {
      h: "Video Editing Services in Kurukshetra",
      p: "Cinematic edits, motion graphics, product videos, reels and shorts — built for founders and marketers who want premium output without a Mumbai-sized retainer.",
    },
    {
      h: "Graphic Design Services in Kurukshetra",
      p: "Distinctive logos, brand identity systems and marketing creatives — designed on real typographic foundations, not Canva templates.",
    },
    {
      h: "Local SEO Services",
      p: "Win the Map Pack and dominate \"near me\" searches. We optimise Google Business Profiles, build local citations, generate reviews and structure local landing pages that rank.",
    },
    {
      h: "Google Ranking Services",
      p: "From keyword research to content production to link earning — our end-to-end Google ranking programs are built for businesses that want sustainable organic traffic, not a temporary spike.",
    },
  ];
  return (
    <section className="relative py-24">
      <div className="pointer-events-none absolute inset-0 -z-10 mesh-bg opacity-50" />
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full glass px-3.5 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-brand-cyan">
            <Search className="h-3 w-3" /> Services across India &amp; beyond
          </span>
          <h2 className="mt-5 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Premium digital services,{" "}
            <span className="gradient-brand-text">trusted across Kurukshetra</span> and beyond.
          </h2>
          <p className="mt-4 text-muted-foreground">
            We work with founders, local businesses and global teams — the work we do for
            each is exactly the same: production-grade, measurable, and built to last.
          </p>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {blocks.map((b, i) => (
            <article
              key={b.h}
              className="group relative overflow-hidden rounded-2xl glass p-6 hover-lift animate-fade-up"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <Spotlight />
              <h3 className="font-display text-base font-semibold leading-snug tracking-tight">
                {b.h}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.p}</p>
              <Link
                to="/contact"
                className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-brand-cyan opacity-80 transition-opacity group-hover:opacity-100"
              >
                Get a free quote <ArrowUpRight className="h-3 w-3" />
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Section heading helper ───────────────────────────── */
function SectionHeading({
  eyebrow,
  title,
  highlight,
  description,
}: {
  eyebrow: string;
  title: string;
  highlight: string;
  description: string;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <span className="inline-flex items-center gap-2 rounded-full glass px-3.5 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-brand-cyan">
        {eyebrow}
      </span>
      <h2 className="mt-5 font-display text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
        {title} <span className="gradient-brand-text">{highlight}</span>
      </h2>
      <p className="mx-auto mt-4 max-w-xl text-muted-foreground">{description}</p>
    </div>
  );
}

/* tiny inline search icon (avoid extra import at top) */
function Search(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
         strokeLinecap="round" strokeLinejoin="round" {...props}>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}
