import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Save, Star, Flame, Loader2 } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Drawer } from "./admin.services";
import {
  deleteProduct,
  listCategories,
  listProductsAdmin,
  slugify,
  upsertProduct,
  type Product,
  type ProductInsert,
} from "@/lib/cms/queries";

export const Route = createFileRoute("/admin/products")({
  head: () => ({ meta: [{ title: "Products — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ProductsManager,
});

type Draft = {
  id?: string;
  title: string;
  slug: string;
  category_id: string | null;
  description: string;
  long_description: string;
  price: number;
  compare_at_price: number | null;
  currency: string;
  image: string;
  gallery: string; // newline-separated URLs
  features: string; // newline-separated feature bullets
  faqs: string; // JSON string [{q,a}]
  demo_url: string;
  download_url: string;
  featured: boolean;
  popular: boolean;
  trending: boolean;
  status: "draft" | "published" | "archived";
  seo_title: string;
  seo_description: string;
};

const emptyDraft = (): Draft => ({
  title: "",
  slug: "",
  category_id: null,
  description: "",
  long_description: "",
  price: 0,
  compare_at_price: null,
  currency: "INR",
  image: "",
  gallery: "",
  features: "",
  faqs: "[]",
  demo_url: "",
  download_url: "",
  featured: false,
  popular: false,
  trending: false,
  status: "published",
  seo_title: "",
  seo_description: "",
});

function productToDraft(p: Product): Draft {
  const gallery = ((p.gallery ?? []) as string[]).join("\n");
  const features = ((p.features ?? []) as string[]).join("\n");
  let faqs = "[]";
  try {
    faqs = JSON.stringify(p.faqs ?? [], null, 2);
  } catch {
    faqs = "[]";
  }
  return {
    id: p.id,
    title: p.title,
    slug: p.slug,
    category_id: p.category_id,
    description: p.description ?? "",
    long_description: p.long_description ?? "",
    price: Number(p.price ?? 0),
    compare_at_price: p.compare_at_price != null ? Number(p.compare_at_price) : null,
    currency: p.currency ?? "INR",
    image: p.image ?? "",
    gallery,
    features,
    faqs,
    demo_url: p.demo_url ?? "",
    download_url: p.download_url ?? "",
    featured: !!p.featured,
    popular: !!p.popular,
    trending: !!p.trending,
    status: p.status as Draft["status"],
    seo_title: p.seo_title ?? "",
    seo_description: p.seo_description ?? "",
  };
}

function ProductsManager() {
  const qc = useQueryClient();
  const productsQ = useQuery({
    queryKey: ["admin", "products"],
    queryFn: listProductsAdmin,
  });
  const catsQ = useQuery({
    queryKey: ["categories", "product"],
    queryFn: () => listCategories("product"),
  });
  const [editing, setEditing] = useState<Draft | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("all");

  const saveMut = useMutation({
    mutationFn: async (d: Draft) => {
      const gallery = d.gallery
        .split(/\r?\n/)
        .map((s) => s.trim())
        .filter(Boolean);
      const features = d.features
        .split(/\r?\n/)
        .map((s) => s.trim())
        .filter(Boolean);
      let faqs: unknown = [];
      try {
        const parsed = JSON.parse(d.faqs || "[]");
        if (Array.isArray(parsed)) faqs = parsed;
      } catch {
        throw new Error("FAQs must be valid JSON, e.g. [{\"q\":\"…\",\"a\":\"…\"}]");
      }
      const payload: ProductInsert = {
        title: d.title,
        slug: d.slug || slugify(d.title),
        category_id: d.category_id,
        description: d.description,
        long_description: d.long_description,
        price: d.price,
        compare_at_price: d.compare_at_price,
        currency: d.currency,
        image: d.image,
        gallery,
        features,
        faqs: faqs as ProductInsert["faqs"],
        demo_url: d.demo_url,
        download_url: d.download_url,
        featured: d.featured,
        popular: d.popular,
        trending: d.trending,
        status: d.status,
        seo_title: d.seo_title,
        seo_description: d.seo_description,
      };
      return upsertProduct(d.id ? { id: d.id, ...payload } : payload);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "products"] });
      qc.invalidateQueries({ queryKey: ["public", "products"] });
      setEditing(null);
      setSaveError(null);
    },
    onError: (err: Error) => setSaveError(err.message),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteProduct(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "products"] });
      qc.invalidateQueries({ queryKey: ["public", "products"] });
    },
  });

  const products = productsQ.data ?? [];
  const categories = catsQ.data ?? [];

  const filtered = useMemo(
    () =>
      filter === "all"
        ? products
        : products.filter((p) => p.category?.slug === filter),
    [products, filter],
  );

  return (
    <AdminShell title="Products">
      <PageHeader
        title="Marketplace products"
        description="Source codes, bots, APIs, templates, panels and digital assets."
        action={
          <Button
            variant="brand"
            onClick={() => {
              setSaveError(null);
              setEditing(emptyDraft());
            }}
          >
            <Plus className="h-4 w-4" /> New product
          </Button>
        }
      />

      <div className="mb-4 flex flex-wrap gap-2">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
          All ({products.length})
        </FilterChip>
        {categories.map((c) => {
          const count = products.filter((p) => p.category?.slug === c.slug).length;
          return (
            <FilterChip
              key={c.id}
              active={filter === c.slug}
              onClick={() => setFilter(c.slug)}
            >
              {c.name} ({count})
            </FilterChip>
          );
        })}
      </div>

      {productsQ.isLoading ? (
        <GlassCard className="text-center">
          <Loader2 className="mx-auto h-4 w-4 animate-spin text-muted-foreground" />
        </GlassCard>
      ) : productsQ.isError ? (
        <GlassCard className="text-center text-destructive text-sm">
          {(productsQ.error as Error).message}
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => (
            <GlassCard key={p.id} className="flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-brand-cyan">
                    {p.category?.name ?? "Uncategorised"}
                  </div>
                  <div className="font-display text-base font-semibold">{p.title}</div>
                </div>
                <div className="flex gap-1">
                  {p.featured ? <Star className="h-3.5 w-3.5 text-amber-400" /> : null}
                  {p.popular ? <Flame className="h-3.5 w-3.5 text-pink-400" /> : null}
                </div>
              </div>
              <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{p.description}</p>
              <div className="mt-3 font-display text-xl font-semibold">
                ₹{Number(p.price).toLocaleString()}
              </div>
              <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                {p.status}
              </div>
              <div className="mt-4 flex justify-end gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setSaveError(null);
                    setEditing(productToDraft(p));
                  }}
                >
                  Edit
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  disabled={deleteMut.isPending}
                  onClick={() => {
                    if (confirm(`Delete "${p.title}"?`)) deleteMut.mutate(p.id);
                  }}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </GlassCard>
          ))}
          {filtered.length === 0 ? (
            <GlassCard className="col-span-full text-center text-muted-foreground">
              No products in this category yet.
            </GlassCard>
          ) : null}
        </div>
      )}

      {editing ? (
        <Drawer
          title={editing.id ? "Edit product" : "New product"}
          onClose={() => setEditing(null)}
        >
          <div className="space-y-4">
            <Field label="Title">
              <Input
                value={editing.title}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    title: e.target.value,
                    slug: editing.slug || slugify(e.target.value),
                  })
                }
              />
            </Field>
            <Field label="Slug">
              <Input
                value={editing.slug}
                onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Category">
                <select
                  value={editing.category_id ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, category_id: e.target.value || null })
                  }
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  <option value="">— None —</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Status">
                <select
                  value={editing.status}
                  onChange={(e) =>
                    setEditing({ ...editing, status: e.target.value as Draft["status"] })
                  }
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </Field>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Price">
                <Input
                  type="number"
                  step="0.01"
                  value={editing.price}
                  onChange={(e) => setEditing({ ...editing, price: Number(e.target.value) })}
                />
              </Field>
              <Field label="Compare at">
                <Input
                  type="number"
                  step="0.01"
                  value={editing.compare_at_price ?? ""}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      compare_at_price: e.target.value ? Number(e.target.value) : null,
                    })
                  }
                />
              </Field>
              <Field label="Currency">
                <Input
                  value={editing.currency}
                  onChange={(e) => setEditing({ ...editing, currency: e.target.value })}
                />
              </Field>
            </div>
            <Field label="Short description">
              <Textarea
                rows={2}
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              />
            </Field>
            <Field label="Long description (Markdown)">
              <Textarea
                rows={6}
                value={editing.long_description}
                onChange={(e) =>
                  setEditing({ ...editing, long_description: e.target.value })
                }
              />
            </Field>
            <Field label="Cover image URL">
              <Input
                value={editing.image}
                onChange={(e) => setEditing({ ...editing, image: e.target.value })}
              />
            </Field>
            <Field label="Gallery image URLs (one per line)">
              <Textarea
                rows={4}
                value={editing.gallery}
                onChange={(e) => setEditing({ ...editing, gallery: e.target.value })}
                placeholder="https://…/screenshot-1.jpg&#10;https://…/screenshot-2.jpg"
              />
            </Field>
            <Field label="Features (one per line)">
              <Textarea
                rows={5}
                value={editing.features}
                onChange={(e) => setEditing({ ...editing, features: e.target.value })}
                placeholder="Fully responsive design&#10;Production-ready code&#10;Free updates for 12 months"
              />
            </Field>
            <Field label='FAQs (JSON array of {"q","a"})'>
              <Textarea
                rows={6}
                value={editing.faqs}
                onChange={(e) => setEditing({ ...editing, faqs: e.target.value })}
                placeholder='[{"q":"Do you offer support?","a":"Yes — 30 days included."}]'
                className="font-mono text-xs"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Demo URL">
                <Input
                  value={editing.demo_url}
                  onChange={(e) => setEditing({ ...editing, demo_url: e.target.value })}
                />
              </Field>
              <Field label="Download URL">
                <Input
                  value={editing.download_url}
                  onChange={(e) => setEditing({ ...editing, download_url: e.target.value })}
                />
              </Field>
            </div>
            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={editing.featured}
                  onChange={(e) => setEditing({ ...editing, featured: e.target.checked })}
                />
                Featured
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={editing.trending}
                  onChange={(e) => setEditing({ ...editing, trending: e.target.checked })}
                />
                Trending
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={editing.popular}
                  onChange={(e) => setEditing({ ...editing, popular: e.target.checked })}
                />
                Popular
              </label>
            </div>
            <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
              <div className="mb-2 text-xs uppercase tracking-wider text-muted-foreground">SEO</div>
              <div className="space-y-3">
                <Field label="SEO Title">
                  <Input
                    value={editing.seo_title}
                    onChange={(e) => setEditing({ ...editing, seo_title: e.target.value })}
                  />
                </Field>
                <Field label="SEO Description">
                  <Textarea
                    rows={2}
                    value={editing.seo_description}
                    onChange={(e) =>
                      setEditing({ ...editing, seo_description: e.target.value })
                    }
                  />
                </Field>
              </div>
            </div>

            {saveError ? (
              <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                {saveError}
              </div>
            ) : null}

            <Button
              variant="brand"
              className="w-full"
              disabled={saveMut.isPending || !editing.title.trim()}
              onClick={() => saveMut.mutate(editing)}
            >
              {saveMut.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              Save product
            </Button>
          </div>
        </Drawer>
      ) : null}
    </AdminShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
        active
          ? "border-brand-cyan/40 bg-brand-cyan/10 text-foreground"
          : "border-white/10 bg-white/[0.02] text-muted-foreground hover:border-white/20"
      }`}
    >
      {children}
    </button>
  );
}
