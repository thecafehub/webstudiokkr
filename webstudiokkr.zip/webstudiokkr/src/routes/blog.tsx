import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calendar, Eye, Loader2, Search, Sparkles, Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { Spotlight } from "@/components/effects/Spotlight";
import { site } from "@/config/site";
import {
  listBlogsPublic,
  listCategories,
  listFeaturedBlogs,
  listPopularBlogs,
  type Blog,
} from "@/lib/cms/queries";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: `Blog — ${site.brand.name}` },
      {
        name: "description",
        content:
          "Long-form guides on web development, SEO, automation, bots and modern digital business — by the Web Studio KKR team.",
      },
      { property: "og:title", content: `Blog — ${site.brand.name}` },
      { property: "og:description", content: "Guides on web, SEO, automation and modern digital business." },
      { property: "og:url", content: `${site.brand.url}/blog` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/blog` }],
  }),
  component: BlogPage,
});

function BlogPage() {
  const postsQ = useQuery({ queryKey: ["public", "blogs"], queryFn: listBlogsPublic });
  const featuredQ = useQuery({ queryKey: ["public", "blogs", "featured"], queryFn: () => listFeaturedBlogs(3) });
  const popularQ = useQuery({ queryKey: ["public", "blogs", "popular"], queryFn: () => listPopularBlogs(5) });
  const catsQ = useQuery({ queryKey: ["categories", "blog"], queryFn: () => listCategories("blog") });

  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");

  const posts = postsQ.data ?? [];
  const featured = featuredQ.data ?? [];
  const popular = popularQ.data ?? [];
  const categories = catsQ.data ?? [];

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return posts.filter((p) => {
      if (filter !== "all" && p.category?.slug !== filter) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        (p.excerpt ?? "").toLowerCase().includes(q) ||
        (p.body ?? "").toLowerCase().includes(q)
      );
    });
  }, [posts, query, filter]);

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Blog"
        title="Notes from the"
        highlight="studio."
        description="Long-form guides on web development, SEO, automation and digital business."
      />

      {/* Featured */}
      {featured.length > 0 ? (
        <section className="container mx-auto px-4 pb-10">
          <div className="mb-5 flex items-end justify-between">
            <div>
              <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
                <Star className="mb-1 mr-2 inline h-4 w-4 text-amber-400" />
                Featured articles
              </h2>
              <p className="text-xs text-muted-foreground md:text-sm">Editor-picked reads</p>
            </div>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {featured.map((p, i) => (
              <BlogCard key={p.id} post={p} index={i} />
            ))}
          </div>
        </section>
      ) : null}

      {/* Search + filters */}
      <section className="container mx-auto px-4 pb-6">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search articles…"
              className="pl-9"
              aria-label="Search articles"
            />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
            All
          </FilterChip>
          {categories.map((c) => (
            <FilterChip key={c.id} active={filter === c.slug} onClick={() => setFilter(c.slug)}>
              {c.name}
            </FilterChip>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 pb-12">
        <div className="grid gap-10 lg:grid-cols-[1fr_280px]">
          <div>
            {postsQ.isLoading ? (
              <div className="flex justify-center py-20 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
              </div>
            ) : postsQ.isError ? (
              <div className="rounded-2xl glass p-6 text-center text-sm text-destructive">
                Couldn't load posts: {(postsQ.error as Error).message}
              </div>
            ) : filtered.length === 0 ? (
              <div className="rounded-2xl glass p-10 text-center text-muted-foreground">
                <Sparkles className="mx-auto mb-3 h-5 w-5 text-brand-violet" />
                {query ? `No articles match "${query}".` : "New posts coming soon."}
              </div>
            ) : (
              <div className="grid gap-5 md:grid-cols-2">
                {filtered.map((p, i) => (
                  <BlogCard key={p.id} post={p} index={i} />
                ))}
              </div>
            )}
          </div>

          {/* Popular sidebar */}
          <aside className="space-y-6">
            {popular.length > 0 ? (
              <div className="rounded-2xl glass p-5">
                <h3 className="mb-3 inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-foreground/80">
                  <Eye className="h-3.5 w-3.5 text-brand-cyan" /> Most read
                </h3>
                <ul className="space-y-3 text-sm">
                  {popular.map((p) => (
                    <li key={p.id}>
                      <Link
                        to="/blog/$slug"
                        params={{ slug: p.slug }}
                        className="block leading-snug text-foreground/90 transition-colors hover:text-brand-cyan"
                      >
                        {p.title}
                      </Link>
                      <div className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                        {p.view_count} views
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {categories.length > 0 ? (
              <div className="rounded-2xl glass p-5">
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-foreground/80">
                  Categories
                </h3>
                <ul className="space-y-1.5 text-sm">
                  {categories.map((c) => {
                    const n = posts.filter((p) => p.category?.slug === c.slug).length;
                    return (
                      <li key={c.id}>
                        <button
                          onClick={() => setFilter(c.slug)}
                          className="flex w-full items-center justify-between text-left text-muted-foreground hover:text-foreground"
                        >
                          <span>{c.name}</span>
                          <span className="text-xs">{n}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ) : null}
          </aside>
        </div>
      </section>

      <CtaStrip
        title="Want first dibs on new posts?"
        description="Reach out and we'll add you to our early readers list — no spam, just craft."
      />
    </SiteLayout>
  );
}

function BlogCard({ post, index }: { post: Blog; index: number }) {
  return (
    <Link
      to="/blog/$slug"
      params={{ slug: post.slug }}
      className="group relative block overflow-hidden rounded-2xl glass p-6 hover-lift animate-fade-up"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <Spotlight />
      {post.featured_image ? (
        <div className="-mx-6 -mt-6 mb-5 aspect-[16/9] overflow-hidden rounded-t-2xl bg-white/5">
          <img
            src={post.featured_image}
            alt={post.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
      ) : null}
      <div className="flex items-center justify-between text-xs">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-brand-cyan">
          {post.category?.name ?? "Article"}
        </span>
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <Calendar className="h-3 w-3" />
          {post.publish_at
            ? new Date(post.publish_at).toLocaleDateString(undefined, {
                month: "short",
                day: "numeric",
                year: "numeric",
              })
            : "—"}
        </span>
      </div>
      <h3 className="mt-5 font-display text-lg font-semibold tracking-tight">{post.title}</h3>
      <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
        {post.excerpt}
      </p>
    </Link>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
        active
          ? "border-brand-cyan/40 bg-brand-cyan/10 text-foreground"
          : "border-white/10 bg-white/[0.02] text-muted-foreground hover:border-white/20"
      }`}
    >
      {children}
    </button>
  );
}

export { notFound };
