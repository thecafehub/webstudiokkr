import { createFileRoute } from "@tanstack/react-router";
import { Bot, CreditCard, MessageSquare, Send, Users, Zap } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/telegram-bot-development";
const TITLE = "Telegram Bot Development Services";
const DESC =
  "Custom Telegram bot development — earning bots, channel managers, payment bots and AI assistants. Built and deployed by Web Studio KKR.";

export const Route = createFileRoute("/telegram-bot-development")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Telegram Bot Development",
          provider: { "@type": "Organization", name: site.brand.name, url: site.brand.url },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Telegram Bots"
      title="Custom Telegram bot"
      highlight="development services."
      description="Earning bots, broadcast systems, payment bots, AI assistants and channel managers — engineered to run reliably at scale."
      intro="Telegram is the highest-leverage messaging surface for creators and operators. We build production-grade Telegram bots that handle payments, subscriptions, AI conversations, referrals and community management — without crashing under load."
      features={[
        { title: "Earning & referral bots", description: "Tasks, withdrawals, leaderboards and anti-fraud built in.", icon: Users },
        { title: "Payment bots", description: "UPI, Stripe, crypto and Telegram Stars — full reconciliation.", icon: CreditCard },
        { title: "AI assistant bots", description: "GPT/Gemini powered conversations with memory and tools.", icon: Bot },
        { title: "Broadcast systems", description: "Reach millions of users with smart batching and rate limiting.", icon: Send },
        { title: "Channel automation", description: "Auto-post, moderation, member onboarding and analytics.", icon: MessageSquare },
        { title: "Hardened deployments", description: "Webhook-first, autoscale, logging, alerting and backups.", icon: Zap },
      ]}
      benefits={[
        "Production-ready code, not toy examples",
        "Webhook + long-polling fallbacks",
        "Admin dashboard included with every bot",
        "Hosted on your VPS or our managed infra",
        "Source code ownership transferred to you",
        "Free 30-day post-launch support",
      ]}
      faqs={[
        { q: "Do you build earning / task bots?", a: "Yes — task systems, referral tracking, withdrawals, leaderboards and anti-fraud are our most common builds." },
        { q: "Can the bot accept payments?", a: "Yes. We integrate UPI, Razorpay, Stripe, crypto wallets and Telegram Stars depending on your audience and region." },
        { q: "Where will the bot be hosted?", a: "Your VPS, your cloud account, or our managed infrastructure. You always own the bot token and the source code." },
        { q: "How much does a Telegram bot cost?", a: "Simple bots start around ₹8,000. Full earning systems with payments, dashboard and broadcast typically range ₹25,000–₹1,50,000." },
      ]}
      inquirySource="landing_telegram_bot_development"
      inquiryTitle="Telegram Bot Development"
    />
  ),
});
