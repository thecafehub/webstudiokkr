import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Shield, UserPlus, Trash2 } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export const Route = createFileRoute("/admin/team")({
  head: () => ({ meta: [{ title: "Team & Roles — Admin" }, { name: "robots", content: "noindex" }] }),
  component: TeamManager,
});

type Role = "admin" | "manager" | "editor";
const ROLE_LABELS: Record<Role, string> = {
  admin: "Admin — full access",
  manager: "Manager — CRM + content + analytics",
  editor: "Editor — content + media",
};
const ROLE_COLORS: Record<Role, string> = {
  admin: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  manager: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  editor: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
};

type ProfileWithRoles = Tables<"profiles"> & { roles: Role[] };

async function loadTeam(): Promise<ProfileWithRoles[]> {
  const [{ data: profiles, error: pErr }, { data: roles, error: rErr }] = await Promise.all([
    supabase.from("profiles").select("*"),
    supabase.from("user_roles").select("user_id, role"),
  ]);
  if (pErr) throw pErr;
  if (rErr) throw rErr;
  const byUser = new Map<string, Role[]>();
  for (const r of roles ?? []) {
    const key = r.user_id as string;
    if (!byUser.has(key)) byUser.set(key, []);
    if (["admin", "manager", "editor"].includes(r.role as string)) {
      byUser.get(key)!.push(r.role as Role);
    }
  }
  return (profiles ?? [])
    .map((p) => ({ ...p, roles: byUser.get(p.id) ?? [] }))
    .filter((p) => p.roles.length > 0)
    .sort((a, b) => (a.email ?? "").localeCompare(b.email ?? ""));
}

function TeamManager() {
  const qc = useQueryClient();
  const { data: team = [], isLoading } = useQuery({
    queryKey: ["team"],
    queryFn: loadTeam,
  });

  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<Role>("editor");
  const [inviteMsg, setInviteMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  const grantMut = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: Role }) => {
      const { error } = await supabase
        .from("user_roles")
        .insert({ user_id: userId, role });
      if (error && !/duplicate/i.test(error.message)) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team"] }),
  });

  const revokeMut = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: Role }) => {
      const { error } = await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId)
        .eq("role", role);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["team"] }),
  });

  async function handleInvite(e: React.FormEvent) {
    e.preventDefault();
    setInviteMsg(null);
    const email = inviteEmail.trim().toLowerCase();
    if (!email) return;
    // Look up an existing profile by email.
    const { data: profile } = await supabase
      .from("profiles")
      .select("id, email")
      .eq("email", email)
      .maybeSingle();
    if (!profile) {
      setInviteMsg({
        type: "err",
        text: `No account found for ${email}. Ask them to sign up first at /admin/login, then come back and grant the role.`,
      });
      return;
    }
    await grantMut.mutateAsync({ userId: profile.id, role: inviteRole });
    setInviteMsg({ type: "ok", text: `Granted ${inviteRole} to ${email}.` });
    setInviteEmail("");
  }

  return (
    <AdminShell title="Team & Roles" requires="roles">
      <PageHeader
        title="Team members"
        description="Admins have full access. Managers handle CRM + analytics on top of content. Editors manage content and media only. Settings, integrations and roles stay admin-only."
      />

      <GlassCard className="mb-6">
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
          <UserPlus className="h-3.5 w-3.5" /> Grant a role
        </div>
        <form onSubmit={handleInvite} className="mt-3 flex flex-wrap items-end gap-2">
          <div className="flex-1 min-w-[240px]">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Email of existing account
            </label>
            <Input
              type="email"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              placeholder="teammate@example.com"
              className="mt-1"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Role
            </label>
            <select
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as Role)}
              className="mt-1 h-10 rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
            >
              <option value="editor">Editor</option>
              <option value="manager">Manager</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <Button type="submit" variant="brand">
            Grant role
          </Button>
        </form>
        {inviteMsg ? (
          <div
            className={`mt-3 rounded-md border px-3 py-2 text-xs ${
              inviteMsg.type === "ok"
                ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-300"
                : "border-amber-500/30 bg-amber-500/5 text-amber-300"
            }`}
          >
            {inviteMsg.text}
          </div>
        ) : null}
      </GlassCard>

      {isLoading ? (
        <GlassCard className="py-16 text-center text-muted-foreground">Loading team…</GlassCard>
      ) : team.length === 0 ? (
        <GlassCard className="py-16 text-center text-muted-foreground">
          No team members yet. Grant a role above to give someone admin-area access.
        </GlassCard>
      ) : (
        <div className="grid gap-3">
          {team.map((m) => (
            <GlassCard key={m.id} className="flex flex-wrap items-center justify-between gap-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 font-display text-sm font-semibold">
                  <Shield className="h-4 w-4 text-brand-cyan" />
                  {m.display_name || m.email || m.id}
                </div>
                <div className="text-xs text-muted-foreground">{m.email}</div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {m.roles.map((r) => (
                    <span
                      key={r}
                      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] ${ROLE_COLORS[r]}`}
                    >
                      {ROLE_LABELS[r]}
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Revoke ${r} from ${m.email}?`)) {
                            revokeMut.mutate({ userId: m.id, role: r });
                          }
                        }}
                        className="ml-1 opacity-70 hover:opacity-100"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                {(["editor", "manager", "admin"] as Role[])
                  .filter((r) => !m.roles.includes(r))
                  .map((r) => (
                    <Button
                      key={r}
                      size="sm"
                      variant="outline"
                      onClick={() => grantMut.mutate({ userId: m.id, role: r })}
                    >
                      + {r}
                    </Button>
                  ))}
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </AdminShell>
  );
}
