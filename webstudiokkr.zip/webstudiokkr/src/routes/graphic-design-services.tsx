import { createFileRoute } from "@tanstack/react-router";
import { Image as ImageIcon, Layers, Palette, PenTool, Shapes, Type } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/graphic-design-services";
const TITLE = "Graphic Design Services";
const DESC =
  "Premium graphic design services — logos, brand identity, marketing creatives, social media kits and print design by Web Studio KKR.";

export const Route = createFileRoute("/graphic-design-services")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Graphic Design",
          provider: { "@type": "Organization", name: site.brand.name, url: site.brand.url },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Design"
      title="Graphic design that"
      highlight="says something."
      description="Distinctive logos, brand systems, social creatives and marketing assets — designed with real typography, not template clichés."
      intro="Your visual identity is the first thing prospects judge. We build brand systems that feel premium, scale across every surface, and don't look like the 100 other brands using the same Canva template."
      features={[
        { title: "Logo & wordmarks", description: "Distinctive marks designed from scratch — never AI-spat-out.", icon: PenTool },
        { title: "Brand identity systems", description: "Colors, type, motion, voice — the full toolkit, documented.", icon: Palette },
        { title: "Marketing creatives", description: "Ad banners, hero images, email graphics — on-brand and scroll-stopping.", icon: ImageIcon },
        { title: "Social media kits", description: "Templates for Instagram, LinkedIn, YouTube — consistent and fast to publish.", icon: Layers },
        { title: "Print & packaging", description: "Business cards, brochures, packaging — production-ready files.", icon: Shapes },
        { title: "Typography systems", description: "Type pairings that look intentional, not random.", icon: Type },
      ]}
      benefits={[
        "Source files in AI / Figma / PSD",
        "Brand guidelines PDF included",
        "Unlimited revisions inside each round",
        "Vector files — scale to any size",
        "Color and type tokens for handoff",
        "Real designers, not template assemblers",
      ]}
      faqs={[
        { q: "How long does a logo project take?", a: "Typical timeline is 7–14 days, with 2 concept rounds and refinements. Rush delivery is possible." },
        { q: "What's included in a brand identity package?", a: "Logo (primary, secondary, mark), color palette, typography system, usage guidelines, basic stationery and social profile assets." },
        { q: "Do you give source files?", a: "Yes — full editable source files in your preferred format, plus exports for web and print." },
      ]}
      inquirySource="landing_graphic_design"
      inquiryTitle="Graphic Design Services"
    />
  ),
});
