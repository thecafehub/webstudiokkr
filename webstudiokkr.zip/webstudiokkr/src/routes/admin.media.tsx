import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Upload, Trash2, Copy, Link as LinkIcon, FolderPlus, Search } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  listMedia,
  listFolders,
  uploadMediaFile,
  addExternalMedia,
  deleteMedia,
  type MediaItem,
} from "@/lib/cms/media";

export const Route = createFileRoute("/admin/media")({
  head: () => ({ meta: [{ title: "Media — Admin" }, { name: "robots", content: "noindex" }] }),
  component: MediaLibrary,
});

function MediaLibrary() {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [folder, setFolder] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [newFolder, setNewFolder] = useState("");
  const [uploading, setUploading] = useState(false);
  const [externalUrl, setExternalUrl] = useState("");

  const { data: folders = [] } = useQuery({
    queryKey: ["media", "folders"],
    queryFn: listFolders,
  });
  const allFolders = useMemo(() => {
    const set = new Set<string>(folders);
    if (newFolder) set.add(newFolder);
    return Array.from(set);
  }, [folders, newFolder]);

  const { data: media = [], isLoading } = useQuery({
    queryKey: ["media", folder, search],
    queryFn: () => listMedia({ folder, search }),
  });

  const uploadMut = useMutation({
    mutationFn: async (files: FileList) => {
      const target = folder === "all" ? newFolder || "general" : folder;
      for (const file of Array.from(files)) {
        await uploadMediaFile(file, target);
      }
    },
    onMutate: () => setUploading(true),
    onSettled: () => {
      setUploading(false);
      qc.invalidateQueries({ queryKey: ["media"] });
    },
  });

  const externalMut = useMutation({
    mutationFn: () => {
      const target = folder === "all" ? newFolder || "general" : folder;
      const name = externalUrl.split("/").pop() ?? externalUrl;
      return addExternalMedia({ name, url: externalUrl, folder: target });
    },
    onSuccess: () => {
      setExternalUrl("");
      qc.invalidateQueries({ queryKey: ["media"] });
    },
  });

  const delMut = useMutation({
    mutationFn: deleteMedia,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["media"] }),
  });

  return (
    <AdminShell title="Media Library" requires="media">
      <PageHeader
        title="Media"
        description="Upload images for blogs, products and pages. Organise by folder, search by name, copy URLs to paste anywhere."
        action={
          <div className="flex items-center gap-2">
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="image/*,video/*,application/pdf"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.length) uploadMut.mutate(e.target.files);
                e.target.value = "";
              }}
            />
            <Button
              variant="brand"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
            >
              <Upload className="h-4 w-4" /> {uploading ? "Uploading…" : "Upload files"}
            </Button>
          </div>
        }
      />

      <div className="mb-5 grid gap-3 lg:grid-cols-[260px_1fr] lg:items-end">
        <div>
          <Label>Folder</Label>
          <select
            value={folder}
            onChange={(e) => setFolder(e.target.value)}
            className="mt-1 h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
          >
            <option value="all">All folders</option>
            {allFolders.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-0 flex-1">
            <Label>Search</Label>
            <div className="relative mt-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name…"
                className="pl-9"
              />
            </div>
          </div>
          <div>
            <Label>Create folder</Label>
            <div className="mt-1 flex gap-2">
              <Input
                value={newFolder}
                onChange={(e) => setNewFolder(e.target.value.replace(/[^a-z0-9-_]/gi, "").toLowerCase())}
                placeholder="new-folder"
                className="w-40"
              />
              <Button
                variant="outline"
                disabled={!newFolder}
                onClick={() => {
                  setFolder(newFolder);
                  setNewFolder("");
                }}
              >
                <FolderPlus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <GlassCard className="mb-6">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Add external image by URL
        </div>
        <div className="mt-2 flex gap-2">
          <Input
            value={externalUrl}
            onChange={(e) => setExternalUrl(e.target.value)}
            placeholder="https://…/image.jpg"
            className="flex-1"
          />
          <Button
            variant="outline"
            disabled={!externalUrl.trim() || externalMut.isPending}
            onClick={() => externalMut.mutate()}
          >
            <LinkIcon className="h-4 w-4" /> Add URL
          </Button>
        </div>
      </GlassCard>

      {isLoading ? (
        <GlassCard className="py-16 text-center text-muted-foreground">Loading media…</GlassCard>
      ) : media.length === 0 ? (
        <GlassCard className="py-16 text-center text-muted-foreground">
          No media yet. Upload files or add an external URL.
        </GlassCard>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {media.map((m) => (
            <MediaCard
              key={m.id}
              item={m}
              onCopy={() => navigator.clipboard.writeText(m.url)}
              onDelete={() => {
                if (confirm(`Delete ${m.name}?`)) delMut.mutate(m);
              }}
            />
          ))}
        </div>
      )}
    </AdminShell>
  );
}

function MediaCard({
  item,
  onCopy,
  onDelete,
}: {
  item: MediaItem;
  onCopy: () => void;
  onDelete: () => void;
}) {
  const isImage = (item.mime_type ?? "").startsWith("image/") || /\.(png|jpe?g|gif|webp|svg|avif)$/i.test(item.url);
  return (
    <GlassCard className="p-3">
      {isImage ? (
        <img
          src={item.url}
          alt={item.alt_text ?? item.name}
          loading="lazy"
          className="aspect-square w-full rounded-lg object-cover"
        />
      ) : (
        <div className="grid aspect-square w-full place-items-center rounded-lg bg-white/[0.04] text-xs text-muted-foreground">
          {item.mime_type ?? "file"}
        </div>
      )}
      <div className="mt-2 truncate text-xs" title={item.name}>
        {item.name}
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
        <span>{item.folder}</span>
        <span>{item.size_bytes ? `${(item.size_bytes / 1024).toFixed(1)} KB` : "—"}</span>
      </div>
      <div className="mt-2 flex gap-1">
        <Button size="icon" variant="ghost" onClick={onCopy} title="Copy URL">
          <Copy className="h-3.5 w-3.5" />
        </Button>
        <Button size="icon" variant="ghost" onClick={onDelete} title="Delete">
          <Trash2 className="h-3.5 w-3.5 text-destructive" />
        </Button>
      </div>
    </GlassCard>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
      {children}
    </div>
  );
}
