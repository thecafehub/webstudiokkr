import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ArrowUpRight, RefreshCw } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { useCms } from "@/lib/admin/store";
import { fetchGa4 } from "@/lib/integrations/ga4.functions";
import { fetchGsc } from "@/lib/integrations/gsc.functions";
import { getIntegrationStatuses } from "@/lib/integrations/status";
import { emptyClarity } from "@/lib/integrations/demo";
import type { DataSource } from "@/lib/integrations/types";


export const Route = createFileRoute("/admin/analytics")({
  head: () => ({ meta: [{ title: "Analytics — Admin" }, { name: "robots", content: "noindex" }] }),
  component: AnalyticsPage,
});

const COLORS = [
  "oklch(0.65 0.21 255)",
  "oklch(0.78 0.18 215)",
  "oklch(0.62 0.22 295)",
  "oklch(0.70 0.22 350)",
  "oklch(0.74 0.18 145)",
];

function AnalyticsPage() {
  const integrations = useCms((s) => s.settings.integrations);
  const statuses = getIntegrationStatuses(integrations);
  const clarity = emptyClarity(integrations.clarityProjectId);

  const ga4Q = useQuery({
    queryKey: ["ga4", integrations.ga4PropertyId],
    queryFn: () =>
      fetchGa4({ data: { propertyId: integrations.ga4PropertyId || undefined } }),
    staleTime: 5 * 60_000,
  });

  const gscQ = useQuery({
    queryKey: ["gsc", integrations.gscSiteUrl],
    queryFn: () =>
      fetchGsc({ data: { siteUrl: integrations.gscSiteUrl || undefined } }),
    staleTime: 5 * 60_000,
  });

  const ga4Source = ga4Q.data?.source;
  const ga4 = ga4Q.data?.data;
  const gsc = gscQ.data?.data;

  const ga4Tracking = Boolean(integrations.ga4MeasurementId);
  const ga4Pending = ga4Source === "pending";
  const ga4Live = ga4Source === "live";

  return (
    <AdminShell title="Analytics">
      <PageHeader
        title="Traffic insights"
        description={
          ga4Live
            ? `Live GA4 data for property ${integrations.ga4PropertyId}.`
            : ga4Pending
              ? `GA4 ${integrations.ga4MeasurementId} is installed on every page. Reports below activate once API access is granted.`
              : ga4Tracking
                ? `GA4 ${integrations.ga4MeasurementId} is tracking. Add a Property ID in Settings to load reports here.`
                : "Add a GA4 Measurement ID in Settings to start tracking."
        }
        action={
          <div className="flex gap-2">
            {integrations.ga4PropertyId ? (
              <Button asChild variant="outline">
                <a
                  href={`https://analytics.google.com/analytics/web/#/p${integrations.ga4PropertyId}/reports`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ArrowUpRight className="h-4 w-4" /> Open GA4
                </a>
              </Button>
            ) : null}
            <Button
              variant="outline"
              onClick={() => {
                ga4Q.refetch();
                gscQ.refetch();
              }}
            >
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
          </div>
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {statuses.map((s) => (
          <GlassCard key={s.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                {s.label}
              </div>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                  s.connected
                    ? "bg-emerald-500/15 text-emerald-300"
                    : "bg-amber-500/15 text-amber-300"
                }`}
              >
                {s.connected ? "Connected" : "Setup"}
              </span>
            </div>
            <div className="mt-1 text-xs text-muted-foreground">{s.details}</div>
          </GlassCard>
        ))}
      </div>

      {ga4Pending ? (
        <GlassCard className="mb-4 border-emerald-500/30 bg-emerald-500/5">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              <span className="font-display text-base font-semibold text-emerald-100">
                Google Analytics Connected — Awaiting API Access
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Measurement ID <code className="rounded bg-black/30 px-1">{integrations.ga4MeasurementId}</code> and
              property <code className="rounded bg-black/30 px-1">{integrations.ga4PropertyId}</code> are wired up.
              Add a <code className="rounded bg-black/30 px-1">GA4_ACCESS_TOKEN</code> Cloud secret with the
              <code className="rounded bg-black/30 px-1">analytics.readonly</code> scope to unlock live Visitors,
              Sessions, Page Views, Top Pages, Devices, Countries and Traffic Sources reports here.
            </p>
          </div>
        </GlassCard>
      ) : null}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <KpiCard label="Users (180d)" value={formatKpi(ga4?.totals.users, ga4Source)} source={ga4Source} />
        <KpiCard label="Sessions" value={formatKpi(ga4?.totals.sessions, ga4Source)} source={ga4Source} />
        <KpiCard label="Pageviews" value={formatKpi(ga4?.totals.pageviews, ga4Source)} source={ga4Source} />
        <KpiCard
          label="Avg session"
          value={
            ga4Live && ga4
              ? `${Math.floor(ga4.totals.avgSessionSeconds / 60)}m ${ga4.totals.avgSessionSeconds % 60}s`
              : "—"
          }
          source={ga4Source}
        />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <GlassCard className="lg:col-span-2">
          <PanelHeader title="Monthly visitors" source={ga4Source} reason={ga4Q.data?.reason} />
          {ga4Live && ga4?.monthly.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={ga4.monthly} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                <XAxis dataKey="label" stroke="oklch(1 0 0 / 0.4)" fontSize={11} />
                <YAxis stroke="oklch(1 0 0 / 0.4)" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.12 0.04 265)",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line type="monotone" dataKey="visitors" stroke="oklch(0.78 0.18 215)" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="sessions" stroke="oklch(0.65 0.21 255)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyPanel source={ga4Source} />
          )}
        </GlassCard>

        <GlassCard>
          <PanelHeader title="Traffic sources" source={ga4Source} />
          {ga4Live && ga4?.sources.length ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={ga4.sources} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90}>
                  {ga4.sources.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.12 0.04 265)",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <EmptyPanel source={ga4Source} />
          )}
        </GlassCard>

        <GlassCard className="lg:col-span-3">
          <PanelHeader title="Top pages" source={ga4Source} />
          {ga4Live && ga4?.topPages.length ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={ga4.topPages} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                <XAxis dataKey="path" stroke="oklch(1 0 0 / 0.4)" fontSize={11} />
                <YAxis stroke="oklch(1 0 0 / 0.4)" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.12 0.04 265)",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="views" fill="oklch(0.65 0.21 255)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <EmptyPanel source={ga4Source} />
          )}
        </GlassCard>

        <GlassCard>
          <PanelHeader title="Devices" source={ga4Source} />
          {ga4Live && ga4?.devices.length ? (
            <ul className="space-y-2 text-sm">
              {ga4.devices.map((d) => (
                <li key={d.name} className="flex items-center justify-between border-t border-white/5 pt-2">
                  <span>{d.name}</span>
                  <span className="text-muted-foreground">{d.value}%</span>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyPanel source={ga4Source} />
          )}
        </GlassCard>

        <GlassCard className="lg:col-span-2">
          <PanelHeader title="Top countries" source={ga4Source} />
          {ga4Live && ga4?.countries.length ? (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                  <th className="py-2">Country</th>
                  <th className="py-2 text-right">Share</th>
                </tr>
              </thead>
              <tbody>
                {ga4.countries.map((c) => (
                  <tr key={c.code} className="border-t border-white/5">
                    <td className="py-2">{c.name}</td>
                    <td className="py-2 text-right text-muted-foreground">{c.value}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <EmptyPanel source={ga4Source} />
          )}
        </GlassCard>

        <GlassCard className="lg:col-span-2">
          <PanelHeader title="Top queries — Search Console" source={gscQ.data?.source} reason={gscQ.data?.reason} />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                  <th className="py-2">Query</th>
                  <th className="py-2 text-right">Clicks</th>
                  <th className="py-2 text-right">Impr.</th>
                  <th className="py-2 text-right">CTR</th>
                  <th className="py-2 text-right">Pos.</th>
                </tr>
              </thead>
              <tbody>
                {(gsc?.topQueries ?? []).map((r, i) => (
                  <tr key={i} className="border-t border-white/5">
                    <td className="py-2 pr-3 font-medium">{r.query}</td>
                    <td className="py-2 text-right">{r.clicks}</td>
                    <td className="py-2 text-right">{r.impressions}</td>
                    <td className="py-2 text-right">{(r.ctr * 100).toFixed(1)}%</td>
                    <td className="py-2 text-right">{r.position.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>

        <GlassCard>
          <PanelHeader title="Microsoft Clarity" source={clarity.installed ? "live" : "demo"} />
          <p className="text-xs text-muted-foreground">
            Clarity doesn't expose a public metrics API. Sessions, heatmaps and recordings live in the
            Clarity dashboard.
          </p>
          <a
            href={clarity.dashboardUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center gap-1.5 text-sm text-brand-cyan hover:underline"
          >
            Open Clarity dashboard <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
          <div className="mt-4 text-[11px] text-muted-foreground">
            {clarity.installed
              ? `Tracking project ${clarity.projectId}`
              : "Add a Project ID in Settings → Integrations to start recording."}
          </div>
        </GlassCard>
      </div>
    </AdminShell>
  );
}

function formatKpi(value: number | undefined, source: DataSource | undefined) {
  if (source !== "live" || value === undefined) return "—";
  return value.toLocaleString();
}

function EmptyPanel({ source }: { source: DataSource | undefined }) {
  const msg =
    source === "pending"
      ? "Awaiting Traffic"
      : source === "live"
        ? "No Data Yet"
        : "Not Connected";
  return (
    <div className="flex h-[180px] items-center justify-center text-center text-xs text-muted-foreground">
      {msg}
    </div>
  );
}


function PanelHeader({
  title,
  source,
  reason,
}: {
  title: string;
  source?: DataSource;
  reason?: string;
}) {
  const label = source === "live" ? "Live" : source === "pending" ? "Not Connected" : "No Data";
  const tone =
    source === "live"
      ? "bg-emerald-500/15 text-emerald-300"
      : source === "pending"
        ? "bg-amber-500/15 text-amber-300"
        : "bg-white/10 text-muted-foreground";

  return (
    <div className="mb-3 flex items-center justify-between">
      <div className="font-display text-base font-semibold">{title}</div>
      {source ? (
        <span title={reason} className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${tone}`}>
          {label}
        </span>
      ) : null}
    </div>
  );
}

function KpiCard({
  label,
  value,
  source,
}: {
  label: string;
  value: string;
  source?: DataSource;
}) {
  const tag = source === "live" ? "live" : source === "pending" ? "not connected" : "no data";
  const tone =
    source === "live"
      ? "bg-emerald-500/15 text-emerald-300"
      : source === "pending"
        ? "bg-amber-500/15 text-amber-300"
        : "bg-white/10 text-muted-foreground";

  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        {source ? (
          <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-medium ${tone}`}>{tag}</span>
        ) : null}
      </div>
      <div className="mt-2 font-display text-2xl font-semibold">{value}</div>
    </GlassCard>
  );
}
