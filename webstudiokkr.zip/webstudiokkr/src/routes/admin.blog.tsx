import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Save, Calendar, Loader2 } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Drawer } from "./admin.services";
import {
  deleteBlog,
  listBlogsAdmin,
  listCategories,
  slugify,
  upsertBlog,
  type Blog,
  type BlogInsert,
} from "@/lib/cms/queries";

export const Route = createFileRoute("/admin/blog")({
  head: () => ({ meta: [{ title: "Blog — Admin" }, { name: "robots", content: "noindex" }] }),
  component: BlogManager,
});

type Draft = {
  id?: string;
  title: string;
  slug: string;
  excerpt: string;
  body: string;
  category_id: string | null;
  featured_image: string;
  featured: boolean;
  status: "draft" | "scheduled" | "published";
  publish_at: string; // datetime-local string
  seo_title: string;
  seo_description: string;
};

const emptyDraft = (): Draft => ({
  title: "",
  slug: "",
  excerpt: "",
  body: "",
  category_id: null,
  featured_image: "",
  featured: false,
  status: "draft",
  publish_at: new Date().toISOString().slice(0, 16),
  seo_title: "",
  seo_description: "",
});

function blogToDraft(b: Blog): Draft {
  return {
    id: b.id,
    title: b.title,
    slug: b.slug,
    excerpt: b.excerpt ?? "",
    body: b.body ?? "",
    category_id: b.category_id,
    featured_image: b.featured_image ?? "",
    featured: !!b.featured,
    status: b.status as Draft["status"],
    publish_at: b.publish_at
      ? new Date(b.publish_at).toISOString().slice(0, 16)
      : new Date().toISOString().slice(0, 16),
    seo_title: b.seo_title ?? "",
    seo_description: b.seo_description ?? "",
  };
}

function BlogManager() {
  const qc = useQueryClient();
  const postsQ = useQuery({ queryKey: ["admin", "blogs"], queryFn: listBlogsAdmin });
  const catsQ = useQuery({
    queryKey: ["categories", "blog"],
    queryFn: () => listCategories("blog"),
  });
  const [editing, setEditing] = useState<Draft | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const saveMut = useMutation({
    mutationFn: async (draft: Draft) => {
      const payload: BlogInsert = {
        title: draft.title,
        slug: draft.slug || slugify(draft.title),
        excerpt: draft.excerpt,
        body: draft.body,
        category_id: draft.category_id,
        featured_image: draft.featured_image,
        featured: draft.featured,
        status: draft.status,
        publish_at: draft.publish_at ? new Date(draft.publish_at).toISOString() : null,
        seo_title: draft.seo_title,
        seo_description: draft.seo_description,
      };
      return upsertBlog(draft.id ? { id: draft.id, ...payload } : payload);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "blogs"] });
      qc.invalidateQueries({ queryKey: ["public", "blogs"] });
      setEditing(null);
      setSaveError(null);
    },
    onError: (err: Error) => setSaveError(err.message),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteBlog(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin", "blogs"] });
      qc.invalidateQueries({ queryKey: ["public", "blogs"] });
    },
  });

  const posts = postsQ.data ?? [];
  const categories = catsQ.data ?? [];

  return (
    <AdminShell title="Blog">
      <PageHeader
        title="Blog posts"
        description="Author, schedule and publish content for the public blog."
        action={
          <Button
            variant="brand"
            onClick={() => {
              setSaveError(null);
              setEditing(emptyDraft());
            }}
          >
            <Plus className="h-4 w-4" /> New post
          </Button>
        }
      />

      <GlassCard className="overflow-hidden p-0">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.03] text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3 text-left">Title</th>
              <th className="px-4 py-3 text-left hidden md:table-cell">Slug</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left hidden md:table-cell">Publish</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {postsQ.isLoading ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-muted-foreground">
                  <Loader2 className="mx-auto h-4 w-4 animate-spin" />
                </td>
              </tr>
            ) : postsQ.isError ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-destructive">
                  {(postsQ.error as Error).message}
                </td>
              </tr>
            ) : posts.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-muted-foreground">
                  No posts yet.
                </td>
              </tr>
            ) : (
              posts.map((p) => (
                <tr key={p.id} className="border-t border-white/5">
                  <td className="px-4 py-3 font-medium">{p.title}</td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">/{p.slug}</td>
                  <td className="px-4 py-3">
                    <StatusPill status={p.status as Draft["status"]} />
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">
                    {p.publish_at ? new Date(p.publish_at).toLocaleDateString() : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSaveError(null);
                          setEditing(blogToDraft(p));
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        disabled={deleteMut.isPending}
                        onClick={() => {
                          if (confirm(`Delete post "${p.title}"?`)) deleteMut.mutate(p.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </GlassCard>

      {editing ? (
        <Drawer
          title={editing.id ? "Edit post" : "New post"}
          onClose={() => setEditing(null)}
        >
          <div className="space-y-4">
            <Field label="Title">
              <Input
                value={editing.title}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    title: e.target.value,
                    slug: editing.slug || slugify(e.target.value),
                  })
                }
              />
            </Field>
            <Field label="Slug">
              <Input
                value={editing.slug}
                onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
              />
            </Field>
            <Field label="Excerpt">
              <Textarea
                rows={2}
                value={editing.excerpt}
                onChange={(e) => setEditing({ ...editing, excerpt: e.target.value })}
              />
            </Field>
            <Field label="Body (Markdown)">
              <Textarea
                rows={10}
                value={editing.body}
                onChange={(e) => setEditing({ ...editing, body: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Category">
                <select
                  value={editing.category_id ?? ""}
                  onChange={(e) =>
                    setEditing({ ...editing, category_id: e.target.value || null })
                  }
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  <option value="">— None —</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Status">
                <select
                  value={editing.status}
                  onChange={(e) =>
                    setEditing({ ...editing, status: e.target.value as Draft["status"] })
                  }
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  <option value="draft">Draft</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="published">Published</option>
                </select>
              </Field>
            </div>
            <Field label="Featured image URL">
              <Input
                value={editing.featured_image}
                onChange={(e) => setEditing({ ...editing, featured_image: e.target.value })}
              />
            </Field>
            <Field label="Publish date">
              <Input
                type="datetime-local"
                value={editing.publish_at}
                onChange={(e) => setEditing({ ...editing, publish_at: e.target.value })}
              />
            </Field>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={editing.featured}
                onChange={(e) => setEditing({ ...editing, featured: e.target.checked })}
              />
              Mark as featured article
            </label>
            <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
              <div className="mb-2 text-xs uppercase tracking-wider text-muted-foreground">SEO</div>
              <div className="space-y-3">
                <Field label="SEO Title">
                  <Input
                    value={editing.seo_title}
                    onChange={(e) => setEditing({ ...editing, seo_title: e.target.value })}
                  />
                </Field>
                <Field label="SEO Description">
                  <Textarea
                    rows={2}
                    value={editing.seo_description}
                    onChange={(e) =>
                      setEditing({ ...editing, seo_description: e.target.value })
                    }
                  />
                </Field>
              </div>
            </div>

            {saveError ? (
              <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                {saveError}
              </div>
            ) : null}

            <Button
              variant="brand"
              className="w-full"
              disabled={saveMut.isPending || !editing.title.trim()}
              onClick={() => saveMut.mutate(editing)}
            >
              {saveMut.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              Save post
            </Button>
          </div>
        </Drawer>
      ) : null}
    </AdminShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function StatusPill({ status }: { status: Draft["status"] }) {
  const styles: Record<Draft["status"], string> = {
    draft: "bg-muted/30 text-muted-foreground",
    scheduled: "bg-amber-500/15 text-amber-300",
    published: "bg-emerald-500/15 text-emerald-300",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] capitalize ${styles[status]}`}
    >
      {status === "scheduled" ? <Calendar className="h-3 w-3" /> : null}
      {status}
    </span>
  );
}

