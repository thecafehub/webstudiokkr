import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, Save } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cms, useCms, type PageContent } from "@/lib/admin/store";

export const Route = createFileRoute("/admin/pages")({
  head: () => ({ meta: [{ title: "Pages — Admin" }, { name: "robots", content: "noindex" }] }),
  component: PagesManager,
});

function PagesManager() {
  const pages = useCms((s) => s.pages);
  const [activeId, setActiveId] = useState(pages[0]?.id ?? "home");
  const active = pages.find((p) => p.id === activeId) ?? pages[0];
  const [draft, setDraft] = useState<PageContent | null>(active ?? null);
  const [saved, setSaved] = useState(false);

  function selectPage(id: string) {
    setActiveId(id);
    const p = pages.find((x) => x.id === id);
    setDraft(p ?? null);
    setSaved(false);
  }

  function save() {
    if (!draft) return;
    cms.upsertPage(draft);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  function patch<K extends keyof PageContent>(key: K, val: PageContent[K]) {
    setDraft((d) => (d ? { ...d, [key]: val } : d));
  }

  return (
    <AdminShell title="Pages">
      <PageHeader
        title="Page content"
        description="Edit hero copy, CTAs, body content and visibility for every public page."
      />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[260px,1fr]">
        <GlassCard className="h-fit p-3">
          <div className="px-2 py-2 text-xs uppercase tracking-wider text-muted-foreground">
            All pages
          </div>
          <ul>
            {pages.map((p) => (
              <li key={p.id}>
                <button
                  onClick={() => selectPage(p.id)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                    activeId === p.id
                      ? "bg-white/[0.06] text-foreground"
                      : "text-muted-foreground hover:bg-white/[0.03] hover:text-foreground"
                  }`}
                >
                  <span>{p.title}</span>
                  {p.visible ? (
                    <Eye className="h-3.5 w-3.5 text-emerald-400" />
                  ) : (
                    <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />
                  )}
                </button>
              </li>
            ))}
          </ul>
        </GlassCard>

        {draft ? (
          <GlassCard>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-display text-lg font-semibold">{draft.title}</div>
                <div className="text-xs text-muted-foreground">/{draft.id === "home" ? "" : draft.id}</div>
              </div>
              <label className="flex items-center gap-2 text-xs">
                <input
                  type="checkbox"
                  checked={draft.visible}
                  onChange={(e) => patch("visible", e.target.checked)}
                />
                Visible
              </label>
            </div>

            <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
              <Field label="Title">
                <Input value={draft.title} onChange={(e) => patch("title", e.target.value)} />
              </Field>
              <Field label="Subtitle">
                <Input value={draft.subtitle} onChange={(e) => patch("subtitle", e.target.value)} />
              </Field>
              <Field label="Hero headline">
                <Input
                  value={draft.heroHeadline}
                  onChange={(e) => patch("heroHeadline", e.target.value)}
                />
              </Field>
              <Field label="Hero subcopy">
                <Input
                  value={draft.heroSubcopy}
                  onChange={(e) => patch("heroSubcopy", e.target.value)}
                />
              </Field>
              <Field label="Primary CTA">
                <Input value={draft.primaryCta} onChange={(e) => patch("primaryCta", e.target.value)} />
              </Field>
              <Field label="Secondary CTA">
                <Input
                  value={draft.secondaryCta}
                  onChange={(e) => patch("secondaryCta", e.target.value)}
                />
              </Field>
            </div>

            <div className="mt-4">
              <Field label="Body content (Markdown supported)">
                <Textarea
                  rows={8}
                  value={draft.body}
                  onChange={(e) => patch("body", e.target.value)}
                  placeholder="Long-form content for the page…"
                />
              </Field>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2">
              {saved ? (
                <span className="text-xs text-emerald-400">Saved ✓</span>
              ) : null}
              <Button variant="brand" onClick={save}>
                <Save className="h-4 w-4" /> Save changes
              </Button>
            </div>
          </GlassCard>
        ) : null}
      </div>
    </AdminShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
