import { createFileRoute } from "@tanstack/react-router";
import { Bot, CheckCircle2, Clock, Cog, Mail, Workflow } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/business-automation";
const TITLE = "Business Automation Services";
const DESC =
  "Automate repetitive business workflows with Web Studio KKR — CRM, email, lead handling, data sync, scraping and AI-assisted operations.";

export const Route = createFileRoute("/business-automation")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Business Automation",
          provider: { "@type": "Organization", name: site.brand.name, url: site.brand.url },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Automation"
      title="Business automation"
      highlight="that gives you hours back."
      description="Ship the boring work — lead intake, follow-ups, data sync, reporting and ops — to bots that don't sleep, miss tasks or forget."
      intro="Every operator has a list of jobs that should not require a human: copying leads between tools, sending the same reply 50 times a day, building the same weekly report. We design and build automations that handle those jobs reliably — so your team can spend time on work that actually moves the business."
      features={[
        { title: "Workflow automation", description: "Multi-step flows across your stack — n8n, Make, custom code.", icon: Workflow },
        { title: "Lead & CRM automation", description: "Capture, route, enrich and follow up on leads automatically.", icon: Mail },
        { title: "Scheduled jobs", description: "Reports, syncs and reminders that run on time, every time.", icon: Clock },
        { title: "Scraping & monitoring", description: "Track prices, competitors and inventory across the web.", icon: Cog },
        { title: "AI-assisted ops", description: "Summarize, classify, route and draft responses with LLMs.", icon: Bot },
        { title: "Audit & alerting", description: "Every run logged. Failures alert you on WhatsApp/Telegram.", icon: CheckCircle2 },
      ]}
      benefits={[
        "ROI-focused — we map savings before quoting",
        "Works with the tools you already use",
        "Self-healing flows with retry logic",
        "Documentation and SOPs included",
        "Training for your team",
        "Ownership transferred — no lock-in",
      ]}
      faqs={[
        { q: "What kind of business workflows can you automate?", a: "Lead intake, follow-up sequences, CRM sync, invoice generation, report distribution, scraping competitor data, social media posting, customer support routing — anything repeatable." },
        { q: "Do you use no-code tools or custom code?", a: "Both, depending on what's right. No-code (n8n, Make, Zapier) for fast iterations; custom code for volume, edge cases or sensitive data." },
        { q: "Will the automation break when an integration changes?", a: "Every automation we build has logging, alerting and graceful failure handling. If an API changes, you'll know before customers do." },
      ]}
      inquirySource="landing_business_automation"
      inquiryTitle="Business Automation"
    />
  ),
});
