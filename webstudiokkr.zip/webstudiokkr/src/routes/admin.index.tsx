import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowUpRight,
  FileText,
  Users,
  Package,
  PenSquare,
  Search,
} from "lucide-react";
import { AdminShell, GlassCard } from "@/components/admin/AdminShell";
import { useCms, computeSeoScore } from "@/lib/admin/store";
import { listLeads } from "@/lib/cms/crm";
import { listBlogsAdmin, listProductsAdmin } from "@/lib/cms/queries";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Admin" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminDashboard,
});

function StatCard({
  label,
  value,
  delta,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string | number;
  delta: string;
  icon: React.ElementType;
  accent: string;
}) {
  return (
    <GlassCard className="relative overflow-hidden">
      <div
        className={`pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full blur-3xl ${accent}`}
      />
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="mt-2 font-display text-3xl font-semibold">{value}</div>
          <div className="mt-1 text-xs text-muted-foreground">{delta}</div>
        </div>
        <div className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[0.04]">
          <Icon className="h-4 w-4 text-brand-cyan" />
        </div>
      </div>
    </GlassCard>
  );
}

function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60_000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function AdminDashboard() {
  const pages = useCms((s) => s.pages);
  const services = useCms((s) => s.services);
  const seo = useCms((s) => s.seo);
  const avgSeo = Math.round(
    seo.reduce((acc, e) => acc + computeSeoScore(e), 0) / Math.max(1, seo.length),
  );

  const leadsQ = useQuery({ queryKey: ["admin", "leads"], queryFn: listLeads });
  const productsQ = useQuery({ queryKey: ["admin", "products"], queryFn: listProductsAdmin });
  const blogsQ = useQuery({ queryKey: ["admin", "blogs"], queryFn: listBlogsAdmin });


  const leads = leadsQ.data ?? [];
  const products = productsQ.data ?? [];
  const blogs = blogsQ.data ?? [];

  // Real activity feed: most recent leads + blogs
  const activity = [
    ...leads.slice(0, 3).map((l) => ({
      label: `New lead — ${l.name}`,
      when: relativeTime(l.created_at),
      icon: Users,
    })),
    ...blogs
      .filter((b: typeof blogs[number]) => b.status === "published")
      .slice(0, 2)
      .map((b: typeof blogs[number]) => ({
        label: `Blog published — ${b.title}`,
        when: relativeTime(b.updated_at ?? b.created_at),
        icon: PenSquare,
      })),
  ].slice(0, 5);


  return (
    <AdminShell title="Dashboard">
      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Pages"
          value={pages.length}
          delta="All managed"
          icon={FileText}
          accent="bg-brand-blue/30"
        />
        <StatCard
          label="Products"
          value={products.length}
          delta={products.length ? `${products.filter((p: typeof products[number]) => p.featured).length} featured` : "No products yet"}
          icon={Package}
          accent="bg-brand-cyan/30"
        />
        <StatCard
          label="Blog posts"
          value={blogs.length}
          delta={blogs.length ? `${blogs.filter((b: typeof blogs[number]) => b.status === "published").length} published` : "No posts yet"}
          icon={PenSquare}
          accent="bg-brand-violet/30"
        />
        <StatCard
          label="Leads"
          value={leads.length}
          delta={leads.length ? `${leads.filter((l: typeof leads[number]) => l.status === "new").length} new` : "No Leads Yet"}
          icon={Users}
          accent="bg-pink-500/30"
        />
      </div>

      {/* Traffic & SEO */}
      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <GlassCard className="lg:col-span-2">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <div className="font-display text-base font-semibold">Website traffic</div>
              <div className="text-xs text-muted-foreground">
                Live visitor data appears here once Google Analytics is connected.
              </div>
            </div>
          </div>
          <div className="flex h-[180px] flex-col items-center justify-center gap-2 text-center">
            <div className="font-display text-2xl text-muted-foreground">No Traffic Yet</div>
            <Link
              to="/admin/analytics"
              className="inline-flex items-center gap-1 text-xs text-brand-cyan hover:underline"
            >
              Open Analytics <ArrowUpRight className="h-3 w-3" />
            </Link>
          </div>
        </GlassCard>

        <GlassCard>
          <div className="mb-2 flex items-center justify-between">
            <div>
              <div className="font-display text-base font-semibold">SEO Health</div>
              <div className="text-xs text-muted-foreground">Average across pages</div>
            </div>
            <Search className="h-4 w-4 text-brand-cyan" />
          </div>
          <div className="mt-2">
            <div className="font-display text-5xl font-semibold">{avgSeo}</div>
            <div className="text-xs text-muted-foreground">out of 100</div>
          </div>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/5">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand-blue via-brand-cyan to-emerald-400"
              style={{ width: `${avgSeo}%` }}
            />
          </div>
          <Link
            to="/admin/seo"
            className="mt-4 inline-flex items-center gap-1 text-xs text-brand-cyan hover:underline"
          >
            Open SEO Center <ArrowUpRight className="h-3 w-3" />
          </Link>
        </GlassCard>
      </div>

      {/* Recent activity */}
      <div className="mt-6">
        <GlassCard>
          <div className="mb-4 font-display text-base font-semibold">Recent activity</div>
          {activity.length === 0 ? (
            <div className="py-6 text-center text-sm text-muted-foreground">
              No activity yet. Submissions, leads, and content updates will appear here.
            </div>
          ) : (
            <ul className="space-y-3">
              {activity.map((a, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <div className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/[0.03]">
                    <a.icon className="h-3.5 w-3.5 text-brand-cyan" />
                  </div>
                  <div>
                    <div>{a.label}</div>
                    <div className="text-xs text-muted-foreground">{a.when}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </GlassCard>
      </div>

      {/* Content overview */}
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { label: "Services", value: services.length, to: "/admin/services" as const },
          { label: "Products", value: products.length, to: "/admin/products" as const },
          { label: "Blog posts", value: blogs.length, to: "/admin/blog" as const },
          { label: "Leads", value: leads.length, to: "/admin/leads" as const },
        ].map((c) => (
          <Link key={c.label} to={c.to}>
            <GlassCard className="cursor-pointer transition-all hover:-translate-y-0.5 hover:border-white/20">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                {c.label}
              </div>
              <div className="mt-1 font-display text-2xl font-semibold">{c.value}</div>
              <div className="mt-1 flex items-center gap-1 text-xs text-brand-cyan">
                Manage <ArrowUpRight className="h-3 w-3" />
              </div>
            </GlassCard>
          </Link>
        ))}
      </div>
    </AdminShell>
  );
}
