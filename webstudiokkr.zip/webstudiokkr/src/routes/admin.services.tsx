import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2, ArrowUp, ArrowDown, Power, Save, X } from "lucide-react";
import { AdminShell, GlassCard, PageHeader } from "@/components/admin/AdminShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cms, uid, useCms, type ServiceItem } from "@/lib/admin/store";

export const Route = createFileRoute("/admin/services")({
  head: () => ({ meta: [{ title: "Services — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ServicesManager,
});

const empty = (): ServiceItem => ({
  id: uid("svc"),
  title: "",
  description: "",
  features: [],
  accent: "blue",
  enabled: true,
  order: 999,
});

function ServicesManager() {
  const rawServices = useCms((s) => s.services);
  const services = [...rawServices].sort((a, b) => a.order - b.order);
  const [editing, setEditing] = useState<ServiceItem | null>(null);

  function save() {
    if (!editing) return;
    cms.upsertService(editing);
    setEditing(null);
  }

  return (
    <AdminShell title="Services">
      <PageHeader
        title="Services catalog"
        description="Add, edit, reorder and toggle every service shown on the public site."
        action={
          <Button variant="brand" onClick={() => setEditing(empty())}>
            <Plus className="h-4 w-4" /> New service
          </Button>
        }
      />

      <GlassCard className="overflow-hidden p-0">
        <table className="w-full text-sm">
          <thead className="bg-white/[0.03] text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3 text-left">Title</th>
              <th className="px-4 py-3 text-left hidden md:table-cell">Description</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {services.map((s) => (
              <tr key={s.id} className="border-t border-white/5">
                <td className="px-4 py-3 font-medium">{s.title}</td>
                <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">
                  <div className="line-clamp-1 max-w-md">{s.description}</div>
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] ${
                      s.enabled
                        ? "bg-emerald-500/15 text-emerald-300"
                        : "bg-muted/30 text-muted-foreground"
                    }`}
                  >
                    <Power className="h-3 w-3" /> {s.enabled ? "Enabled" : "Disabled"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => cms.reorderService(s.id, -1)}>
                      <ArrowUp className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => cms.reorderService(s.id, 1)}>
                      <ArrowDown className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => cms.upsertService({ ...s, enabled: !s.enabled })}
                    >
                      <Power className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setEditing(s)}>
                      Edit
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        if (confirm(`Delete service "${s.title}"?`)) cms.deleteService(s.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {services.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-10 text-center text-muted-foreground">
                  No services yet — click <strong>New service</strong> to add one.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </GlassCard>

      {editing ? (
        <Drawer onClose={() => setEditing(null)} title={editing.title ? "Edit service" : "New service"}>
          <div className="space-y-4">
            <Field label="Title">
              <Input value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} />
            </Field>
            <Field label="Description">
              <Textarea
                rows={4}
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              />
            </Field>
            <Field label="Features (one per line)">
              <Textarea
                rows={4}
                value={editing.features.join("\n")}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    features: e.target.value.split("\n").map((l) => l.trim()).filter(Boolean),
                  })
                }
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Accent">
                <select
                  value={editing.accent}
                  onChange={(e) =>
                    setEditing({ ...editing, accent: e.target.value as ServiceItem["accent"] })
                  }
                  className="h-10 w-full rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm"
                >
                  <option value="blue">Blue</option>
                  <option value="cyan">Cyan</option>
                  <option value="violet">Violet</option>
                  <option value="pink">Pink</option>
                </select>
              </Field>
              <Field label="Status">
                <label className="flex h-10 items-center gap-2 rounded-md border border-white/10 bg-white/[0.03] px-3 text-sm">
                  <input
                    type="checkbox"
                    checked={editing.enabled}
                    onChange={(e) => setEditing({ ...editing, enabled: e.target.checked })}
                  />
                  Enabled
                </label>
              </Field>
            </div>
            <Button variant="brand" className="w-full" onClick={save}>
              <Save className="h-4 w-4" /> Save service
            </Button>
          </div>
        </Drawer>
      ) : null}
    </AdminShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

export function Drawer({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
      <div className="h-full w-full max-w-lg overflow-y-auto border-l border-white/10 bg-[oklch(0.10_0.04_265)] p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="rounded-md border border-white/10 p-1.5">
            <X className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
