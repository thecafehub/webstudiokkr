import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { FeatureCard } from "@/components/sections/FeatureCard";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { services, site } from "@/config/site";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: `Services — ${site.brand.name}` },
      {
        name: "description",
        content:
          "Website design, SEO, custom APIs, automation, Telegram & WhatsApp bots, video editing, e-commerce and VPS management — by Web Studio KKR.",
      },
      { property: "og:title", content: `Services — ${site.brand.name}` },
      { property: "og:description", content: "Full-stack digital services delivered end-to-end." },
      { property: "og:url", content: `${site.brand.url}/services` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/services` }],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Services"
        title="Everything you need to"
        highlight="ship and grow online."
        description="A focused set of services we deliver to the highest standard — design, code, automation, SEO and infrastructure under one roof."
      >
        <Button asChild variant="hero" size="lg">
          <Link to="/contact">
            Request a quote <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
        <Button asChild variant="glass" size="lg">
          <Link to="/products">Browse marketplace</Link>
        </Button>
      </PageHero>

      <section className="container mx-auto px-4 pb-16">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <div key={s.id} className="animate-fade-up" style={{ animationDelay: `${i * 50}ms` }}>
              <FeatureCard
                icon={s.icon}
                title={s.title}
                description={s.description}
                accent={s.accent}
                footer={
                  <ul className="mt-3 space-y-1.5">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <CheckCircle2 className="h-3.5 w-3.5 text-brand-cyan" />
                        {f}
                      </li>
                    ))}
                  </ul>
                }
              />
            </div>
          ))}
        </div>
      </section>

      <CtaStrip
        title="Not sure where to start?"
        description="Tell us about your business and we'll suggest the right path — no obligation, no fluff."
      />
    </SiteLayout>
  );
}
