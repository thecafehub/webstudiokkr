import { createFileRoute } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { FeatureCard } from "@/components/sections/FeatureCard";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { toolCategories, site } from "@/config/site";
import { trackEvent } from "@/lib/analytics/track";

export const Route = createFileRoute("/tools")({
  head: () => ({
    meta: [
      { title: `Tools — ${site.brand.name}` },
      {
        name: "description",
        content:
          "A growing platform of free SEO, developer, marketing and API tools — DA/PA checker, JSON formatter, meta generator, sitemap builder and more.",
      },
      { property: "og:title", content: `Tools — ${site.brand.name}` },
      { property: "og:description", content: "Free, fast tools for SEO, developers and marketers." },
      { property: "og:url", content: `${site.brand.url}/tools` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/tools` }],
  }),
  component: ToolsPage,
});

function ToolsPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="Tools platform"
        title="Free, fast tools for"
        highlight="builders & marketers."
        description="A growing library of SEO, developer, marketing and API tools — built by our team, free to use, no signup."
      />

      <section className="container mx-auto px-4 pb-12">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {toolCategories.map((t, i) => (
            <div
              key={t.id}
              role="button"
              tabIndex={0}
              onClick={() => trackEvent("tool_use", { tool_id: t.id, tool_title: t.title })}
              className="animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <FeatureCard
                icon={t.icon}
                title={t.title}
                description={t.description}
                accent={(["blue", "cyan", "violet", "pink"] as const)[i % 4]}
                footer={
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-2.5 py-1 text-xs text-brand-violet">
                    <Sparkles className="h-3 w-3" /> Launching soon
                  </span>
                }
              />
            </div>
          ))}
        </div>
      </section>

      <CtaStrip
        title="Want a specific tool first?"
        description="Tell us which tool would unblock your workflow and we'll prioritise building it."
      />
    </SiteLayout>
  );
}
