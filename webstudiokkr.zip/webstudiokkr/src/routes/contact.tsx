import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Mail, Phone, MapPin, Send, MessageCircle, Instagram, ArrowRight, CheckCircle2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { site } from "@/config/site";
import { trackEvent } from "@/lib/analytics/track";
import { useSiteSettings } from "@/lib/cms/settings";
import { submitPublicLead } from "@/lib/cms/crm";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: `Contact — ${site.brand.name}` },
      {
        name: "description",
        content: `Get in touch with Web Studio KKR — email ${site.contact.email}, WhatsApp ${site.contact.phone}, or message us on Telegram or Instagram.`,
      },
      { property: "og:title", content: `Contact — ${site.brand.name}` },
      { property: "og:description", content: "Start a project, request a product, or just say hi." },
      { property: "og:url", content: `${site.brand.url}/contact` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/contact` }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const settings = useSiteSettings();
  const [submitted, setSubmitted] = useState(false);
  const submit = useMutation({
    mutationFn: (input: {
      name: string;
      email: string;
      phone: string;
      service: string;
      message: string;
    }) =>
      submitPublicLead({
        name: input.name,
        email: input.email,
        phone: input.phone,
        message: `${input.service ? `[${input.service}] ` : ""}${input.message}`,
        source: "contact_form",
        metadata: { service: input.service },
      }),
    onSuccess: () => setSubmitted(true),
  });

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Contact"
        title="Let's build something"
        highlight="memorable."
        description="Tell us about your project — we typically respond within a few hours, every day of the week."
      />

      <section className="container mx-auto px-4 pb-20">
        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-5">
          {/* Form */}
          <div className="lg:col-span-3">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                const payload = {
                  name: String(fd.get("name") ?? "").trim(),
                  email: String(fd.get("email") ?? "").trim(),
                  phone: String(fd.get("phone") ?? "").trim(),
                  service: String(fd.get("service") ?? "").trim(),
                  message: String(fd.get("message") ?? "").trim(),
                };
                trackEvent("contact_form_submit", {
                  service: payload.service,
                  has_phone: Boolean(payload.phone),
                });
                submit.mutate(payload);
              }}
              className="rounded-3xl glass-strong p-8"
            >
              <h2 className="font-display text-2xl font-bold tracking-tight">Start a conversation</h2>
              <p className="mt-1 text-sm text-muted-foreground">All fields required.</p>

              {submitted ? (
                <div className="mt-8 flex flex-col items-center gap-3 rounded-2xl border border-brand-cyan/30 bg-brand-cyan/5 p-8 text-center">
                  <CheckCircle2 className="h-10 w-10 text-brand-cyan" />
                  <h3 className="font-display text-lg font-semibold">Message received</h3>
                  <p className="text-sm text-muted-foreground">
                    Thanks — we'll be in touch shortly. For anything urgent, please reach us on WhatsApp.
                  </p>
                  <Button variant="glass" onClick={() => setSubmitted(false)}>
                    Send another
                  </Button>
                </div>
              ) : (
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <Field label="Your name" name="name" placeholder="Nitin Kamboj" />
                  <Field label="Email" name="email" type="email" placeholder="you@company.com" />
                  <Field label="Phone / WhatsApp" name="phone" placeholder="+91 …" />
                  <Field label="Service" name="service" placeholder="e.g. Website design" />
                  <div className="sm:col-span-2">
                    <Label>Project details</Label>
                    <textarea
                      required
                      name="message"
                      rows={5}
                      placeholder="What are you building? Timeline, budget range, any references…"
                      className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm placeholder:text-muted-foreground/60 focus:border-brand-cyan/50 focus:outline-none focus:ring-2 focus:ring-brand-cyan/20"
                    />
                  </div>
                  {submit.error ? (
                    <div className="sm:col-span-2 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                      Couldn't send: {(submit.error as Error).message}
                    </div>
                  ) : null}
                  <div className="sm:col-span-2">
                    <Button type="submit" variant="hero" size="lg" className="w-full sm:w-auto" disabled={submit.isPending}>
                      {submit.isPending ? (
                        <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</>
                      ) : (
                        <>Send message <ArrowRight className="h-4 w-4" /></>
                      )}
                    </Button>
                  </div>
                </div>
              )}
            </form>
          </div>

          {/* Sidebar contacts */}
          <div className="space-y-4 lg:col-span-2">
            <ContactCard icon={Mail} label="Email" value={settings.contact.email} href={`mailto:${settings.contact.email}`} />
            <ContactCard icon={Phone} label="Phone" value={settings.contact.phone} href={`tel:${settings.contact.phone}`} />
            <ContactCard icon={MessageCircle} label="WhatsApp" value={settings.contact.phone} href={settings.contact.whatsappLink} external />
            <ContactCard icon={Send} label="Telegram" value={`@${settings.contact.telegram}`} href={settings.contact.telegramLink} external />
            <ContactCard icon={Instagram} label="Instagram" value={`@${settings.contact.instagram}`} href={settings.contact.instagramLink} external />
            <div className="rounded-2xl glass p-5">
              <div className="flex items-start gap-3">
                <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-brand-blue/30 to-brand-violet/20 text-brand-cyan ring-1 ring-white/10">
                  <MapPin className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Studio</p>
                  <p className="mt-0.5 text-sm font-medium">{settings.contact.address}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{site.brand.domain}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">{children}</label>;
}

function Field({ label, name, type = "text", placeholder }: { label: string; name: string; type?: string; placeholder?: string }) {
  return (
    <div>
      <Label>{label}</Label>
      <input
        required
        name={name}
        type={type}
        placeholder={placeholder}
        className="mt-1.5 h-11 w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 text-sm placeholder:text-muted-foreground/60 focus:border-brand-cyan/50 focus:outline-none focus:ring-2 focus:ring-brand-cyan/20"
      />
    </div>
  );
}

function ContactCard({
  icon: Icon,
  label,
  value,
  href,
  external,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  href: string;
  external?: boolean;
}) {
  return (
    <a
      href={href}
      target={external ? "_blank" : undefined}
      rel={external ? "noreferrer noopener" : undefined}
      className="group flex items-center gap-4 rounded-2xl glass p-5 hover-lift"
    >
      <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-blue/30 to-brand-violet/20 text-brand-cyan ring-1 ring-white/10">
        <Icon className="h-5 w-5" />
      </span>
      <div className="flex-1">
        <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
        <p className="mt-0.5 text-sm font-medium text-foreground">{value}</p>
      </div>
      <ArrowRight className="h-4 w-4 text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-foreground" />
    </a>
  );
}
