import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Award, Globe, Heart, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { site } from "@/config/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: `About — ${site.brand.name}` },
      {
        name: "description",
        content: `Web Studio KKR is a premium digital studio based in ${site.brand.location}, building websites, APIs, automation and digital products for clients worldwide.`,
      },
      { property: "og:title", content: `About — ${site.brand.name}` },
      { property: "og:description", content: `Premium digital studio based in ${site.brand.location}.` },
      { property: "og:url", content: `${site.brand.url}/about` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/about` }],
  }),
  component: AboutPage,
});

const values = [
  { icon: Award, title: "Craft over quantity", description: "We'd rather ship one great thing than ten average ones." },
  { icon: Heart, title: "Honest partnerships", description: "Transparent pricing, clear timelines, no surprises mid-project." },
  { icon: Rocket, title: "Production-first", description: "Every project ships to a real environment — not just a demo URL." },
  { icon: Globe, title: "Built for the world", description: "Clients across 14 countries — and we build for global scale by default." },
];

function AboutPage() {
  return (
    <SiteLayout>
      <PageHero
        eyebrow="About us"
        title="A small studio with a"
        highlight="big appetite for craft."
        description={`Web Studio KKR is an independent digital studio based in ${site.brand.location}. We design, build, automate and grow modern web businesses — for clients across India and around the world.`}
      >
        <Button asChild variant="hero" size="lg">
          <Link to="/contact">
            Work with us <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </PageHero>

      {/* Story */}
      <section className="container mx-auto px-4 py-12">
        <div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-2">
          <div className="rounded-3xl glass-strong p-8">
            <h2 className="font-display text-2xl font-bold tracking-tight">Our story</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              Web Studio KKR began in {site.brand.founded} as a one-person workshop in Kurukshetra — a single freelancer
              with a strong opinion that most of the web is built carelessly. Five years later we're a tight, in-house team
              shipping websites, APIs, automation and digital products to clients across {site.stats[2].value} countries.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              We obsess over the boring parts — performance, SEO, security, deploy hygiene — so the parts you see end up
              feeling effortless. Premium isn't a finish we apply at the end; it's a decision we make on day one.
            </p>
          </div>

          <div className="rounded-3xl glass-strong p-8">
            <h2 className="font-display text-2xl font-bold tracking-tight">What we do</h2>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li>· Full-stack web design & development for businesses</li>
              <li>· Custom APIs, automation, Telegram & WhatsApp bots</li>
              <li>· A growing marketplace of source codes, templates & APIs</li>
              <li>· A free tools platform for SEO, dev & marketing</li>
              <li>· Long-form guides on building better web businesses</li>
            </ul>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {site.stats.map((s) => (
                <div key={s.label} className="rounded-xl bg-white/5 p-3 text-center">
                  <p className="gradient-brand-text font-display text-xl font-bold">{s.value}</p>
                  <p className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-center font-display text-3xl font-bold tracking-tight sm:text-4xl">
          What we <span className="gradient-brand-text">stand for</span>
        </h2>
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {values.map((v, i) => (
            <div
              key={v.title}
              className="rounded-2xl glass p-6 animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-brand-blue/30 to-brand-violet/20 text-brand-cyan ring-1 ring-white/10">
                <v.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-base font-semibold tracking-tight">{v.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{v.description}</p>
            </div>
          ))}
        </div>
      </section>

      <CtaStrip />
    </SiteLayout>
  );
}
