import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, Loader2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { PageHero } from "@/components/sections/PageHero";
import { CtaStrip } from "@/components/sections/CtaStrip";
import { ProductCard } from "@/components/sections/ProductCard";
import { site } from "@/config/site";
import { listCategories, listProductsPublic, type Product } from "@/lib/cms/queries";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: `Marketplace — ${site.brand.name}` },
      {
        name: "description",
        content:
          "Premium source codes, Telegram bots, custom APIs, website templates, admin panels and digital products — production-ready, by Web Studio KKR.",
      },
      { property: "og:title", content: `Marketplace — ${site.brand.name}` },
      { property: "og:description", content: "Production-ready digital products you can deploy today." },
      { property: "og:url", content: `${site.brand.url}/products` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}/products` }],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const productsQ = useQuery({
    queryKey: ["public", "products"],
    queryFn: () => listProductsPublic(),
  });
  const catsQ = useQuery({
    queryKey: ["categories", "product"],
    queryFn: () => listCategories("product"),
  });

  const [filter, setFilter] = useState<string>("all");
  const [query, setQuery] = useState<string>("");

  const products = productsQ.data ?? [];
  const categories = catsQ.data ?? [];

  const featured = useMemo(() => products.filter((p) => p.featured).slice(0, 3), [products]);
  const trending = useMemo(() => products.filter((p) => p.trending).slice(0, 3), [products]);
  const newest = useMemo(() => [...products].slice(0, 3), [products]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (filter !== "all" && p.category?.slug !== filter) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        (p.description ?? "").toLowerCase().includes(q) ||
        (p.category?.name ?? "").toLowerCase().includes(q)
      );
    });
  }, [products, filter, query]);

  return (
    <SiteLayout>
      <PageHero
        eyebrow="Marketplace"
        title="Production-ready"
        highlight="digital products."
        description="Source codes, bots, APIs, templates and admin panels — vetted by our studio, ready to deploy."
      >
        <Button asChild variant="hero" size="lg">
          <Link to="/contact">
            Request a product <ArrowUpRight className="h-4 w-4" />
          </Link>
        </Button>
      </PageHero>

      {/* Search */}
      <section className="container mx-auto max-w-2xl px-4 pb-6">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products by name, category or keyword…"
            className="pl-9"
            aria-label="Search products"
          />
        </div>
      </section>

      {/* Featured strip */}
      {featured.length > 0 && !query && filter === "all" ? (
        <ProductStrip title="Featured" subtitle="Hand-picked by our studio" products={featured} />
      ) : null}

      {/* Trending strip */}
      {trending.length > 0 && !query && filter === "all" ? (
        <ProductStrip title="Trending now" subtitle="Most-requested this month" products={trending} />
      ) : null}

      {/* New strip */}
      {newest.length > 0 && !query && filter === "all" ? (
        <ProductStrip title="New arrivals" subtitle="Recently added to the marketplace" products={newest} />
      ) : null}

      <section className="container mx-auto px-4 pb-12">
        <div className="mb-6 flex flex-wrap gap-2">
          <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
            All ({products.length})
          </FilterChip>
          {categories.map((c) => {
            const count = products.filter((p) => p.category?.slug === c.slug).length;
            return (
              <FilterChip
                key={c.id}
                active={filter === c.slug}
                onClick={() => setFilter(c.slug)}
              >
                {c.name} ({count})
              </FilterChip>
            );
          })}
        </div>

        {productsQ.isLoading ? (
          <div className="flex justify-center py-20 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : productsQ.isError ? (
          <div className="rounded-2xl glass p-6 text-center text-sm text-destructive">
            Couldn't load products: {(productsQ.error as Error).message}
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-2xl glass p-10 text-center text-muted-foreground">
            {query
              ? `No products match "${query}".`
              : "No products available in this category yet."}
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        )}
      </section>

      <CtaStrip
        title="Need something custom?"
        description="Our studio also builds exclusive products on commission — branded, white-labeled, fully yours."
      />
    </SiteLayout>
  );
}

function ProductStrip({
  title,
  subtitle,
  products,
}: {
  title: string;
  subtitle: string;
  products: Product[];
}) {
  return (
    <section className="container mx-auto px-4 pb-10">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold tracking-tight md:text-2xl">{title}</h2>
          <p className="text-xs text-muted-foreground md:text-sm">{subtitle}</p>
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p, i) => (
          <ProductCard key={p.id} product={p} index={i} />
        ))}
      </div>
    </section>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
        active
          ? "border-brand-cyan/40 bg-brand-cyan/10 text-foreground"
          : "border-white/10 bg-white/[0.02] text-muted-foreground hover:border-white/20"
      }`}
    >
      {children}
    </button>
  );
}
