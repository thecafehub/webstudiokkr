import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { site } from "@/config/site";

const BASE_URL = site.brand.url;

interface SitemapEntry {
  path: string;
  changefreq?: "weekly" | "monthly" | "daily";
  priority?: string;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [
          { path: "/", changefreq: "weekly", priority: "1.0" },
          { path: "/services", changefreq: "weekly", priority: "0.9" },
          { path: "/products", changefreq: "weekly", priority: "0.9" },
          { path: "/tools", changefreq: "weekly", priority: "0.8" },
          { path: "/blog", changefreq: "daily", priority: "0.8" },
          { path: "/about", changefreq: "monthly", priority: "0.6" },
          { path: "/contact", changefreq: "monthly", priority: "0.7" },
          // SEO landing pages
          { path: "/website-development-kurukshetra", changefreq: "monthly", priority: "0.9" },
          { path: "/website-designing-kurukshetra", changefreq: "monthly", priority: "0.9" },
          { path: "/seo-services-kurukshetra", changefreq: "monthly", priority: "0.9" },
          { path: "/telegram-bot-development", changefreq: "monthly", priority: "0.8" },
          { path: "/custom-api-development", changefreq: "monthly", priority: "0.8" },
          { path: "/business-automation", changefreq: "monthly", priority: "0.8" },
          { path: "/graphic-design-services", changefreq: "monthly", priority: "0.7" },
          { path: "/video-editing-services", changefreq: "monthly", priority: "0.7" },
        ];

        const urls = entries.map(
          (e) => `  <url>
    <loc>${BASE_URL}${e.path}</loc>
    <changefreq>${e.changefreq}</changefreq>
    <priority>${e.priority}</priority>
  </url>`,
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
