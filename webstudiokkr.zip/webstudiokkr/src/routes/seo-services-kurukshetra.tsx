import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, FileSearch, Globe, Link2, PenTool, Search } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/seo-services-kurukshetra";
const TITLE = "SEO Services in Kurukshetra";
const DESC =
  "Result-driven SEO services in Kurukshetra. Local SEO, technical SEO, content strategy and link building by Web Studio KKR — rank for what matters.";

export const Route = createFileRoute("/seo-services-kurukshetra")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "SEO",
          provider: {
            "@type": "LocalBusiness",
            name: site.brand.name,
            url: site.brand.url,
            telephone: site.contact.phone,
            email: site.contact.email,
            address: { "@type": "PostalAddress", addressLocality: "Kurukshetra", addressRegion: "Haryana", addressCountry: "IN" },
          },
          areaServed: { "@type": "City", name: "Kurukshetra" },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="Kurukshetra · SEO"
      title="SEO services that"
      highlight="actually rank."
      description="Technical SEO, local SEO and content-led growth from a Kurukshetra-based studio that measures success in revenue, not vanity metrics."
      intro="We don't sell magic. We run audits, fix the boring stuff, write the right pages, and earn links from sources Google actually trusts. Then we report on what changed — every month."
      features={[
        { title: "Technical SEO audit", description: "Crawlability, schema, Core Web Vitals, indexation — fixed at the root.", icon: FileSearch },
        { title: "Local SEO", description: "Google Business Profile, local citations and map-pack optimisation.", icon: Globe },
        { title: "Keyword research", description: "Real search data — volume, intent, difficulty, business value.", icon: Search },
        { title: "Content strategy", description: "Pillar pages, clusters and updates that compound over time.", icon: PenTool },
        { title: "Link building", description: "Editorial outreach to relevant sites — never spammy PBNs.", icon: Link2 },
        { title: "Monthly reporting", description: "Ranking, traffic, conversion — explained in plain English.", icon: BarChart3 },
      ]}
      benefits={[
        "Whitehat-only — your domain stays safe",
        "Kurukshetra-local team — easy coordination",
        "Transparent monthly reports",
        "GA4 + Search Console fully wired",
        "Content written by humans, edited by experts",
        "No long contracts — month-to-month",
      ]}
      faqs={[
        { q: "How long does SEO take to show results?", a: "Technical fixes can move rankings in 4–6 weeks. Content + backlink work typically shows real movement in 3–6 months. Anyone promising \"#1 in 7 days\" is lying." },
        { q: "Do you guarantee #1 rankings?", a: "No, and we won't. Google forbids it, and any agency that does is selling you snake oil. We guarantee the work, the process and the reporting." },
        { q: "Do you do local SEO for Kurukshetra businesses?", a: "Yes — local SEO is one of our specialties. Google Business Profile, NAP citations, local content and review management." },
        { q: "Can you fix a Google penalty?", a: "Yes. We audit penalised sites, identify the cause (links, content, technical), implement fixes and file reconsideration where needed." },
      ]}
      inquirySource="landing_seo_kurukshetra"
      inquiryTitle="SEO Services (Kurukshetra)"
    />
  ),
});
