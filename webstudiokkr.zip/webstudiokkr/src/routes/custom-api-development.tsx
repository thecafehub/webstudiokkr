import { createFileRoute } from "@tanstack/react-router";
import { Database, KeyRound, Plug, Shield, Webhook, Zap } from "lucide-react";
import { LandingPage } from "@/components/sections/LandingPage";
import { site } from "@/config/site";

const URL_PATH = "/custom-api-development";
const TITLE = "Custom API Development Services";
const DESC =
  "Build robust REST & GraphQL APIs, integrations and data pipelines with Web Studio KKR. Production-grade, secure and built to scale.";

export const Route = createFileRoute("/custom-api-development")({
  head: () => ({
    meta: [
      { title: `${TITLE} — ${site.brand.name}` },
      { name: "description", content: DESC },
      { property: "og:title", content: `${TITLE} — ${site.brand.name}` },
      { property: "og:description", content: DESC },
      { property: "og:url", content: `${site.brand.url}${URL_PATH}` },
    ],
    links: [{ rel: "canonical", href: `${site.brand.url}${URL_PATH}` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Custom API Development",
          provider: { "@type": "Organization", name: site.brand.name, url: site.brand.url },
          name: TITLE,
          description: DESC,
          url: `${site.brand.url}${URL_PATH}`,
        }),
      },
    ],
  }),
  component: () => (
    <LandingPage
      eyebrow="APIs & Integrations"
      title="Custom API"
      highlight="development services."
      description="REST and GraphQL APIs engineered for uptime, security and scale — with auth, rate limiting, observability and clean documentation."
      intro="Whether you're connecting two SaaS tools, building a mobile-app backend, or shipping a public developer platform, we design APIs that don't break under real-world load and that your future team can actually maintain."
      features={[
        { title: "REST & GraphQL", description: "Whichever fits your domain — designed with clean schemas.", icon: Plug },
        { title: "Auth & rate limiting", description: "JWT, OAuth, API keys, per-tenant quotas built in.", icon: KeyRound },
        { title: "Webhooks & queues", description: "Reliable event delivery with retries and dead-letter handling.", icon: Webhook },
        { title: "Database design", description: "Postgres-first schemas with proper indexes and migrations.", icon: Database },
        { title: "Security hardening", description: "Input validation, RLS, secret rotation and audit logs.", icon: Shield },
        { title: "Performance tuning", description: "Caching layers, query optimization, sub-100ms p95 targets.", icon: Zap },
      ]}
      benefits={[
        "OpenAPI / GraphQL schema delivered",
        "Full test coverage for critical paths",
        "Observability — metrics, logs, traces",
        "CI/CD pipeline included",
        "Source ownership transferred to you",
        "Versioning strategy from day one",
      ]}
      faqs={[
        { q: "What stack do you build APIs on?", a: "Mostly Node.js (TypeScript) and Python. We choose Postgres by default and Redis for caching/queues. We can match an existing stack." },
        { q: "Can you integrate third-party APIs?", a: "Yes. Payments, OTP, SMS, mapping, AI, CRMs, marketplaces — we've connected most of them." },
        { q: "Do you write API documentation?", a: "Yes. Every API ships with OpenAPI/Swagger or GraphQL playground docs, plus a quickstart guide." },
        { q: "Will you host the API for us?", a: "Optional. We can deploy to your cloud (AWS/GCP/DO/Hetzner) or run it on our managed infra with monitoring." },
      ]}
      inquirySource="landing_custom_api_development"
      inquiryTitle="Custom API Development"
    />
  ),
});
