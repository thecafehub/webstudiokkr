/**
 * Centralized site configuration.
 *
 * Every piece of public website content (brand info, navigation, services,
 * product categories, tools, social links, footer) lives here. The future
 * admin panel will read/write these same shapes (later swapped for a DB
 * source) without UI changes.
 */

import {
  Globe,
  Search,
  Cog,
  Bot,
  Send,
  MessageCircle,
  Video,
  Palette,
  ShoppingCart,
  Rocket,
  Server,
  Code2,
  Package,
  Plug,
  LayoutTemplate,
  MapPin,
  Shield,
  Sparkles,
  Wrench,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";

export type NavItem = { label: string; href: string };

export type Service = {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  accent: "blue" | "cyan" | "violet" | "pink";
  features: string[];
};

export type ProductCategory = {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  accent: "blue" | "cyan" | "violet" | "pink";
  count: string;
};

export type ToolCategory = {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
};

export const site = {
  brand: {
    name: "Web Studio KKR",
    short: "WS KKR",
    tagline: "Premium digital craftsmanship from Kurukshetra to the world",
    description:
      "Web Studio KKR is a full-stack digital agency, products marketplace, tools platform and blog — building websites, custom APIs, automation bots and SEO systems for modern businesses.",
    domain: "webstudiokkr.in",
    url: "https://webstudiokkr.in",
    location: "Kurukshetra, Haryana, India",
    founded: "2023",
  },
  contact: {
    email: "nitinkamboj510@gmail.com",
    phone: "+91 8295420609",
    whatsapp: "+918295420609",
    whatsappLink: "https://wa.me/918295420609",
    telegram: "webstudiokkr",
    telegramLink: "https://t.me/webstudiokkr",
    instagram: "webstudiokkr",
    instagramLink: "https://instagram.com/webstudiokkr",
  },
  nav: [
    { label: "Home", href: "/" },
    { label: "Services", href: "/services" },
    { label: "Products", href: "/products" },
    { label: "Tools", href: "/tools" },
    { label: "Blog", href: "/blog" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ] satisfies NavItem[],
  stats: [
    { label: "Projects shipped", value: "120+" },
    { label: "Happy clients", value: "80+" },
    { label: "Countries served", value: "14" },
    { label: "Years of craft", value: "5+" },
  ],
} as const;

export const services: Service[] = [
  {
    id: "website-development",
    title: "Website Development",
    description:
      "Production-grade websites built on React, Next.js and TanStack — fast, secure and engineered to scale with your business.",
    icon: Globe,
    accent: "blue",
    features: ["Modern React stacks", "Performance-first builds", "CMS-ready architecture"],
  },
  {
    id: "website-designing",
    title: "Website Designing",
    description:
      "Pixel-perfect, conversion-focused UI design — distinctive brand systems, not template clichés.",
    icon: LayoutTemplate,
    accent: "cyan",
    features: ["Custom UI design", "Responsive layouts", "Design systems"],
  },
  {
    id: "seo",
    title: "SEO Services",
    description:
      "Technical SEO, on-page optimisation, content strategy and authority building — driven by real keyword data.",
    icon: Search,
    accent: "violet",
    features: ["Technical audit", "Keyword + content roadmap", "Backlink outreach"],
  },
  {
    id: "local-seo",
    title: "Local SEO",
    description:
      "Rank in Kurukshetra and across Haryana — Google Business Profile, local citations, map-pack optimisation and reviews.",
    icon: MapPin,
    accent: "blue",
    features: ["Google Business Profile", "Local citations", "Map-pack ranking"],
  },
  {
    id: "telegram",
    title: "Telegram Bot Development",
    description:
      "Custom Telegram bots — earning bots, channel managers, payment bots and AI assistants, production-deployed on your infra.",
    icon: Send,
    accent: "cyan",
    features: ["Inline + group bots", "Payments & subscriptions", "Channel automation"],
  },
  {
    id: "whatsapp",
    title: "WhatsApp API Integration",
    description:
      "Official WhatsApp Business API setup, broadcast systems, chatbots and CRM integrations for high-conversion messaging.",
    icon: MessageCircle,
    accent: "violet",
    features: ["Official Cloud API", "Broadcast + templates", "CRM sync"],
  },
  {
    id: "api",
    title: "Custom API Development",
    description:
      "Robust REST & GraphQL APIs, third-party integrations and data pipelines engineered for scale, security and uptime.",
    icon: Plug,
    accent: "blue",
    features: ["REST & GraphQL", "Webhooks & queues", "Auth + rate limiting"],
  },
  {
    id: "automation",
    title: "Business Automation",
    description:
      "Workflow automation, scrapers, schedulers and intelligent bots that quietly do the boring work for you.",
    icon: Cog,
    accent: "cyan",
    features: ["Workflow automation", "Scraping & monitoring", "AI-assisted bots"],
  },
  {
    id: "ecommerce",
    title: "E-commerce Development",
    description:
      "Shopify, WooCommerce and headless e-commerce stores tuned for speed, SEO and ruthless checkout conversion.",
    icon: ShoppingCart,
    accent: "violet",
    features: ["Shopify / Woo / Headless", "Payment + shipping setup", "Conversion optimisation"],
  },
  {
    id: "landing",
    title: "Landing Page Development",
    description:
      "High-converting landing pages built around your offer, copy and analytics — shipped in days, not months.",
    icon: Rocket,
    accent: "blue",
    features: ["A/B-ready structure", "Pixel + analytics", "Lead capture flows"],
  },
  {
    id: "graphic-design",
    title: "Graphic Design",
    description:
      "Marketing creatives, social kits and print collateral — clean typography and bold visual systems.",
    icon: Palette,
    accent: "pink",
    features: ["Social creatives", "Brand collateral", "Print + digital kits"],
  },
  {
    id: "logo-design",
    title: "Logo Design",
    description:
      "Distinctive logo marks and brand identities built on real typography — memorable, scalable and versatile.",
    icon: Sparkles,
    accent: "violet",
    features: ["Logo marks", "Brand identity", "Style guidelines"],
  },
  {
    id: "video",
    title: "Video Editing",
    description:
      "Cinematic edits, motion graphics, reels and product videos that look premium and convert on every platform.",
    icon: Video,
    accent: "pink",
    features: ["Reels & shorts", "Motion graphics", "Product videos"],
  },
];

export const productCategories: ProductCategory[] = [
  {
    id: "trading-website",
    title: "Trading Website Source Code",
    description:
      "Production-ready trading website source code — admin panel, user dashboard, wallet, KYC and payment hooks included.",
    icon: TrendingUp,
    accent: "blue",
    count: "Full source",
  },
  {
    id: "smm-panel",
    title: "SMM Panel Source Code",
    description:
      "Complete SMM panel source code with provider API integration, user dashboard, orders, tickets and reseller mode.",
    icon: Rocket,
    accent: "cyan",
    count: "Full source",
  },
  {
    id: "telegram-bot",
    title: "Telegram Bot Source Code",
    description:
      "Ready-to-deploy Telegram bot source codes — earning, referral, broadcast, payment and AI assistants.",
    icon: Send,
    accent: "violet",
    count: "Full source",
  },
  {
    id: "website-template",
    title: "Website Template Source Code",
    description:
      "Beautifully designed, fully responsive website template source codes for agencies, SaaS and creators.",
    icon: LayoutTemplate,
    accent: "pink",
    count: "Full source",
  },
];

export const toolCategories: ToolCategory[] = [
  { id: "seo", title: "SEO Tools", description: "DA/PA checker, keyword density, meta generator, sitemap & robots.txt builders.", icon: Search },
  { id: "dev", title: "Developer Tools", description: "JSON formatter, API tester, regex playground, base64 + JWT decoders.", icon: Code2 },
  { id: "marketing", title: "Marketing Tools", description: "Traffic checker, ad copy generators, headline analyzers, UTM builders.", icon: TrendingUp },
  { id: "api", title: "API Tools", description: "Endpoint pingers, mock servers, schema validators, webhook inspectors.", icon: Plug },
  { id: "business", title: "Business Tools", description: "Invoice generators, GST calculators, ROI estimators, lead scorers.", icon: Sparkles },
  { id: "utility", title: "Utility Tools", description: "Image compressors, PDF tools, color pickers, gradient generators.", icon: Wrench },
];

export const highlights = [
  { title: "Premium craftsmanship", description: "Every line of code, every pixel — designed for production, not demos.", icon: Sparkles },
  { title: "Performance-first", description: "Sub-second load times, perfect Lighthouse scores, SEO-ready architecture.", icon: Rocket },
  { title: "Secure by default", description: "Hardened servers, RBAC, RLS, encrypted secrets — security baked in from day one.", icon: Shield },
  { title: "Built to scale", description: "Architectures that grow from 100 to 1M users without a rewrite.", icon: TrendingUp },
];
