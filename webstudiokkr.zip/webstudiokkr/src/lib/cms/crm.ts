/**
 * CRM queries — leads, lead notes, follow-up reminders.
 *
 * Status pipeline: new → contacted → qualified → won/closed/lost.
 * Lead source captures origin (contact form, WhatsApp click, CTA, product
 * inquiry). Notes are a separate table with the author tracked for audit.
 */
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";

export type Lead = Tables<"leads"> & {
  product?: { id: string; title: string; slug: string } | null;
};
export type LeadNote = Tables<"lead_notes">;
export type LeadStatus = Lead["status"];

export const LEAD_STATUSES: LeadStatus[] = [
  "new",
  "contacted",
  "qualified",
  "won",
  "closed",
  "lost",
];

export const LEAD_STATUS_LABEL: Record<LeadStatus, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  won: "Won",
  closed: "Closed",
  lost: "Lost",
};

const LEAD_SELECT =
  "id, name, email, phone, message, source, status, metadata, assigned_to, follow_up_at, product_id, internal_notes, created_at, updated_at, product:products(id, title, slug)";

export async function listLeads(): Promise<Lead[]> {
  const { data, error } = await supabase
    .from("leads")
    .select(LEAD_SELECT)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Lead[];
}

export async function createLead(input: TablesInsert<"leads">): Promise<Lead> {
  const { data, error } = await supabase
    .from("leads")
    .insert(input)
    .select(LEAD_SELECT)
    .single();
  if (error) throw error;
  return data as unknown as Lead;
}

export async function updateLead(
  id: string,
  patch: TablesUpdate<"leads">,
): Promise<Lead> {
  const { data, error } = await supabase
    .from("leads")
    .update(patch)
    .eq("id", id)
    .select(LEAD_SELECT)
    .single();
  if (error) throw error;
  return data as unknown as Lead;
}

export async function deleteLead(id: string): Promise<void> {
  const { error } = await supabase.from("leads").delete().eq("id", id);
  if (error) throw error;
}

export async function listNotes(leadId: string): Promise<LeadNote[]> {
  const { data, error } = await supabase
    .from("lead_notes")
    .select("*")
    .eq("lead_id", leadId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function addNote(leadId: string, body: string): Promise<LeadNote> {
  const { data: u } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("lead_notes")
    .insert({ lead_id: leadId, body, author_id: u.user?.id ?? null })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteNote(id: string): Promise<void> {
  const { error } = await supabase.from("lead_notes").delete().eq("id", id);
  if (error) throw error;
}

/** Leads with follow_up_at <= now and not in a closed state. */
export function isDueFollowUp(lead: Lead): boolean {
  if (!lead.follow_up_at) return false;
  if (lead.status === "won" || lead.status === "closed" || lead.status === "lost") return false;
  return new Date(lead.follow_up_at).getTime() <= Date.now();
}

/** Public lead-creation helper used by the contact form and CTA buttons. */
export async function submitPublicLead(input: {
  name: string;
  email: string;
  phone?: string;
  message: string;
  source: string;
  productId?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  const { error } = await supabase.from("leads").insert({
    name: input.name,
    email: input.email,
    phone: input.phone ?? null,
    message: input.message,
    source: input.source,
    product_id: input.productId ?? null,
    metadata: (input.metadata ?? {}) as never,
  });
  if (error) throw error;
}
