/**
 * Media library queries — DB-backed catalog of uploaded images / external URLs.
 *
 * Files uploaded through the admin live in the private "media" Storage bucket.
 * We resolve a long-lived signed URL on upload (10 years) and store it on the
 * row so it can be embedded directly in <img> tags. External URLs (pasted by
 * the admin) are stored as-is.
 */
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type MediaItem = Tables<"media">;

const TEN_YEARS_SECONDS = 60 * 60 * 24 * 365 * 10;

export async function listMedia(filters?: {
  folder?: string;
  search?: string;
}): Promise<MediaItem[]> {
  let q = supabase
    .from("media")
    .select("*")
    .order("created_at", { ascending: false });
  if (filters?.folder && filters.folder !== "all") q = q.eq("folder", filters.folder);
  if (filters?.search) q = q.ilike("name", `%${filters.search}%`);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

export async function listFolders(): Promise<string[]> {
  const { data, error } = await supabase.from("media").select("folder");
  if (error) throw error;
  const set = new Set<string>(["general"]);
  for (const row of data ?? []) set.add(row.folder ?? "general");
  return Array.from(set).sort();
}

export async function uploadMediaFile(
  file: File,
  folder: string,
  altText?: string,
): Promise<MediaItem> {
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${folder}/${Date.now()}_${safeName}`;
  const { error: upErr } = await supabase.storage
    .from("media")
    .upload(path, file, { contentType: file.type || undefined, upsert: false });
  if (upErr) throw upErr;

  const { data: signed, error: signErr } = await supabase.storage
    .from("media")
    .createSignedUrl(path, TEN_YEARS_SECONDS);
  if (signErr) throw signErr;

  const { data: u } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("media")
    .insert({
      name: file.name,
      url: signed.signedUrl,
      storage_path: path,
      mime_type: file.type || null,
      size_bytes: file.size,
      alt_text: altText ?? null,
      folder,
      uploaded_by: u.user?.id ?? null,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function addExternalMedia(input: {
  name: string;
  url: string;
  folder: string;
  altText?: string;
}): Promise<MediaItem> {
  const { data: u } = await supabase.auth.getUser();
  const { data, error } = await supabase
    .from("media")
    .insert({
      name: input.name,
      url: input.url,
      folder: input.folder,
      alt_text: input.altText ?? null,
      uploaded_by: u.user?.id ?? null,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteMedia(item: MediaItem): Promise<void> {
  if (item.storage_path) {
    await supabase.storage.from("media").remove([item.storage_path]);
  }
  const { error } = await supabase.from("media").delete().eq("id", item.id);
  if (error) throw error;
}

export async function renameMediaFolder(id: string, folder: string): Promise<void> {
  const { error } = await supabase.from("media").update({ folder }).eq("id", id);
  if (error) throw error;
}
