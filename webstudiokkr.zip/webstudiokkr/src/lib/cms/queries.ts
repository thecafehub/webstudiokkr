/**
 * CMS query helpers — Supabase reads/writes for blogs & products.
 *
 * Pattern: tiny pure functions that each take a Supabase client and return a
 * typed Promise. Components call them through TanStack Query.
 */
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate, Json } from "@/integrations/supabase/types";

export type Blog = Tables<"blogs"> & {
  category?: { id: string; slug: string; name: string } | null;
};
export type Product = Tables<"products"> & {
  category?: { id: string; slug: string; name: string } | null;
};
export type Category = Tables<"categories">;

export type BlogInsert = TablesInsert<"blogs">;
export type BlogUpdate = TablesUpdate<"blogs">;
export type ProductInsert = TablesInsert<"products">;
export type ProductUpdate = TablesUpdate<"products">;

/** Structured FAQ entry stored on products.faqs (jsonb). */
export type ProductFaq = { q: string; a: string };

export function parseFaqs(value: Json | null | undefined): ProductFaq[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((row): ProductFaq | null => {
      if (!row || typeof row !== "object") return null;
      const obj = row as Record<string, unknown>;
      const q = typeof obj.q === "string" ? obj.q : "";
      const a = typeof obj.a === "string" ? obj.a : "";
      if (!q || !a) return null;
      return { q, a };
    })
    .filter((x): x is ProductFaq => x !== null);
}

const BLOG_SELECT =
  "id, slug, title, excerpt, body, featured, featured_image, status, publish_at, reading_minutes, view_count, seo_title, seo_description, author_id, category_id, created_at, updated_at, category:categories(id, slug, name)";

const PRODUCT_SELECT =
  "id, slug, title, description, long_description, price, compare_at_price, currency, image, gallery, features, faqs, demo_url, download_url, featured, popular, trending, status, seo_title, seo_description, category_id, created_at, updated_at, category:categories(id, slug, name)";

/* ----------------------------- Categories -------------------------------- */

export async function listCategories(kind: "blog" | "product"): Promise<Category[]> {
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .eq("kind", kind)
    .order("position", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

/* -------------------------------- Blogs --------------------------------- */

export async function listBlogsAdmin(): Promise<Blog[]> {
  const { data, error } = await supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Blog[];
}

export async function listBlogsPublic(): Promise<Blog[]> {
  const { data, error } = await supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .eq("status", "published")
    .or(`publish_at.is.null,publish_at.lte.${new Date().toISOString()}`)
    .order("publish_at", { ascending: false, nullsFirst: false });
  if (error) throw error;
  return (data ?? []) as unknown as Blog[];
}

export async function listFeaturedBlogs(limit = 3): Promise<Blog[]> {
  const { data, error } = await supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .eq("status", "published")
    .eq("featured", true)
    .order("publish_at", { ascending: false, nullsFirst: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as Blog[];
}

export async function listPopularBlogs(limit = 5): Promise<Blog[]> {
  const { data, error } = await supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .eq("status", "published")
    .order("view_count", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as Blog[];
}

export async function listRelatedBlogs(
  categoryId: string | null,
  excludeId: string,
  limit = 3,
): Promise<Blog[]> {
  let q = supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .eq("status", "published")
    .neq("id", excludeId)
    .order("publish_at", { ascending: false, nullsFirst: false })
    .limit(limit);
  if (categoryId) q = q.eq("category_id", categoryId);
  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []) as unknown as Blog[];
}

export async function getBlogBySlug(slug: string): Promise<Blog | null> {
  const { data, error } = await supabase
    .from("blogs")
    .select(BLOG_SELECT)
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw error;
  return (data as unknown as Blog) ?? null;
}

export async function upsertBlog(input: BlogInsert | (BlogUpdate & { id: string })) {
  if ("id" in input && input.id) {
    const { id, ...rest } = input;
    const { data, error } = await supabase
      .from("blogs")
      .update(rest)
      .eq("id", id)
      .select(BLOG_SELECT)
      .single();
    if (error) throw error;
    return data as unknown as Blog;
  }
  const { data, error } = await supabase
    .from("blogs")
    .insert(input as BlogInsert)
    .select(BLOG_SELECT)
    .single();
  if (error) throw error;
  return data as unknown as Blog;
}

export async function deleteBlog(id: string) {
  const { error } = await supabase.from("blogs").delete().eq("id", id);
  if (error) throw error;
}

/* ------------------------------ Products -------------------------------- */

export async function listProductsAdmin(): Promise<Product[]> {
  const { data, error } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as Product[];
}

export async function listProductsPublic(filters?: {
  categorySlug?: string;
  featuredOnly?: boolean;
  trendingOnly?: boolean;
  limit?: number;
}): Promise<Product[]> {
  let q = supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("status", "published")
    .order("created_at", { ascending: false });
  if (filters?.featuredOnly) q = q.eq("featured", true);
  if (filters?.trendingOnly) q = q.eq("trending", true);
  if (filters?.limit) q = q.limit(filters.limit);
  const { data, error } = await q;
  if (error) throw error;
  let rows = (data ?? []) as unknown as Product[];
  if (filters?.categorySlug) {
    rows = rows.filter((p) => p.category?.slug === filters.categorySlug);
  }
  return rows;
}

export async function listRelatedProducts(
  categoryId: string | null,
  excludeId: string,
  limit = 4,
): Promise<Product[]> {
  let q = supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("status", "published")
    .neq("id", excludeId)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (categoryId) q = q.eq("category_id", categoryId);
  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []) as unknown as Product[];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw error;
  return (data as unknown as Product) ?? null;
}

export async function upsertProduct(
  input: ProductInsert | (ProductUpdate & { id: string }),
) {
  if ("id" in input && input.id) {
    const { id, ...rest } = input;
    const { data, error } = await supabase
      .from("products")
      .update(rest)
      .eq("id", id)
      .select(PRODUCT_SELECT)
      .single();
    if (error) throw error;
    return data as unknown as Product;
  }
  const { data, error } = await supabase
    .from("products")
    .insert(input as ProductInsert)
    .select(PRODUCT_SELECT)
    .single();
  if (error) throw error;
  return data as unknown as Product;
}

export async function deleteProduct(id: string) {
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw error;
}

/* ----------------------------- Utilities -------------------------------- */

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
