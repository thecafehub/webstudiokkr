/**
 * Website settings — KV store backed by `website_settings`.
 *
 * Every editable surface of the public site (brand identity, contact, hero
 * copy, homepage stats, CTA buttons, footer) lives here as a JSON value
 * keyed by section. The static `site` constant in `@/config/site` provides
 * fallbacks so the site renders on first paint and before any keys exist.
 */
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { site } from "@/config/site";

export type BrandSettings = {
  name: string;
  tagline: string;
  description: string;
  logoUrl: string;
  faviconUrl: string;
};

export type ContactSettings = {
  email: string;
  phone: string;
  whatsapp: string;
  whatsappLink: string;
  telegram: string;
  telegramLink: string;
  instagram: string;
  instagramLink: string;
  address: string;
};

export type HeroSettings = {
  eyebrow: string;
  headline: string;
  highlight: string;
  subcopy: string;
  ctaPrimary: { label: string; href: string };
  ctaSecondary: { label: string; href: string };
};

export type StatItem = { label: string; value: string };

export type FooterSettings = {
  copyright: string;
  tagline: string;
};

export type IntegrationsSettings = {
  ga4MeasurementId: string;
  ga4PropertyId: string;
  gscSiteUrl: string;
  clarityProjectId: string;
};

export type SiteSettings = {
  brand: BrandSettings;
  contact: ContactSettings;
  hero: HeroSettings;
  stats: StatItem[];
  footer: FooterSettings;
  integrations: IntegrationsSettings;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  brand: {
    name: site.brand.name,
    tagline: site.brand.tagline,
    description: site.brand.description,
    logoUrl: "",
    faviconUrl: "/favicon.ico",
  },
  contact: {
    email: site.contact.email,
    phone: site.contact.phone,
    whatsapp: site.contact.whatsapp,
    whatsappLink: site.contact.whatsappLink,
    telegram: site.contact.telegram,
    telegramLink: site.contact.telegramLink,
    instagram: site.contact.instagram,
    instagramLink: site.contact.instagramLink,
    address: site.brand.location,
  },
  hero: {
    eyebrow: "Premium digital craftsmanship",
    headline: "Websites, SEO, APIs, Automation",
    highlight: "& Digital Products",
    subcopy: site.brand.tagline,
    ctaPrimary: { label: "Start a project", href: "/contact" },
    ctaSecondary: { label: "Explore services", href: "/services" },
  },
  stats: site.stats.map((s) => ({ label: s.label, value: s.value })),
  footer: {
    copyright: `© ${new Date().getFullYear()} ${site.brand.name}`,
    tagline: site.brand.tagline,
  },
  integrations: {
    ga4MeasurementId: "G-LMK3HRTESX",
    ga4PropertyId: "542294012",
    gscSiteUrl: "https://webstudiokkr.in/",
    clarityProjectId: "",
  },
};

export const SETTINGS_KEYS = [
  "brand",
  "contact",
  "hero",
  "stats",
  "footer",
  "integrations",
] as const;

export type SettingsKey = (typeof SETTINGS_KEYS)[number];

function merge<T>(base: T, override: unknown): T {
  if (!override || typeof override !== "object") return base;
  if (Array.isArray(base)) return (override as T) ?? base;
  return { ...(base as object), ...(override as object) } as T;
}

export async function loadSiteSettings(): Promise<SiteSettings> {
  const { data, error } = await supabase
    .from("website_settings")
    .select("key, value")
    .in("key", [...SETTINGS_KEYS]);
  if (error) {
    // Public read may fail until policies set; fall back to defaults.
    return DEFAULT_SETTINGS;
  }
  const map = new Map<string, unknown>((data ?? []).map((r) => [r.key, r.value]));
  return {
    brand: merge(DEFAULT_SETTINGS.brand, map.get("brand")),
    contact: merge(DEFAULT_SETTINGS.contact, map.get("contact")),
    hero: merge(DEFAULT_SETTINGS.hero, map.get("hero")),
    stats: (map.get("stats") as StatItem[] | undefined) ?? DEFAULT_SETTINGS.stats,
    footer: merge(DEFAULT_SETTINGS.footer, map.get("footer")),
    integrations: merge(DEFAULT_SETTINGS.integrations, map.get("integrations")),
  };
}

export async function saveSettingsKey<K extends SettingsKey>(
  key: K,
  value: SiteSettings[K],
): Promise<void> {
  const { error } = await supabase
    .from("website_settings")
    .upsert(
      { key, value: value as never, is_public: key !== "integrations" },
      { onConflict: "key" },
    );
  if (error) throw error;
}

/** React hook — returns live settings, falling back to defaults during fetch. */
export function useSiteSettings(): SiteSettings {
  const { data } = useQuery({
    queryKey: ["site-settings"],
    queryFn: loadSiteSettings,
    staleTime: 60_000,
    placeholderData: DEFAULT_SETTINGS,
  });
  return data ?? DEFAULT_SETTINGS;
}
