/**
 * Thin GA4 helper. Safe to call from anywhere — no-ops on the server
 * and when gtag hasn't been injected yet (e.g. no Measurement ID configured).
 */
declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    dataLayer?: unknown[];
  }
}

export function trackEvent(name: string, params: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  try {
    window.gtag?.("event", name, params);
  } catch {
    /* swallow */
  }
}

export function trackPageView(path: string, title?: string) {
  if (typeof window === "undefined") return;
  try {
    window.gtag?.("event", "page_view", {
      page_path: path,
      page_location: window.location.href,
      page_title: title ?? document.title,
    });
  } catch {
    /* swallow */
  }
}
