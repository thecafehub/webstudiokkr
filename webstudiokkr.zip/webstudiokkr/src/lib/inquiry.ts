/**
 * Inquiry helpers — WhatsApp / Telegram deep links + CRM lead capture.
 *
 * Phase 8 replaces direct purchases with lightweight inquiry CTAs. Every
 * click also writes a soft lead so the CRM tracks demand even when the
 * customer continues the conversation off-platform.
 */
import { site } from "@/config/site";
import { submitPublicLead } from "@/lib/cms/crm";
import { trackEvent } from "@/lib/analytics/track";

export const WHATSAPP_NUMBER = "918295420609";
export const TELEGRAM_USERNAME = "webstudiokkr";

export type InquiryContext = {
  productId?: string | null;
  productTitle?: string;
  productSlug?: string;
  category?: string;
  source: string; // e.g. "product_card_whatsapp", "landing_seo_kurukshetra"
};

/** Build the prefilled message body for an inquiry. */
export function buildInquiryMessage(ctx: InquiryContext): string {
  const lines: string[] = ["Hi Web Studio KKR,"];
  if (ctx.productTitle) {
    lines.push("");
    lines.push(`I'm interested in *${ctx.productTitle}*.`);
    if (ctx.category) lines.push(`Category: ${ctx.category}`);
    if (ctx.productSlug) {
      lines.push(`Link: ${site.brand.url}/products/${ctx.productSlug}`);
    }
  } else {
    lines.push("");
    lines.push("I'd like to discuss a project with your team.");
  }
  lines.push("");
  lines.push("Please share details and next steps. Thanks!");
  return lines.join("\n");
}

export function whatsappLink(ctx: InquiryContext): string {
  const text = encodeURIComponent(buildInquiryMessage(ctx));
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

/** Telegram deep link to the studio username. t.me/<user> doesn't accept
 *  prefilled text, so we copy the message to the clipboard on click. */
export function telegramLink(): string {
  return `https://t.me/${TELEGRAM_USERNAME}`;
}

/** Record a soft lead in the CRM and fire an analytics event. Errors are
 *  swallowed — the inquiry experience must never break on telemetry. */
export async function trackInquiry(
  channel: "whatsapp" | "telegram",
  ctx: InquiryContext,
): Promise<void> {
  trackEvent("inquiry_click", {
    channel,
    source: ctx.source,
    product_id: ctx.productId ?? null,
    product_title: ctx.productTitle ?? null,
  });
  try {
    await submitPublicLead({
      name: ctx.productTitle ? `${channel} · ${ctx.productTitle}` : `${channel} inquiry`,
      email: `${channel}@webstudiokkr.in`,
      message: buildInquiryMessage(ctx),
      source: `${channel}:${ctx.source}`,
      productId: ctx.productId ?? null,
      metadata: {
        kind: "inquiry",
        channel,
        product_title: ctx.productTitle ?? null,
        category: ctx.category ?? null,
        pathname:
          typeof window !== "undefined" ? window.location.pathname : null,
      },
    });
  } catch (err) {
    // Non-fatal — never break the inquiry UX — but log so failures aren't invisible.
    console.error("[inquiry] failed to record lead", err);
  }

}

export async function copyToClipboard(text: string): Promise<boolean> {
  if (typeof navigator === "undefined") return false;
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
