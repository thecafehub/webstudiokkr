/**
 * Admin authentication — Supabase-backed with role-based access control.
 *
 * Roles (see app_role enum): admin > manager > editor > user
 * - admin   : full access (settings, roles, integrations, content, CRM, media)
 * - manager : content + media + CRM (leads, notes, follow-ups) + analytics
 * - editor  : content + media only
 * - user    : public / no admin access
 *
 * Login bootstrap: the canonical `nitin` / `nitin123` account auto-claims
 * `admin` on first sign-in via the `claim_admin_if_no_admin_exists` RPC.
 * Session persistence is handled by the Supabase client.
 */
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const ADMIN_USERNAME = "nitin";
export const ADMIN_EMAIL = "nitin@webstudiokkr.in";

export type AppRole = "admin" | "manager" | "editor" | "user";

/** Logical permission keys — map to allowed roles. */
export type Permission =
  | "content"
  | "media"
  | "crm"
  | "analytics"
  | "settings"
  | "roles"
  | "integrations";

const PERMISSION_MATRIX: Record<Permission, AppRole[]> = {
  content: ["admin", "editor", "manager"],
  media: ["admin", "editor", "manager"],
  crm: ["admin", "manager"],
  analytics: ["admin", "manager"],
  settings: ["admin"],
  roles: ["admin"],
  integrations: ["admin"],
};

export type AdminAuthState = {
  ready: boolean;
  userId: string | null;
  email: string | null;
  roles: AppRole[];
  /** Convenience: any admin-area role (admin|manager|editor). */
  isStaff: boolean;
  isAdmin: boolean;
  hasRole: (r: AppRole) => boolean;
  can: (p: Permission) => boolean;
};

const INITIAL: AdminAuthState = {
  ready: false,
  userId: null,
  email: null,
  roles: [],
  isStaff: false,
  isAdmin: false,
  hasRole: () => false,
  can: () => false,
};

function build(userId: string | null, email: string | null, roles: AppRole[]): AdminAuthState {
  const set = new Set(roles);
  const hasRole = (r: AppRole) => set.has(r);
  return {
    ready: true,
    userId,
    email,
    roles,
    isStaff: set.has("admin") || set.has("manager") || set.has("editor"),
    isAdmin: set.has("admin"),
    hasRole,
    can: (p) => PERMISSION_MATRIX[p].some((r) => set.has(r)),
  };
}

/** React hook: returns admin auth state, kept in sync with Supabase. */
export function useAdminAuth(): AdminAuthState {
  const [state, setState] = useState<AdminAuthState>(INITIAL);

  useEffect(() => {
    let cancelled = false;

    async function hydrate(userId: string | null, email: string | null) {
      if (!userId) {
        if (!cancelled) setState(build(null, null, []));
        return;
      }
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId);
      if (cancelled) return;
      const roles = ((data ?? []).map((r) => r.role) as AppRole[]) ?? [];
      setState(build(userId, email, roles));
    }

    supabase.auth.getSession().then(({ data }) => {
      const s = data.session;
      hydrate(s?.user.id ?? null, s?.user.email ?? null);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED")
        return;
      hydrate(session?.user.id ?? null, session?.user.email ?? null);
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  return state;
}

/** Resolve the email used for sign-in: accept "nitin" as an alias. */
export function resolveLoginIdentifier(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return trimmed;
  if (trimmed.toLowerCase() === ADMIN_USERNAME) return ADMIN_EMAIL;
  return trimmed;
}

export async function adminLogin(
  identifier: string,
  password: string,
): Promise<{ ok: boolean; error?: string }> {
  const email = resolveLoginIdentifier(identifier);

  let signIn = await supabase.auth.signInWithPassword({ email, password });

  if (
    signIn.error &&
    email.toLowerCase() === ADMIN_EMAIL.toLowerCase() &&
    password === "nitin123"
  ) {
    const signUp = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo:
          typeof window !== "undefined" ? `${window.location.origin}/admin` : undefined,
        data: { display_name: "Nitin" },
      },
    });
    if (signUp.error && !/already registered/i.test(signUp.error.message)) {
      return { ok: false, error: signUp.error.message };
    }
    signIn = await supabase.auth.signInWithPassword({ email, password });
    if (signIn.error || !signIn.data.user) {
      return {
        ok: false,
        error:
          "Account created but sign-in is pending email confirmation. Disable email confirmation in Cloud → Users → Auth Settings, then try again.",
      };
    }
    await supabase.rpc("claim_admin_if_no_admin_exists");
  }

  if (signIn.error || !signIn.data.user) {
    return { ok: false, error: signIn.error?.message ?? "Invalid credentials" };
  }

  // Any admin-area role grants access; specific permissions are enforced per-page.
  const { data: roles } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", signIn.data.user.id);

  const allowed = (roles ?? []).some((r) =>
    ["admin", "manager", "editor"].includes(r.role as string),
  );
  if (!allowed) {
    await supabase.auth.signOut();
    return { ok: false, error: "This account does not have admin access." };
  }

  return { ok: true };
}

export async function adminLogout(): Promise<void> {
  await supabase.auth.signOut();
}
