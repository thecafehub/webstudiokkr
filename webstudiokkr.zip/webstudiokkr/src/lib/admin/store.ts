/**
 * Centralised CMS store — localStorage-backed for now.
 *
 * Every shape in here is what the future database tables will look like, so
 * swapping the persistence layer (Cloud / Postgres) requires no UI changes.
 * Hooks below use `useSyncExternalStore` so all admin pages stay in sync.
 */
import { useSyncExternalStore } from "react";
import { site, services, productCategories, toolCategories } from "@/config/site";

// --- Types ---------------------------------------------------------------

export type PageContent = {
  id: string;
  title: string;
  subtitle: string;
  heroHeadline: string;
  heroSubcopy: string;
  primaryCta: string;
  secondaryCta: string;
  body: string;
  visible: boolean;
};

export type ServiceItem = {
  id: string;
  title: string;
  description: string;
  features: string[];
  accent: "blue" | "cyan" | "violet" | "pink";
  enabled: boolean;
  order: number;
};

export type ProductItem = {
  id: string;
  title: string;
  category: string;
  description: string;
  price: number;
  image: string;
  featured: boolean;
  popular: boolean;
  seoTitle: string;
  seoDescription: string;
  createdAt: number;
};

export type ToolItem = {
  id: string;
  title: string;
  description: string;
  category: string;
  url: string;
  enabled: boolean;
};

export type BlogPost = {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  body: string;
  category: string;
  tags: string[];
  featuredImage: string;
  status: "draft" | "scheduled" | "published";
  publishAt: number;
  createdAt: number;
};

export type SeoEntry = {
  pageId: string;
  metaTitle: string;
  metaDescription: string;
  keywords: string;
  canonical: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  twitterCard: "summary" | "summary_large_image";
  schema: string;
};

export type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  source: string;
  status: "new" | "contacted" | "won" | "lost";
  createdAt: number;
};

export type MediaItem = {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: number;
};

export type IntegrationsConfig = {
  ga4MeasurementId: string;
  ga4PropertyId: string;
  gscSiteUrl: string;
  clarityProjectId: string;
  psiApiKey: string;
};

export type SiteSettings = {
  brand: { name: string; tagline: string; logoUrl: string; faviconUrl: string };
  contact: {
    email: string;
    phone: string;
    whatsapp: string;
    telegram: string;
    instagram: string;
    address: string;
  };
  hero: { headline: string; subcopy: string; ctaPrimary: string; ctaSecondary: string };
  footer: { copyright: string; tagline: string };
  integrations: IntegrationsConfig;
};

export type PsiHistoryEntry = {
  pageId: string;
  strategy: "mobile" | "desktop";
  fetchedAt: number;
  source: "live" | "demo" | "pending";
  scores: { performance: number; accessibility: number; bestPractices: number; seo: number };
  vitals: { lcp: number; cls: number; inp: number; fcp: number; ttfb: number };
};

export type CmsState = {
  pages: PageContent[];
  services: ServiceItem[];
  products: ProductItem[];
  tools: ToolItem[];
  blog: BlogPost[];
  seo: SeoEntry[];
  leads: Lead[];
  media: MediaItem[];
  settings: SiteSettings;
  psiHistory: PsiHistoryEntry[];
};

// --- Defaults seeded from site.ts ---------------------------------------

const DEFAULT_PAGES: PageContent[] = [
  { id: "home", title: "Home", subtitle: "Premium digital craftsmanship", heroHeadline: "Websites, SEO, APIs, Automation & Digital Products", heroSubcopy: site.brand.tagline, primaryCta: "Start a project", secondaryCta: "Explore services", body: "", visible: true },
  { id: "services", title: "Services", subtitle: "What we build", heroHeadline: "Services", heroSubcopy: "From websites to bots, APIs to SEO — engineered for growth.", primaryCta: "Get a quote", secondaryCta: "See portfolio", body: "", visible: true },
  { id: "products", title: "Products", subtitle: "Marketplace", heroHeadline: "Products", heroSubcopy: "Production-ready source codes, bots, APIs and templates.", primaryCta: "Browse all", secondaryCta: "Featured", body: "", visible: true },
  { id: "tools", title: "Tools", subtitle: "Free utilities", heroHeadline: "Tools", heroSubcopy: "SEO, dev, marketing and utility tools — all free.", primaryCta: "Open tools", secondaryCta: "Request a tool", body: "", visible: true },
  { id: "blog", title: "Blog", subtitle: "Insights", heroHeadline: "Blog", heroSubcopy: "Notes on web, growth, automation and AI.", primaryCta: "Read latest", secondaryCta: "Subscribe", body: "", visible: true },
  { id: "about", title: "About", subtitle: "Who we are", heroHeadline: "About Web Studio KKR", heroSubcopy: "A premium digital studio from Kurukshetra.", primaryCta: "Work with us", secondaryCta: "Our story", body: "", visible: true },
  { id: "contact", title: "Contact", subtitle: "Let's talk", heroHeadline: "Contact", heroSubcopy: "Tell us about your project — we reply within 24 hours.", primaryCta: "Send message", secondaryCta: "WhatsApp us", body: "", visible: true },
];

const DEFAULT_SERVICES: ServiceItem[] = services.map((s, i) => ({
  id: s.id,
  title: s.title,
  description: s.description,
  features: [...s.features],
  accent: s.accent,
  enabled: true,
  order: i,
}));

const DEFAULT_PRODUCTS: ProductItem[] = productCategories.flatMap((c, ci) =>
  Array.from({ length: 2 }).map((_, i) => ({
    id: `${c.id}-${i + 1}`,
    title: `${c.title} Starter ${i + 1}`,
    category: c.id,
    description: c.description,
    price: 999 + ci * 500 + i * 250,
    image: "",
    featured: i === 0,
    popular: ci % 2 === 0 && i === 0,
    seoTitle: `${c.title} Starter ${i + 1} — Web Studio KKR`,
    seoDescription: c.description,
    createdAt: Date.now() - (ci * 86400000 + i * 3600000),
  })),
);

const DEFAULT_TOOLS: ToolItem[] = toolCategories.map((t) => ({
  id: t.id,
  title: t.title,
  description: t.description,
  category: t.id,
  url: `/tools#${t.id}`,
  enabled: true,
}));

const DEFAULT_BLOG: BlogPost[] = [
  { id: "welcome", title: "Welcome to Web Studio KKR", slug: "welcome", excerpt: "Why we built this platform.", body: "Full content here.", category: "company", tags: ["welcome", "launch"], featuredImage: "", status: "published", publishAt: Date.now() - 86400000, createdAt: Date.now() - 86400000 },
];

const DEFAULT_SEO: SeoEntry[] = DEFAULT_PAGES.map((p) => ({
  pageId: p.id,
  metaTitle: `${p.title} — ${site.brand.name}`,
  metaDescription: p.heroSubcopy,
  keywords: `${p.title}, web studio, kurukshetra, ${site.brand.name}`,
  canonical: p.id === "home" ? "/" : `/${p.id}`,
  ogTitle: `${p.title} — ${site.brand.name}`,
  ogDescription: p.heroSubcopy,
  ogImage: "",
  twitterCard: "summary_large_image",
  schema: "",
}));

const DEFAULT_SETTINGS: SiteSettings = {
  brand: { name: site.brand.name, tagline: site.brand.tagline, logoUrl: "", faviconUrl: "/favicon.ico" },
  contact: {
    email: site.contact.email,
    phone: site.contact.phone,
    whatsapp: site.contact.whatsapp,
    telegram: site.contact.telegram,
    instagram: site.contact.instagram,
    address: site.brand.location,
  },
  hero: { headline: "Websites, SEO, APIs, Automation & Digital Products", subcopy: site.brand.tagline, ctaPrimary: "Start a project", ctaSecondary: "Explore services" },
  footer: { copyright: `© ${new Date().getFullYear()} ${site.brand.name}`, tagline: site.brand.tagline },
  integrations: {
    ga4MeasurementId: "G-LMK3HRTESX",
    ga4PropertyId: "542294012",
    gscSiteUrl: "https://webstudiokkr.in/",
    clarityProjectId: "",
    psiApiKey: "",
  },
};

const DEFAULT_STATE: CmsState = {
  pages: DEFAULT_PAGES,
  services: DEFAULT_SERVICES,
  products: DEFAULT_PRODUCTS,
  tools: DEFAULT_TOOLS,
  blog: DEFAULT_BLOG,
  seo: DEFAULT_SEO,
  leads: [],
  media: [],
  settings: DEFAULT_SETTINGS,
  psiHistory: [],
};

// --- Storage layer ------------------------------------------------------

const STORAGE_KEY = "wskkr_cms_state_v1";
let memoryState: CmsState = DEFAULT_STATE;
const listeners = new Set<() => void>();

function load(): CmsState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw) as Partial<CmsState>;
    const merged: CmsState = { ...DEFAULT_STATE, ...parsed };
    merged.settings = {
      ...DEFAULT_STATE.settings,
      ...(parsed.settings ?? {}),
      integrations: {
        ...DEFAULT_STATE.settings.integrations,
        ...((parsed.settings as Partial<SiteSettings> | undefined)?.integrations ?? {}),
      },
    };
    return merged;
  } catch {
    return DEFAULT_STATE;
  }
}

function persist(state: CmsState) {
  memoryState = state;
  if (typeof window !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }
  listeners.forEach((l) => l());
}

if (typeof window !== "undefined") {
  memoryState = load();
}

export function getCmsState(): CmsState {
  return memoryState;
}

export function setCmsState(updater: (s: CmsState) => CmsState) {
  persist(updater(memoryState));
}

export function resetCmsState() {
  persist(DEFAULT_STATE);
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function useCms<T>(selector: (s: CmsState) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(memoryState),
    () => selector(DEFAULT_STATE),
  );
}

// --- Convenience helpers used by managers -------------------------------

export const cms = {
  upsertPage(page: PageContent) {
    setCmsState((s) => ({
      ...s,
      pages: s.pages.some((p) => p.id === page.id)
        ? s.pages.map((p) => (p.id === page.id ? page : p))
        : [...s.pages, page],
    }));
  },
  upsertService(item: ServiceItem) {
    setCmsState((s) => ({
      ...s,
      services: s.services.some((x) => x.id === item.id)
        ? s.services.map((x) => (x.id === item.id ? item : x))
        : [...s.services, item],
    }));
  },
  deleteService(id: string) {
    setCmsState((s) => ({ ...s, services: s.services.filter((x) => x.id !== id) }));
  },
  reorderService(id: string, dir: -1 | 1) {
    setCmsState((s) => {
      const arr = [...s.services].sort((a, b) => a.order - b.order);
      const i = arr.findIndex((x) => x.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= arr.length) return s;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      return { ...s, services: arr.map((x, k) => ({ ...x, order: k })) };
    });
  },
  upsertProduct(item: ProductItem) {
    setCmsState((s) => ({
      ...s,
      products: s.products.some((x) => x.id === item.id)
        ? s.products.map((x) => (x.id === item.id ? item : x))
        : [...s.products, item],
    }));
  },
  deleteProduct(id: string) {
    setCmsState((s) => ({ ...s, products: s.products.filter((x) => x.id !== id) }));
  },
  upsertTool(item: ToolItem) {
    setCmsState((s) => ({
      ...s,
      tools: s.tools.some((x) => x.id === item.id)
        ? s.tools.map((x) => (x.id === item.id ? item : x))
        : [...s.tools, item],
    }));
  },
  deleteTool(id: string) {
    setCmsState((s) => ({ ...s, tools: s.tools.filter((x) => x.id !== id) }));
  },
  upsertPost(item: BlogPost) {
    setCmsState((s) => ({
      ...s,
      blog: s.blog.some((x) => x.id === item.id)
        ? s.blog.map((x) => (x.id === item.id ? item : x))
        : [...s.blog, item],
    }));
  },
  deletePost(id: string) {
    setCmsState((s) => ({ ...s, blog: s.blog.filter((x) => x.id !== id) }));
  },
  upsertSeo(entry: SeoEntry) {
    setCmsState((s) => ({
      ...s,
      seo: s.seo.some((x) => x.pageId === entry.pageId)
        ? s.seo.map((x) => (x.pageId === entry.pageId ? entry : x))
        : [...s.seo, entry],
    }));
  },
  addLead(lead: Lead) {
    setCmsState((s) => ({ ...s, leads: [lead, ...s.leads] }));
  },
  updateLead(id: string, patch: Partial<Lead>) {
    setCmsState((s) => ({ ...s, leads: s.leads.map((l) => (l.id === id ? { ...l, ...patch } : l)) }));
  },
  deleteLead(id: string) {
    setCmsState((s) => ({ ...s, leads: s.leads.filter((l) => l.id !== id) }));
  },
  addMedia(m: MediaItem) {
    setCmsState((s) => ({ ...s, media: [m, ...s.media] }));
  },
  deleteMedia(id: string) {
    setCmsState((s) => ({ ...s, media: s.media.filter((m) => m.id !== id) }));
  },
  updateSettings(patch: Partial<SiteSettings>) {
    setCmsState((s) => ({ ...s, settings: { ...s.settings, ...patch } }));
  },
  addPsiSnapshot(entry: PsiHistoryEntry) {
    setCmsState((s) => {
      const next = [entry, ...s.psiHistory].slice(0, 200);
      return { ...s, psiHistory: next };
    });
  },
  clearPsiHistory() {
    setCmsState((s) => ({ ...s, psiHistory: [] }));
  },
};

export function uid(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-4)}`;
}

export function computeSeoScore(e: SeoEntry): number {
  let score = 0;
  if (e.metaTitle.length >= 30 && e.metaTitle.length <= 60) score += 20;
  else if (e.metaTitle) score += 10;
  if (e.metaDescription.length >= 80 && e.metaDescription.length <= 160) score += 20;
  else if (e.metaDescription) score += 10;
  if (e.keywords) score += 10;
  if (e.canonical) score += 15;
  if (e.ogTitle && e.ogDescription) score += 15;
  if (e.ogImage) score += 10;
  if (e.schema) score += 10;
  return Math.min(100, score);
}
