/**
 * PageSpeed Insights integration — server-only.
 *
 * The Google API key is read exclusively from `process.env.PSI_API_KEY`
 * (Lovable Cloud secret) inside the handler. It is never accepted from the
 * client, never echoed back in the response, and never logged.
 */
import { createServerFn } from "@tanstack/react-start";
import { emptyPsi } from "./demo";
import type { Envelope, PsiSnapshot } from "./types";


type PsiInput = { url: string; strategy?: "mobile" | "desktop" };

export const fetchPsi = createServerFn({ method: "POST" })
  .inputValidator((data: PsiInput) => ({
    url: typeof data?.url === "string" ? data.url : "/",
    strategy: data?.strategy === "desktop" ? "desktop" : "mobile",
  }))
  .handler(async ({ data }): Promise<Envelope<PsiSnapshot>> => {
    const strategy = data.strategy as "mobile" | "desktop";
    const key = process.env.PSI_API_KEY;
    const targetUrl = data.url.startsWith("http")
      ? data.url
      : `https://webstudiokkr.in${data.url.startsWith("/") ? data.url : `/${data.url}`}`;

    try {
      const params = new URLSearchParams({ url: targetUrl, strategy });
      ["performance", "accessibility", "best-practices", "seo"].forEach((c) =>
        params.append("category", c),
      );
      if (key) params.set("key", key);

      const res = await fetch(
        `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?${params.toString()}`,
        { headers: { Accept: "application/json" } },
      );
      if (!res.ok) throw new Error(`PSI ${res.status}`);
      const json = (await res.json()) as any;
      const lh = json.lighthouseResult;
      const cats = lh?.categories ?? {};
      const audits = lh?.audits ?? {};
      const numericValue = (id: string): number => audits[id]?.numericValue ?? 0;

      const snapshot: PsiSnapshot = {
        url: targetUrl,
        strategy,
        scores: {
          performance: Math.round((cats.performance?.score ?? 0) * 100),
          accessibility: Math.round((cats.accessibility?.score ?? 0) * 100),
          bestPractices: Math.round((cats["best-practices"]?.score ?? 0) * 100),
          seo: Math.round((cats.seo?.score ?? 0) * 100),
        },
        vitals: {
          lcp: Math.round(numericValue("largest-contentful-paint")),
          cls: Number((audits["cumulative-layout-shift"]?.numericValue ?? 0).toFixed(3)),
          inp: Math.round(
            numericValue("interaction-to-next-paint") || numericValue("max-potential-fid"),
          ),
          fcp: Math.round(numericValue("first-contentful-paint")),
          ttfb: Math.round(numericValue("server-response-time")),
        },
      };
      return { source: "live", fetchedAt: Date.now(), data: snapshot };
    } catch (err) {
      const reason = err instanceof Error ? err.message : "PSI request failed";
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyPsi(targetUrl),
        reason,
      };
    }
  });

