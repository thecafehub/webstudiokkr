/**
 * Empty/zeroed snapshots for analytics & SEO integrations.
 *
 * Production policy: never display fake numbers. When a provider isn't
 * configured (or fails), we return a zeroed snapshot and the UI shows
 * "Not Connected" / "No Data Yet" / "Awaiting Traffic".
 */
import type {
  ClaritySnapshot,
  Ga4Snapshot,
  GscSnapshot,
  PsiSnapshot,
} from "./types";

export function emptyGa4(): Ga4Snapshot {
  return {
    totals: { users: 0, sessions: 0, pageviews: 0, bounceRate: 0, avgSessionSeconds: 0 },
    monthly: [],
    sources: [],
    topPages: [],
    devices: [],
    countries: [],
  };
}

export function emptyGsc(): GscSnapshot {
  return {
    totals: { clicks: 0, impressions: 0, ctr: 0, position: 0 },
    topQueries: [],
    topPages: [],
  };
}

export function emptyPsi(url = "/"): PsiSnapshot {
  return {
    url,
    strategy: "mobile",
    scores: { performance: 0, accessibility: 0, bestPractices: 0, seo: 0 },
    vitals: { lcp: 0, cls: 0, inp: 0, fcp: 0, ttfb: 0 },
  };
}

export function emptyClarity(projectId = ""): ClaritySnapshot {
  return {
    projectId,
    dashboardUrl: projectId
      ? `https://clarity.microsoft.com/projects/view/${projectId}`
      : "https://clarity.microsoft.com",
    installed: Boolean(projectId),
  };
}
