/**
 * Client-side helpers to summarise which analytics/SEO integrations
 * are configured. Reads from the CMS settings store.
 */
import type { IntegrationsConfig } from "@/lib/admin/store";
import type { IntegrationStatus } from "./types";

export function getIntegrationStatuses(cfg: IntegrationsConfig): IntegrationStatus[] {
  return [
    {
      id: "ga4",
      label: "Google Analytics 4",
      connected: Boolean(cfg.ga4MeasurementId),
      details: cfg.ga4MeasurementId
        ? `Tracking ${cfg.ga4MeasurementId}${cfg.ga4PropertyId ? "" : " · add Property ID for in-app reports"}`
        : "Add a Measurement ID (G-XXXXX) to start tracking",
    },
    {
      id: "gsc",
      label: "Search Console",
      connected: Boolean(cfg.gscSiteUrl),
      details: cfg.gscSiteUrl
        ? `Site ${cfg.gscSiteUrl}`
        : "Add the verified site URL (e.g. https://webstudiokkr.in/)",
    },
    {
      id: "clarity",
      label: "Microsoft Clarity",
      connected: Boolean(cfg.clarityProjectId),
      details: cfg.clarityProjectId
        ? `Project ${cfg.clarityProjectId}`
        : "Add your Clarity Project ID to inject the script sitewide",
    },
    {
      id: "psi",
      label: "PageSpeed Insights",
      connected: true,
      details: "API key managed server-side (Cloud secret PSI_API_KEY)",
    },
  ];
}
