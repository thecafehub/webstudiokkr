/**
 * Typed result shapes for analytics & SEO integrations.
 * Every provider returns { source: 'live' | 'demo', data } so the UI can
 * surface where the numbers came from.
 */

export type DataSource = "live" | "demo" | "pending";

export type Envelope<T> = {
  source: DataSource;
  fetchedAt: number;
  /** For source === 'pending' this is a zeroed snapshot — render the awaiting state instead. */
  data: T;
  /** Human-readable reason when source !== 'live'. */
  reason?: string;
};

// --- GA4 -----------------------------------------------------------------

export type Ga4Series = { label: string; visitors: number; sessions: number }[];
export type Ga4SourceBreakdown = { name: string; value: number }[];
export type Ga4TopPage = { path: string; views: number }[];
export type Ga4Device = { name: string; value: number }[];
export type Ga4Country = { code: string; name: string; value: number }[];

export type Ga4Snapshot = {
  totals: {
    users: number;
    sessions: number;
    pageviews: number;
    bounceRate: number; // 0..1
    avgSessionSeconds: number;
  };
  monthly: Ga4Series;
  sources: Ga4SourceBreakdown;
  topPages: Ga4TopPage;
  devices: Ga4Device;
  countries: Ga4Country;
};

// --- Google Search Console ----------------------------------------------

export type GscRow = {
  query?: string;
  page?: string;
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
};

export type GscSnapshot = {
  totals: { clicks: number; impressions: number; ctr: number; position: number };
  topQueries: GscRow[];
  topPages: GscRow[];
};

// --- PageSpeed Insights --------------------------------------------------

export type PsiCategoryScore = {
  performance: number; // 0..100
  accessibility: number;
  bestPractices: number;
  seo: number;
};

export type PsiVitals = {
  lcp: number; // ms
  cls: number;
  inp: number; // ms
  fcp: number; // ms
  ttfb: number; // ms
};

export type PsiSnapshot = {
  url: string;
  strategy: "mobile" | "desktop";
  scores: PsiCategoryScore;
  vitals: PsiVitals;
};

// --- Microsoft Clarity ---------------------------------------------------

export type ClaritySnapshot = {
  projectId: string;
  /** Clarity does not expose a public REST metrics API. */
  dashboardUrl: string;
  installed: boolean;
};

// --- Provider connection status -----------------------------------------

export type IntegrationStatus = {
  id: "ga4" | "gsc" | "clarity" | "psi";
  label: string;
  connected: boolean;
  details: string;
};
