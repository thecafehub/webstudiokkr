/**
 * Google Analytics 4 (Data API v1beta) integration.
 *
 * Live source requires an OAuth2 access token OR a service-account JWT with
 * the `analytics.readonly` scope. We accept a short-lived access token via
 * `GA4_ACCESS_TOKEN` (Lovable Cloud secret) plus `GA4_PROPERTY_ID`.
 *
 * Until those are configured, deterministic demo data is returned with
 * `source: 'demo'` so the dashboard renders consistently.
 *
 * Reference: https://developers.google.com/analytics/devguides/reporting/data/v1/rest
 */
import { createServerFn } from "@tanstack/react-start";
import { emptyGa4 } from "./demo";
import type { Envelope, Ga4Snapshot } from "./types";

type Ga4Input = {
  propertyId?: string;
  accessToken?: string;
  /** ISO date or 'NdaysAgo' shortcut. Defaults to 30 days. */
  startDate?: string;
};

export const fetchGa4 = createServerFn({ method: "POST" })
  .inputValidator((data: Ga4Input) => data ?? {})
  .handler(async ({ data }): Promise<Envelope<Ga4Snapshot>> => {
    const propertyId = data.propertyId || process.env.GA4_PROPERTY_ID;
    const token = data.accessToken || process.env.GA4_ACCESS_TOKEN;

    // No property ID at all → demo (so empty installs still see the dashboard shape).
    if (!propertyId) {
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGa4(),
        reason: "Not connected — add a GA4 Property ID in Settings",
      };
    }


    // Property ID present but no API access token yet → pending state.
    // Surface zeroed data so the UI shows "Connected — awaiting API access"
    // instead of fake metrics.
    if (!token) {
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGa4(),
        reason: "Awaiting GA4_ACCESS_TOKEN (Lovable Cloud secret)",
      };
    }

    try {
      const endpoint = `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`;
      const body = {
        dateRanges: [{ startDate: data.startDate ?? "180daysAgo", endDate: "today" }],
        dimensions: [{ name: "month" }],
        metrics: [{ name: "totalUsers" }, { name: "sessions" }, { name: "screenPageViews" }],
      };
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`GA4 ${res.status}`);
      // Response mapper to Ga4Snapshot is added once a real OAuth token is wired.
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGa4(),
        reason: "GA4 reachable — response mapper pending",
      };
    } catch (err) {
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGa4(),
        reason: err instanceof Error ? err.message : "GA4 request failed",
      };
    }
  });
