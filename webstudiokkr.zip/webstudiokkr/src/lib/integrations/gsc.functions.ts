/**
 * Google Search Console (Search Analytics API) integration.
 *
 * Live source requires an OAuth2 access token with the
 * `webmasters.readonly` scope. Configure via `GSC_ACCESS_TOKEN` and
 * `GSC_SITE_URL` (Lovable Cloud secrets / CMS settings).
 *
 * Reference: https://developers.google.com/webmaster-tools/v1/searchanalytics/query
 */
import { createServerFn } from "@tanstack/react-start";
import { emptyGsc } from "./demo";
import type { Envelope, GscSnapshot } from "./types";


type GscInput = {
  siteUrl?: string;
  accessToken?: string;
  startDate?: string;
  endDate?: string;
};

export const fetchGsc = createServerFn({ method: "POST" })
  .inputValidator((data: GscInput) => data ?? {})
  .handler(async ({ data }): Promise<Envelope<GscSnapshot>> => {
    const siteUrl = data.siteUrl || process.env.GSC_SITE_URL;
    const token = data.accessToken || process.env.GSC_ACCESS_TOKEN;

    if (!siteUrl || !token) {
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGsc(),
        reason: !siteUrl
          ? "Not connected — add a Search Console site URL in Settings"
          : "Awaiting GSC_ACCESS_TOKEN (Cloud secret)",
      };
    }


    try {
      const endpoint = `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`;
      const today = new Date();
      const start = new Date(today.getTime() - 28 * 86400000);
      const fmt = (d: Date) => d.toISOString().slice(0, 10);
      const baseBody = {
        startDate: data.startDate ?? fmt(start),
        endDate: data.endDate ?? fmt(today),
        rowLimit: 10,
      };

      const [qRes, pRes] = await Promise.all([
        fetch(endpoint, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ...baseBody, dimensions: ["query"] }),
        }),
        fetch(endpoint, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ ...baseBody, dimensions: ["page"] }),
        }),
      ]);
      if (!qRes.ok || !pRes.ok) throw new Error(`GSC ${qRes.status}/${pRes.status}`);
      const qJson = (await qRes.json()) as any;
      const pJson = (await pRes.json()) as any;

      const topQueries = (qJson.rows ?? []).map((r: any) => ({
        query: r.keys?.[0],
        clicks: r.clicks,
        impressions: r.impressions,
        ctr: r.ctr,
        position: r.position,
      }));
      const topPages = (pJson.rows ?? []).map((r: any) => ({
        page: r.keys?.[0],
        clicks: r.clicks,
        impressions: r.impressions,
        ctr: r.ctr,
        position: r.position,
      }));
      const totals = topQueries.reduce(
        (a: any, r: any) => ({
          clicks: a.clicks + r.clicks,
          impressions: a.impressions + r.impressions,
          ctr: 0,
          position: 0,
        }),
        { clicks: 0, impressions: 0, ctr: 0, position: 0 },
      );
      totals.ctr = totals.impressions ? totals.clicks / totals.impressions : 0;
      totals.position =
        topQueries.reduce((a: number, r: any) => a + r.position, 0) /
        Math.max(topQueries.length, 1);

      return {
        source: "live",
        fetchedAt: Date.now(),
        data: { totals, topQueries, topPages },
      };
    } catch (err) {
      return {
        source: "pending",
        fetchedAt: Date.now(),
        data: emptyGsc(),
        reason: err instanceof Error ? err.message : "GSC request failed",
      };
    }
  });

