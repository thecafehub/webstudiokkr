import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { site } from "@/config/site";
import { AnalyticsScripts } from "@/components/integrations/AnalyticsScripts";

function NotFoundComponent() {
  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <p className="font-display text-[120px] font-bold leading-none gradient-brand-text">404</p>
        <h2 className="mt-2 font-display text-2xl font-semibold tracking-tight">
          Lost in the aurora
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-brand-blue to-brand-violet px-5 py-2.5 text-sm font-medium text-white transition-transform hover:-translate-y-0.5"
          >
            Take me home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md rounded-2xl glass-strong p-8 text-center">
        <h1 className="font-display text-xl font-semibold tracking-tight">
          Something went wrong
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          We've logged the error. You can try again or head home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-brand-blue to-brand-violet px-5 py-2.5 text-sm font-medium text-white"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-lg glass px-5 py-2.5 text-sm font-medium"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#0a0a1a" },
      { title: `${site.brand.name} — Premium Digital Studio, Marketplace & Tools` },
      {
        name: "description",
        content: site.brand.description,
      },
      { name: "author", content: site.brand.name },
      { property: "og:site_name", content: site.brand.name },
      { property: "og:type", content: "website" },
      { property: "og:title", content: `${site.brand.name} — Premium Digital Studio` },
      { property: "og:description", content: site.brand.description },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: site.brand.name },
      { name: "twitter:description", content: site.brand.description },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: site.brand.name,
          url: site.brand.url,
          description: site.brand.description,
          email: site.contact.email,
          telephone: site.contact.phone,
          address: {
            "@type": "PostalAddress",
            addressLocality: "Kurukshetra",
            addressRegion: "Haryana",
            addressCountry: "IN",
          },
          sameAs: [site.contact.telegramLink, site.contact.instagramLink],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AnalyticsScripts />
      <Outlet />
    </QueryClientProvider>
  );
}
